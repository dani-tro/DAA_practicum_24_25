#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 10;
const int INF = 1e9 + 1;

vector <pair <int, int> > v[MAXN];
int a[MAXN], comp[MAXN], w[MAXN];

int n, m;

void dfs(int x, int mx) {
    for (auto i : v[x]) {
        if (i.second < mx || comp[i.first]) continue;
        comp[i.first] = comp[x];
        dfs(i.first, mx);
    }
}

bool check(int x) {
    for (int i = 1; i <= n; i++) comp[i] = 0;
    int cnt = 1;
    for (int i = 1; i <= n; i++) {
        if (!comp[i]) {
            comp[i] = cnt++;
            dfs(i, x);
        }
    }

    for (int i = 1; i <= n; i++) {
        if (comp[i] != comp[a[i]]) return false;
    }

    return true;
}

int main () {
    //ifstream cin("wormsort.in");
    //ofstream cout("wormsort.out");

    bool sorted = true;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        if (i > 1 && a[i] < a[i - 1]) sorted = false;
    }
    for (int i = 0; i < m; i++) {
        int a, b; cin >> a >> b >> w[i];
        v[a].push_back({b, w[i]});
        v[b].push_back({a, w[i]});
    }

    if (sorted) {
        cout << -1 << endl;
        return 0;
    }

    int ans = 0;
    for (int i = 0; i < m; i++) {
        if (check(w[i])) {
            ans = max(ans, w[i]);
        }
    }

    cout << ans << endl;
    return 0;
}