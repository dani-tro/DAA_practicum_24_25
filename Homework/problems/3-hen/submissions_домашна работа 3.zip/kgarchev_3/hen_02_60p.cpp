#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 1e5;
const int MAX_W = 1e9;

struct Edge
{
    int from, to, w;

    Edge(int from = -1, int to = -1, int w = -1) : from(from), to(to), w(w) {}

    inline bool operator<(const Edge other) const { return w > other.w; }
};

int n, m;
int p[MAX_N];
Edge edges[MAX_N];

void readInput()
{
    cin >>n >>m;
    for(int i = 0; i < n; ++i)
    {
        cin >>p[i];
        --(p[i]);
    }
    for(int i = 0; i < m; ++i)
    {
        cin >>edges[i].from >>edges[i].to >>edges[i].w;
        --(edges[i].from);
        --(edges[i].to);
    }
}

int ld[MAX_N];
int rk[MAX_N];

struct Comp1
{
    inline bool operator()(const pair<int, int> a, const pair<int, int> b) const
    {
        return a.first < b.first;
    }
};

vector<set<pair<int, int>, Comp1>> tr;
priority_queue<pair<int, int>> unneeded;

void prepare()
{
    sort(edges, edges + m);
    for(int i = 0; i < n; ++i)
    {
        ld[i] = i;
        rk[i] = 0;
        tr.assign(n, set<pair<int, int>, Comp1>(Comp1()));
    }
    //unneeded = new priority_queue<int, vector<int>, Comp2>(Comp2(&tr));
}

int getLeader(int v)
{
    if(v == ld[v]) return v;
    return ld[v] = getLeader(ld[v]);
}

void unite(int u, int v)
{
    u = getLeader(u);
    v = getLeader(v);
    //cout <<"ha" <<endl;
    if(u == v) return;
    if(rk[u] < rk[v]) swap(u, v);

    ld[v] = u;
    if(rk[u] == rk[v]) ++(rk[u]);
}

void kruskal()
{
    //cout <<"Kruskal1" <<endl;
    for(int i = 0; i < m; ++i)
    {
        //cout <<"E: fr: " <<e.from + 1 <<" to: " <<e.to + 1 <<" w: " <<e.w <<endl;
        if(getLeader(edges[i].from) != getLeader(edges[i].to))
        {
            unite(edges[i].from, edges[i].to);
            tr[edges[i].from].emplace(edges[i].to, edges[i].w);
            tr[edges[i].to].emplace(edges[i].from, edges[i].w);
        }
    }
    //cout <<"Kruskal" <<endl;

    /*cout <<"Spanning tree:" <<endl;
    for(int i = 0; i < n; ++i)
    {
        cout <<i + 1 <<" -> ";
        for(const auto [a, w] : tr[i])
        {
            cout <<"(" <<a + 1 <<", " <<w <<"), ";
        }
        cout <<endl;
    }*/
}

void removeUnneededEdges()
{
    //cout <<"Poss unneeded" <<endl;
    for(int i = 0; i < n; ++i)
    {
        if(i == p[i])
        {
            //cout <<i+1 <<endl;
            unneeded.emplace(-tr[i].size(), i);
        }
    }
    //cout <<"Passed1" <<endl;
    int v, sz, nb;
    while(!unneeded.empty() && unneeded.top().first == -1)
    {
        v = unneeded.top().second;
        sz = -unneeded.top().first;
        unneeded.pop();
        if(sz != tr[v].size()) continue;
        //cout <<v+1 <<endl;
        nb = tr[v].begin()->first;
        tr[v].erase(tr[v].begin());
        /*if(tr[nb].lower_bound({v, -1}) != tr[nb].end())
            {
                cout <<"Rem: " <<"v: " <<v+1 " nb: " << <<tr[nb].lower_bound({nb, -1}) ->
            }*/
        tr[nb].erase(tr[nb].lower_bound({v, -1}));
        if(nb == p[nb])
            unneeded.emplace(-tr[nb].size(), nb);
    }
    /*cout <<"Spanning tree:" <<endl;
    for(int i = 0; i < n; ++i)
    {
        cout <<i + 1 <<" -> ";
        for(const auto [a, w] : tr[i])
        {
            cout <<"(" <<a + 1 <<", " <<w <<"), ";
        }
        cout <<endl;
    }*/
}

int answer()
{
    int ans = MAX_W;
    for(int i = 0; i < n; ++i)
    {
        for(auto [_, w] : tr[i])
        {
            ans = min(ans, w);
        }
    }

    return ans;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    readInput();

    bool isSorted = true;
    for(int i = 1; i < n; ++i)
    {
        if(p[i - 1] > p[i])
        {
            isSorted = false;
            break;
        }
    }

    if(isSorted)
    {
        cout <<-1 <<endl;
        return 0;
    }

    prepare();
    kruskal();
    removeUnneededEdges();
    cout <<answer() <<endl;
}
