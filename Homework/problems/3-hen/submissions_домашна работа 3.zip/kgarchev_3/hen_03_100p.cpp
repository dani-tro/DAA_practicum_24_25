#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 1e5;
const int MAX_W = 1e9;

struct Edge
{
    int from, to, w;

    Edge(int from = -1, int to = -1, int w = -1) : from(from), to(to), w(w) {}

    inline bool operator<(const Edge other) const { return w > other.w; }
};

int n, m;
int p[MAX_N];
Edge edges[MAX_N];

void readInput()
{
    cin >>n >>m;
    for(int i = 0; i < n; ++i)
    {
        cin >>p[i];
        --(p[i]);
    }
    for(int i = 0; i < m; ++i)
    {
        cin >>edges[i].from >>edges[i].to >>edges[i].w;
        --(edges[i].from);
        --(edges[i].to);
    }
}

int ld[MAX_N];
int rk[MAX_N];

vector<pair<int, int>> forest[MAX_N];
bool vis[MAX_N];
int ans = MAX_W;

void prepare()
{
    sort(edges, edges + m);
    for(int i = 0; i < n; ++i)
    {
        ld[i] = i;
        rk[i] = 0;
    }
    fill(vis, vis + n, false);
}

int getLeader(int v)
{
    if(v == ld[v]) return v;
    return ld[v] = getLeader(ld[v]);
}

void unite(int u, int v)
{
    u = getLeader(u);
    v = getLeader(v);
    if(u == v) return;
    if(rk[u] < rk[v]) swap(u, v);

    ld[v] = u;
    if(rk[u] == rk[v]) ++(rk[u]);
}

void kruskal()
{
    for(int i = 0; i < m; ++i)
    {
        if(getLeader(edges[i].from) != getLeader(edges[i].to))
        {
            unite(edges[i].from, edges[i].to);
            forest[edges[i].from].emplace_back(edges[i].to, edges[i].w);
            forest[edges[i].to].emplace_back(edges[i].from, edges[i].w);
        }
    }
    /*
    cout <<"Kruskal:" <<endl;
    for(int i = 0; i < n; ++i)
    {
        cout <<"i: " <<i + 1 << " -> ";
        for(auto [nb, w] : forest[i])
        {
            cout <<"(" <<nb + 1 <<", " <<w <<"), ";
        }
        cout <<endl;
    }
    */
}


bool dfs(int v, int par = -1)
{
    vis[v] = true;
    bool hasNonFixedPoints = p[v] != v;
    for(const auto [nb, w] : forest[v])
    {
        if(nb == par) continue;
        if(dfs(nb, v))
        {
            //cout <<"Edge: " << v + 1 <<" - " <<nb + 1 <<" with weight " <<w <<endl;
            ans = min(ans, w);
            hasNonFixedPoints = hasNonFixedPoints || p[nb] != nb;
        }
    }

    return hasNonFixedPoints;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    readInput();

    bool isSorted = true;
    for(int i = 1; i < n; ++i)
    {
        if(p[i - 1] > p[i])
        {
            isSorted = false;
            break;
        }
    }

    if(isSorted)
    {
        cout <<-1 <<endl;
        return 0;
    }

    prepare();
    kruskal();

    for(int i = 0; i < n; ++i)
    {
        if(!vis[i] && p[i] != i)
        {
            //cout <<"Dfs at " <<i + 1 <<endl;
            dfs(i);
        }
    }
    cout <<ans <<endl;
}
