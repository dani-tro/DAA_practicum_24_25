#include <bits/stdc++.h>

#define llong long long

const llong MAXN = 1e6 + 10;

llong n, m;
llong chickens[MAXN];
llong component[MAXN];

std::vector<std::pair<llong, llong>> graph[MAXN];

void findComponents(llong v, llong comp, llong maxW) {
    for (std::pair<llong, llong> e : graph[v]) {
        if (component[e.first] == -1 && e.second <= maxW) {
            component[e.first] = comp;
            findComponents(e.first, comp, maxW);
        }
    }
}

bool check(llong weight) {
    for (size_t i = 0; i < n; ++i) {
        component[i] = -1;
    }

    llong components = 0;
    for (size_t i = 0; i < n; ++i) {
        if (component[i] == -1) {
            findComponents(i, components, weight);
            ++components;
        }
    }

    for (size_t i = 0; i < n; ++i) {
        if (component[i] != component[chickens[i]]) {
            return false;
        }
    }

    return true;
}

int main() {
    std::cin >> n >> m;

    for (int i = 0; i < n; ++i) {
        std::cin >> chickens[i];
    }

    for (int i = 0; i < m; ++i) {
        llong a, b, w;
        std::cin >> a >> b >> w;
        --a;
        --b;
        graph[a].push_back({b, w});
        graph[b].push_back({a, w});
    }

    llong start = 0, end = LONG_LONG_MAX;

    while (start <= end) {
        llong mid = (start + end) / 2;
        if (check(mid)) {
            start = mid + 1;
        } else {
            end = mid - 1;
        }
    }

    std::cout << end << std::endl;
}