#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e6 + 10;
const int MAXM = 1e6 + 10;

int par[MAXN], sz[MAXN];

struct Edge {
    int u;
    int v;
    long long w;

    friend bool operator<(Edge a, Edge b) {
        return a.w < b.w;
    }
};

Edge e[MAXM];

int find_root(int x) {
    if (par[x] == x) return x;
    return par[x] = find_root(par[x]);
}

bool connect(int a, int b, long long w) {
    int ra, rb;
    ra = find_root(a);
    rb = find_root(b);

    if (ra == rb) return false;

    if (sz[ra] > sz[rb]) {
        par[rb] = ra;
        sz[ra] += sz[rb];
    } else {
        par[ra] = rb;
        sz[rb] += sz[ra];
    }
    
    return true;
}
int main () {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    cin >> n >> m;
    
    int* v = new int[n + 1];
    
    bool sorted = true;
    v[0] = 0;
    
    for (int i = 1; i <= n; i++) {
        cin >> v[i];
        if (v[i] < v[i - 1]) {
            sorted = false;
        }
    }
    
    for (int i = 1; i <= n; i++) {
        par[i] = i;
        sz[i] = 1;
    }
    
    for (int i = 0; i < m; i++) {
        cin >> e[i].u >> e[i].v >> e[i].w;
    }
    
    if (sorted) {
        cout << "-1";
        
        delete [] v;
        
        return 0;
    }
    
    sort(e, e+m);

    int max = 0;

    for (int i = 0; i < m; i++) {
        if (e[i].u > e[i].w || e[i].v > e[i].w) {
            continue;
        }
        if (connect(e[i].u, e[i].v, e[i].w)) {
            if (e[i].w > max) {
                max = e[i].w;
            }
        }
    }
    
    cout << max;
    
    delete [] v;

    return 0;
}