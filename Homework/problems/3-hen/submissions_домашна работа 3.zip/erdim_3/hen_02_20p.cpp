#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 10;
int p[MAXN];
int group[MAXN];
int sizee[MAXN];
struct Edge
{
    int from, to, weight;
    bool operator<(const Edge &other) const
    {
        return weight > other.weight;
    }
};
vector<Edge> edges;

void mark_group(int k, int gr)
{
    if (group[k] != 0)
        return;
    group[k] = gr;
    mark_group(p[k], gr);
}

struct DSU
{
    int lead[MAXN];
    int min_weight, cnt;
    set<int> grps[MAXN];
    int comp[MAXN];
    DSU(int n)
    {
        cnt = 0;
        for (int i = 1; i <= n; i++)
        {
            lead[i] = i;
            sizee[i] = 1;
            grps[i].insert(group[i]);
            comp[group[i]]++;
            if (comp[group[i]] == 2)
                cnt++;
        }
        min_weight = -1;
    }

    int findLead(int k)
    {
        if (k == lead[k])
            return k;
        return lead[k] = findLead(lead[k]);
    }

    void connect(Edge edge)
    {
        int p = edge.from, q = edge.to;
        int leadP = findLead(p);
        int leadQ = findLead(q);

        if (sizee[leadP] > sizee[leadQ])
        {
            swap(leadP, leadQ);
            swap(p, q);
        }

        if (leadP != leadQ && cnt > 0)
        {
            lead[leadP] = leadQ;
            sizee[leadQ] += sizee[leadP];
            min_weight = edge.weight;

            for (int el : grps[leadP])
            {
                grps[leadQ].insert(el);
                comp[el]--;
                if (comp[el] == 1)
                    cnt--;
            }
        }
    }
};

int mst(int n)
{
    sort(edges.begin(), edges.end());

    DSU *dsu = new DSU(n);
    for (Edge edge : edges)
    {
        dsu->connect(edge);
    }

    return dsu->min_weight;
}

int main()
{
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> p[i];

    int cnt = 0;
    for (int i = 1; i <= n; i++)
    {
        if (group[p[i]] == 0)
            mark_group(p[i], ++cnt);
    }

    for (int i = 1; i <= m; i++)
    {
        int p, q, w;
        cin >> p >> q >> w;
        edges.push_back({p, q, w});
    }

    cout << mst(n) << endl;

    return 0;
}