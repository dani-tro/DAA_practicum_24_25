#include<iostream>
#include<string>
#include<cstdio>
#include<cmath>
#include<stack>
#include<algorithm>
#define R 1000000001
#define MAX 100005
using namespace std;
long long  n, l ,r, mid , a[MAX], col[MAX], br=1, m ,ans=-1, v1, v2, w;
bool fl[MAX], flag;
vector < pair<long long, long long> > v[MAX];
void dfs(int u){
    int to;
    //fl[u]=flag;
    fl[u]=true;
    col[u]=br;
    for(pair<long long, long long> p : v[u]){
        to=p.first;
        //if(fl[to]!=flag && p.second>=mid) dfs(to);
        if(!fl[to] && p.second>=mid) dfs(to);
    }
}

bool check(){
    //flag=!flag;
    fill(fl+1,fl+n+1, false);
    //cout<<"mid="<< mid <<" flag="<< flag <<endl;
    for(int i=1;i<=n;i++){
        //if(fl[i]!=flag) {dfs(i); br++;}
        if(!fl[i]) {dfs(i); br++;}
    }
    //for(int i=1;i<=n;i++) cout<<col[i]<<" "; cout<<endl; 

    for(int i=1;i<=n;i++)
        if(col[i]!=col[a[i]]) return false;
    //cout<<"yep\n";
    return true;
}

void guess(){
    long long l=1, r=R;
    for(int i=1;i<=n;i++) 
        if(a[i]!=i) flag=true;
    if(!flag) return; //already sorted

    while(l<=r){
        mid=(l+r)/2;
        if(check()){
            ans=mid;
            l=mid+1;
        }
        else r=mid-1;
    }
}

int main (){
    int i,j=0;
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin>>n>>m;
    for(i=1;i<=n;i++) cin>>a[i];
    for(i=0;i<m;i++){
        cin>>v1>>v2>>w;
        v[v1].push_back({v2,w});
        v[v2].push_back({v1,w});
    }
    guess();
    cout << ans << endl;
    
    return 0;
}

/*
4 4
3 2 1 4
1 2 9
1 3 7
2 3 10
2 4 3

4 1
1 2 3 4
4 2 13



- ideq 1:  двоично търсене по отговора, за фиксирана тежест гледам в графа с ребра >= тази тежест дали тези от циклите са в една
свръ зана компонента 

// - ideq 2:  максимални покриващи дървета за 
*/