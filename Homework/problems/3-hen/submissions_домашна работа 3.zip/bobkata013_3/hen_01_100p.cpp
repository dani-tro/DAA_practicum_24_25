#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int N, M;
int p[100005 + 1];
int A[100005], B[100005];
ll Wt[100005];

ll widths[100005];
int Wn;

int parent_[100005 + 1], rank_[100005 + 1];

void dsu_init(int n) {
    for (int i = 1; i <= n; i++) {
        parent_[i] = i;
        rank_[i] = 0;
    }
}
int dsu_find(int x) {
    return parent_[x] == x ? x : (parent_[x] = dsu_find(parent_[x]));
}
void dsu_union(int a, int b) {
    a = dsu_find(a);
    b = dsu_find(b);
    if (a == b)
        return;
    if (rank_[a] < rank_[b])
        swap(a, b);
    parent_[b] = a;
    if (rank_[a] == rank_[b])
        rank_[a]++;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> M;
    bool already = true;
    for (int i = 1; i <= N; i++) {
        cin >> p[i];
        if (p[i] != i)
            already = false;
    }

    for (int i = 0; i < M; i++) {
        cin >> A[i] >> B[i] >> Wt[i];
        widths[i] = Wt[i];
    }

    if (already) {
        cout << -1 << "\n";
        return 0;
    }

    sort(widths, widths + M);
    Wn = int(unique(widths, widths + M) - widths);

    ll ans = -1;
    int lo = 0, hi = Wn - 1;
    while (lo <= hi) {
        int mid = (lo + hi) >> 1;
        ll thresh = widths[mid];

        dsu_init(N);
        for (int i = 0; i < M; i++) {
            if (Wt[i] >= thresh) {
                dsu_union(A[i], B[i]);
            }
        }

        bool ok = true;
        for (int i = 1; i <= N; i++) {
            if (dsu_find(i) != dsu_find(p[i])) {
                ok = false;
                break;
            }
        }

        if (ok) {
            ans = thresh;
            lo = mid + 1;
        }
        else {
            hi = mid - 1;
        }
    }

    cout << ans << "\n";
    return 0;
}
