#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>

using namespace std;
const int maxn = 1e6 + 10;
int n, m;
bool visited[maxn];
bool rightPlace[maxn];
int notInPlaceCount;
int start;

struct edge
{
	int v, w;
	bool operator <(const edge& other) const
	{
		return w < other.w;
	}
};

vector<edge> gr[maxn];
priority_queue<edge> pq;

int Prim()
{
	int minWormhole = INT_MAX;
	for (auto edge : gr[start])
	{
		pq.push(edge);
	}
	visited[start] = true;
	while (!pq.empty() && notInPlaceCount >= 0)
	{
		auto edge = pq.top();
		pq.pop();
		if (visited[edge.v])
			continue;
		visited[edge.v] = true;
		if(!rightPlace[edge.v])
			minWormhole = min(minWormhole, edge.w);
		for (auto v : gr[edge.v])
		{
			if (!visited[v.v])
			{
				pq.push(v);
			}
		}
	}
	return minWormhole;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m;
	int pos;
	for (size_t i = 1; i <= n; i++)
	{
		cin >> pos;
		if (pos != i)
		{
			++notInPlaceCount;
			start = i;
		}
		else
			rightPlace[i] = true;
	}
	int u, v, w;
	for (size_t i = 0; i < m; i++)
	{
		cin >> u >> v >> w;
		gr[u].push_back({ v ,w });
		gr[v].push_back({ u, w });
	}
	if (notInPlaceCount == 0)
		cout << -1 << endl;
	else
		cout << Prim() << endl;
	/*
	4 1
	1 2 3 4
	4 2 13

	4 4
	3 2 1 4
	1 2 9
	1 3 7
	2 3 10	
	2 4 3
	*/
	return 0;
}