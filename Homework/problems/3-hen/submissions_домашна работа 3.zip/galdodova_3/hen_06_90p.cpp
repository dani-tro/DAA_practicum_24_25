#include <vector>
#include <iostream>
#include <tuple>

using namespace std;

long long int n, m;
vector<vector<int>> graph;
vector<bool> visited;

void dfs_mark(int node, int cid, vector<int>& comp) {
    visited[node] = true;
    comp[node] = cid;
    for (int neighbor : graph[node]) {
        if (!visited[neighbor]) {
            dfs_mark(neighbor, cid, comp);
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> m;
    vector<int> positions(n);
    vector<tuple<int, int, int>> edges;

    for (int i = 0; i < n; i++) {
        cin >> positions[i];
    }

    for (int i = 0; i < m; i++) {
        int a, b, w;
        cin >> a >> b >> w;
        edges.emplace_back(a, b, w);
    }

    long long answer = -1;
    long long left = 0, right = 1e9;

    while (left <= right) {
        long long mid = (left + right) / 2;
        graph.assign(n + 1, vector<int>());
        for (auto [a, b, w] : edges) {
            if (w >= mid) {
                graph[a].push_back(b);
                graph[b].push_back(a);
            }
        }

        visited.assign(n + 1, false);
        vector<int> component_id(n + 1, -1);
        int cid = 0;

        for (int i = 1; i <= n; i++) {
            if (!visited[i]) {
                dfs_mark(i, cid, component_id);
                cid++;
            }
        }

        bool ok = true;
        for (int i = 0; i < n; i++) {
            int start = i + 1;
            int target = positions[i];
            if (component_id[start] == -1 || component_id[target] == -1 ||
                component_id[start] != component_id[target]) {
                ok = false;
                break;
            }
        }

        if (ok) {
            answer = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    // Финална проверка: ако не е намерено валидно решение
    if (answer == -1) {
        cout << -1 << '\n';
    } else {
        cout << answer << '\n';
    }

    return 0;
}
