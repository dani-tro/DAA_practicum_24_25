#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define MAX	100500

queue<int> q;

pair<int, int> pairs[MAX];

vector<pair<int, int>> gr[MAX];

int chickens[MAX], N = 0, M = 0, u = 0, v = 0, w = 0, cnt = 0, minW = INT16_MAX, maxW = 0;
bool visited[MAX];


bool isTherePath(int start, int end, int weight) {
	q.push(start);
	visited[start] = true;

	while (!q.empty()) {
		int node = q.front();
		q.pop();

		if (node == end) return true;

		for (auto adj : gr[node]) {
			if (adj.second >= weight && !visited[adj.first]) {
				q.push(adj.first);
				visited[adj.first] = true;
			}

		}
	}

	return false;
}

int main() {
	//INPUT CHICKENS
	cin >> N>>M;
	for (int i = 1; i <= N; ++i) {
		cin >> chickens[i];
	}

	//INPUT GRAPH
	for (int i = 0; i < M; ++i) {
		cin >> u >> v >> w;
		gr[u].push_back({ v, w });
		gr[v].push_back({ u, w });

		minW = min(minW, w);
		maxW = max(maxW, w);
	}

	//SORT CHECK
	for (int i = 1; i <= N; ++i) {
		if (chickens[i] == i) continue;
		else {
			pairs[cnt++] = {i, chickens[i]};
		}
	}

	if (cnt == 0) {
		cout << -1;
		return 0;
	}

	int left = minW, right = maxW, currRes = INT16_MIN;
	while (left <= right) {
		int mid = left + ((right - left) / 2);

		bool res = true;
		for (int i = 0; i < cnt && res; ++i) {
			for (int i = 1; i <= M; ++i) {
				visited[i] = false;
			}
			q = queue<int>();
			res = res && isTherePath(pairs[i].first, pairs[i].second, mid);
		}

		if (res) {
			currRes = mid;
			left = mid + 1;
		}
		else
			right = mid - 1;
	}

	std::cout << currRes;

}



