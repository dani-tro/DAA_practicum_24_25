#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 5;

int N, M, p[MAXN];
vector<tuple<int, int, int>> edges;

struct DSU {
    vector<int> parent;

    DSU(int n) {
        parent.resize(n+1);
        iota(parent.begin(), parent.end(), 0);
    }

    int find(int x) {
        if (x != parent[x])
            parent[x] = find(parent[x]);
        return parent[x];
    }

    void unite(int x, int y) {
        x = find(x), y = find(y);
        if (x != y)
            parent[y] = x;
    }
};

bool check(int w) {
    DSU dsu(N);
    for (auto &[a, b, weight] : edges) {
        if (weight >= w) {
            dsu.unite(a, b);
        }
    }
    for (int i = 1; i <= N; ++i) {
        if (dsu.find(i) != dsu.find(p[i])) {
            return false;
        }
    }
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> M;
    for (int i = 1; i <= N; ++i)
        cin >> p[i];

    bool sorted = true;
    for (int i = 1; i <= N; ++i)
        if (p[i] != i) sorted = false;

    if (sorted) {
        cout << -1 << '\n';
        return 0;
    }

    edges.resize(M);
    for (int i = 0; i < M; ++i) {
        int a, b, w;
        cin >> a >> b >> w;
        edges[i] = {a, b, w};
    }

    int left = 1, right = 1e9, ans = -1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (check(mid)) {
            ans = mid;
            left = mid + 1; // търсим по-голямо
        } else {
            right = mid - 1;
        }
    }

    cout << ans << '\n';
    return 0;
}
