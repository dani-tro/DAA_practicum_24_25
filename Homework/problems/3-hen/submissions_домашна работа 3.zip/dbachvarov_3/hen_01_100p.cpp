#include <bits/stdc++.h>

using namespace std;

struct edge
{
    int d, w;
    edge(int dest, int weight) : d(dest), w(weight) {}
};

const int maxn = 1e5 + 10;
int n, m;

vector<int> loc, lhs, rhs, weight, comp;
vector<vector<edge>> graph;

void dfs(int curr, int label, int mw)
{
    if (comp[curr] == label) return;
    comp[curr] = label;

    for (auto e : graph[curr])
    {
        if (e.w >= mw)
        {
           dfs(e.d, label, mw);
        }
    }
}

bool check(int mw)
{
    for (int i = 0; i < comp.size(); i++)
        comp[i] = -1;
    int numcopms = 0;
    for (int i = 0; i < comp.size(); i++)
    {
        if (comp[i] < 0)
            dfs(i, numcopms++, mw);
    }

    for (int i = 0; i < loc.size(); i++)
    {
        if (comp[i] != comp[loc[i]]) return false;
    }

    return true;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m;
    loc.resize(n);
    comp.resize(n);
    graph.resize(n);
    lhs.resize(m);
    rhs.resize(m);
    weight.resize(m);

    for (int i = 0; i < n; i++)
    {
        cin >> loc[i];
        loc[i]--;
    }

    for (int i = 0; i < m; i++)
    {
        int a, b, w;
        cin >> a >> b >> w;
        a--; b--;
        graph[a].emplace_back(b, w);
        graph[b].emplace_back(a, w);
    }

    int l = 0;
    int r = 1000000001;

    while (l != r)
    {
        int m = (l + r + 1) / 2;

        if (check(m)) l = m;
        else r = m - 1;
    }

    if (l > 1e9) l = -1;
    cout << l << endl;

    return 0;
}
