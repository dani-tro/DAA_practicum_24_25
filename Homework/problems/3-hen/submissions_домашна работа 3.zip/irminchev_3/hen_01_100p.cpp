#include <cstdio>
#include <vector>
using namespace std;

const int MAXN = 1e5 + 5;

int N, M;
int p[MAXN];
struct Tunnel {
    int a, b, w;
};
vector<Tunnel> tunnels;
int parent[MAXN];

// DSU
int find(int x) {
    if (parent[x] != x)
        parent[x] = find(parent[x]);
    return parent[x];
}

void unite(int x, int y) {
    x = find(x);
    y = find(y);
    if (x != y)
        parent[y] = x;
}

bool can_sort(int min_width) {
    for (int i = 1; i <= N; ++i)
        parent[i] = i;

    for (const auto& t : tunnels) {
        if (t.w >= min_width)
            unite(t.a, t.b);
    }

    for (int i = 1; i <= N; ++i) {
        if (find(i) != find(p[i]))
            return false;
    }

    return true;
}

int main() {
    scanf("%d %d", &N, &M);
    for (int i = 1; i <= N; ++i)
        scanf("%d", &p[i]);

    tunnels.resize(M);
    for (int i = 0; i < M; ++i) {
        scanf("%d %d %d", &tunnels[i].a, &tunnels[i].b, &tunnels[i].w);
    }

    // Проверка дали вече е сортиран
    bool sorted = true;
    for (int i = 1; i <= N; ++i) {
        if (p[i] != i) {
            sorted = false;
            break;
        }
    }

    if (sorted) {
        printf("-1\n");
        return 0;
    }

    int low = 1, high = 1'000'000'000, answer = -1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (can_sort(mid)) {
            answer = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    printf("%d\n", answer);
    return 0;
}
