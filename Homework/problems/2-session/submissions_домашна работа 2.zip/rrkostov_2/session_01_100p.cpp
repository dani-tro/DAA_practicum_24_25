#include <iostream>
#include <iomanip>
#include <cmath>
#include <climits>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <queue>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>

using namespace std;

bool compareELementsOfA(const pair<long long, long long>& pair1, const pair<long long, long long>& pair2) {
	return pair1.first > pair2.first;
}

int main() {
	ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

	int n;
	long long m;
	cin >> n >> m;
	vector<pair<long long, long long>> a(n);

	for (int i = 0; i < n; ++i) {
		cin >> a[i].first;
	}
	for (int i = 0; i < n; ++i) {
		cin >> a[i].second;
		a[i].first = max(a[i].first, a[i].second);
	}

	sort(a.begin(), a.end(), compareELementsOfA);

	long long minK = 0, maxK = a[0].first * m, resK = 0, currK;
	long long currSteps, leftoverSteps, extraSteps, extraToFill;
	bool isValidK;
	while (minK <= maxK) {
		currK = minK + (maxK - minK) / 2;

		leftoverSteps = 0;
		isValidK = true;
		for (int i = 0; i < n; ++i) {
			currSteps = currK / a[i].first;
			if (currK % a[i].first) {
				++currSteps;
			}

			if (currSteps <= m) {
				leftoverSteps += m - currSteps;
			}
			else {
				extraToFill = currK - (m * a[i].first);
				extraSteps = extraToFill / a[i].second;
				if (extraToFill % a[i].second) {
					++extraSteps;
				}
				leftoverSteps -= extraSteps;
				if (leftoverSteps < 0) {
					isValidK = false;
					break;
				}
			}
		}
		if (isValidK) {
			resK = max(resK, currK);
			minK = currK + 1;
		}
		else {
			maxK = currK - 1;
		}
	}

	cout << resK;

	return 0;
}