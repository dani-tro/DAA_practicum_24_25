#include<iostream>
#include<string>
#include<cstdio>
#include<cmath>
#include<stack>
#include<algorithm>
#define MAX 1000000000000000000
using namespace std;
long long  l ,r, mid , a[300005], b[300005], ans=0, k, mx, t, MX=1e18, n,m, L, R;
long long residue(long long x, long long y){
    if(x%y!=0) return 1;
    return 0;
}

bool solve(long long target){
    long long br=0;
    for(int i=1;i<=n;i++){
        //mx=max(a[i],b[i]);
        //k=min(target/mx+min(target%mx,(long long)1),m);
        // k=min(target/mx+residue(target,mx),m);
        // br+=k;
        // if(target>k*mx) br+=(target-k*mx)/b[i]+min((target-k*mx)%b[i],(long long)1);

        // t=target;
        // mx=max(a[i],b[i]);
        // k=min(target/mx+residue(t,mx),m);
        // br+=k; t-=k*mx;
        // if(t>0) br+=t/b[i]+residue(t,b[i]);

        t=target;
        if(a[i]>b[i]){
            mx=min(t/a[i]+residue(t,a[i]),m);
            br+=mx;
            t-=mx*a[i];
        }
        if(t>0)br+=t/b[i]+residue(t,b[i]);
        if(br>n*m)return false;
    }
    return br<=n*m;
}
void guess(){
    //long long l=1, r=MAX;
    //long long l=L, r=9223372036854775807;
    long long l=L, r=R;
    while(l<=r){
        mid=(l+r)/2;
        if(solve(mid)){
            ans=mid;
            l=mid+1;
        }
        else r=mid-1;
    }
}

int main (){
    int i,j=0;
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin>>n>>m;
    for(i=1;i<=n;i++) cin>>a[i];
    for(i=1;i<=n;i++) cin>>b[i];
    L=R=max(a[1],b[1]);
    for(i=2;i<=n;i++) {
        L=min(L,max(a[i],b[i]));
        R=max(R,max(a[i],b[i]));
    }
    L*=m; R*=m;
    guess();
    cout<<ans<<endl;
    // for(int i=0;i<n;i++) printf("%lld ",a[i]); cout<<endl;
    
    return 0;
}

/*
9 1
20 20 20 20 20 20 0 20 20
20 20 20 20 20 20 1 20 20

9 2
20 20 20 20 20 20 0 20 20
20 20 20 20 20 20 1 20 20

4 25
1 2 3 4
1 2 3 4

*/