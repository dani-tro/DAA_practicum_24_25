#include<bits/stdc++.h>
using namespace std;

unsigned lectures[300005];
unsigned alone[300005];

bool check(unsigned long long x, size_t n, unsigned m) {
    unsigned long long hours = 0;

    for (size_t i = 0; i < n; ++i) {
        unsigned long long to_study = x;

        if (lectures[i] > alone[i]) {
            unsigned attendance = min(m, (unsigned) ceil(1.0 * to_study / lectures[i]));
            to_study = attendance * lectures[i] >= to_study ? 0 : to_study - attendance * lectures[i];
            hours += attendance;
        }

        hours += ceil(1.0 * to_study / alone[i]);
    }

    return hours <= n * m;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	size_t n;
    unsigned m, max_amount;
	cin >> n >> m;
	
	for (size_t i = 0; i < n; ++i) {
		cin >> lectures[i];
        max_amount = i == 0 ? lectures[i] : max(max_amount, lectures[i]);
	}
	
	for (size_t i = 0; i < n; ++i) {
		cin >> alone[i];
        max_amount = max(max_amount, alone[i]);
	}
	
    unsigned long long l = 0, r = m * max_amount + 10, mid;

    while (l < r) {
        mid = (l + r + 1) / 2;

        if (check(mid, n, m)) {
            l = mid;
        } else {
            r = mid - 1;
        }
    }

    cout << l;
	return 0;
}