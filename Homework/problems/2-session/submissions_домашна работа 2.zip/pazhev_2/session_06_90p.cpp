#include<bits/stdc++.h>
using namespace std;

long long lectures[300005];
long long alone[300005];

bool check(long long x, long long n, long long m) {
    long long hours = 0;

    for (size_t i = 0; i < n; ++i) {
        long long to_study = x;

        if (lectures[i] > alone[i]) {
            long long attendance = min(m, (long long) ceil(1.0 * to_study / lectures[i]));
            to_study = max(0LL, to_study - attendance * lectures[i]);
            hours += attendance;
        }

        hours += ceil(1.0 * to_study / alone[i]);
    }

    return hours <= n * m;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	long long n;
    long long m, max_amount;
	cin >> n >> m;
	
	for (size_t i = 0; i < n; ++i) {
		cin >> lectures[i];
        max_amount = i == 0 ? lectures[i] : max(max_amount, lectures[i]);
	}
	
	for (size_t i = 0; i < n; ++i) {
		cin >> alone[i];
        max_amount = max(max_amount, alone[i]);
	}
	
    long long l = 0, r = m * max_amount + 10, mid;

    while (l < r) {
        mid = (l + r + 1) / 2;

        if (check(mid, n, m)) {
            l = mid;
        } else {
            r = mid - 1;
        }
    }

    cout << l;
	return 0;
}