#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int MAX_N = 3e5;
const ll MAX_M = 1e9;
const ll MAX_A = MAX_M;

int n, m;
ll maxR = 0;

struct Subj
{
    int a, b;
};

Subj sbs[MAX_N];

inline ll int_ceil_div(ll x, int y)
{
    return x / y + (x % y != 0);
}

/*
a * x + b * y >= k, 0 <= x <= m, y >= 0, min(x + y) == ?
a * x + b * y - k >= 0
min(x + y) =: c
|a * x + b * y - k >= 0
|y = c - x

=> |(a - b) * x + b * c - k >= 0
   | -1.x + c >= 0
& want: c>=0 min

c >= (k + (b - a) * x) / b -> slope < 1
c >= x -> slope = 1

=> the second function gets bigger after some place
                     SET
(k + (b - a) * x) / b = x
k + (b - a) * x = b * x
k - a * x = 0
x = k / a

0 <= x <= m
//(k + (b - a) * k / a) / b;
*/
#define find_min_hours_for(a, b, k) \
   ((b >= a) ? k / b + (k % b != 0) : \
           (k <= (ll)m * a) ? k / a + (k % a != 0) : \
            int_ceil_div(k - (ll)a * m, b) + m)

bool is_possible(ll minK)
{
    ll hours = (ll)n * m;
    for(Subj* sb = sbs; sb < sbs + n; ++sb)
    {
        hours -= find_min_hours_for(sb->a, sb->b, minK);
        if(hours < 0) return false;
    }

    return true;
}

int bin_search()
{
    //cout <<"Start L: " <<l <<" Start R: " <<r <<endl;
    ll l = m, r = l, mid;
    for(; is_possible(r); l = r, r <<= 1); // exponential search
    while(r - l > 1) // binary search
    {
        mid = l + ((r - l) >> 1);
        //cout <<"L: " <<l <<" r: " <<r <<" m: " <<mid <<endl;
        if(is_possible(mid))
        {
            l = mid;
        }
        else
        {
            r = mid;
        }
    }

    return l;
}


int main()
{
    cin >>n >>m;

    for(int i = 0; i < n; ++i)
    {
        cin >>sbs[i].a;
    }
    for(int i = 0; i < n; ++i)
    {
        cin >>sbs[i].b;
        maxR += max(sbs[i].a, sbs[i].b);
    }
    /*
    sort(sbs, sbs + n, [](const Subj x, const Subj y) {
         return x.a > x.b ? (y.a > y.b ? x.a < y.a : false) : (y.a > y.b ? true : (x.b == y.b ? x.a < x.b : x.b < y.b));
         });
    */

    //for(int i = 0; i < n; ++i) cout <<"(a:" <<sbs[i].a <<", b:" <<sbs[i].b <<"), "; cout <<endl;

    cout <<bin_search() <<endl;
}
/*
8  7
1 3 9 7 7 3 5 1
3 4 6 8 6 8 4 2

*/
