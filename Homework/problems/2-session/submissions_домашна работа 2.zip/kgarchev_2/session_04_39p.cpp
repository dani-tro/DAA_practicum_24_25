#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int MAX_N = 3e5;
const ll MAX_M = 1e9;
const ll MAX_A = MAX_M;

int n, m;
ll maxR = 0;

struct Subj
{
    int a, b;
};

Subj sbs[MAX_N];

bool is_possible(ll minK)
{
    ll available_hours = (ll)n * m;
    ll hours, rem;
    int i;
    for(i = 0; i < n; ++i)
    {
        hours = minK / sbs[i].b + (minK % sbs[i].b != 0);
        if(sbs[i].a > sbs[i].b) break;
        available_hours -= hours;
        if(available_hours < 0) return false;
    }
    for(; i < n; ++i)
    {
        hours = min((ll)m, minK / sbs[i].a + (minK % sbs[i].a != 0));
        available_hours -= hours;
        rem = minK - hours * sbs[i].a;
        available_hours -= rem > 0 ? rem / sbs[i].b + (rem % sbs[i].b != 0) : 0;
        if(available_hours < 0) return false;
    }

    return true;
}

pair<ll, ll> find_better_bounds()
{
    ll result = 0;
    double norm = 0;
    for(int i = 0; i < n; ++i)
    {
        result = max({result, (ll)sbs[i].a, (ll)sbs[i].b});
        norm  += 1.0 / max(sbs[i].a, sbs[i].b);
    }

    result = (ll)ceil((ll)n * m / (double)result / norm);
    return {result >> 1, result << 5};
}

int bin_search()
{
    //auto [l, r] = find_better_bounds();
    //ll mid;
    //l = max(l, (ll)m);
    //r = min(r, maxR * m + 1);
    //cout <<"Start L: " <<l <<" Start R: " <<r <<endl;
    ll l = m, r = maxR * m + 1, mid;
    while(r - l > 1)
    {
        mid = l + ((r - l) >> 1);
        //cout <<"L: " <<l <<" r: " <<r <<" m: " <<mid <<endl;
        if(is_possible(mid))
        {
            l = mid;
        }
        else
        {
            r = mid;
        }
    }

    return l;
}


int main()
{
    cin >>n >>m;

    for(int i = 0; i < n; ++i)
    {
        cin >>sbs[i].a;
    }
    for(int i = 0; i < n; ++i)
    {
        cin >>sbs[i].b;
        maxR += max(sbs[i].a, sbs[i].b);
    }

    sort(sbs, sbs + n, [](const Subj x, const Subj y) {
         return x.a > x.b ? (y.a > y.b ? x.a > y.a : false) : (y.a < y.b ? true : x.b > y.b);
         });


    //for(int i = 0; i < n; ++i) cout <<"(a:" <<sbs[i].a <<", b:" <<sbs[i].b <<"), "; cout <<endl;

    cout <<bin_search() <<endl;
}
