#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int MAX_N = 3e5;
const ll MAX_M = 1e9;
const ll MAX_A = MAX_M;

int n, m;

struct Subj
{
    int a, b;
};

Subj sbs[MAX_N];

bool is_possible(ll minK)
{
    ll available_hours = (ll)n * m;
    ll hours, rem;
    int i;
    for(i = 0; i < n; ++i)
    {
        hours = min((ll)m, minK / sbs[i].a + (minK % sbs[i].a != 0));
        if(hours * sbs[i].a < minK) break;
        available_hours -= hours;
    }
    for(; i < n; ++i)
    {
        hours = min((ll)m, minK / sbs[i].a + (minK % sbs[i].a != 0));
        if(sbs[i].a < sbs[i].b) hours = 0;
        available_hours -= hours;
        rem = minK - hours * sbs[i].a;
        available_hours -= rem / sbs[i].b + (rem % sbs[i].b != 0);
        if(available_hours < 0) return false;
    }

    return true;
}

int bin_search()
{
    ll l = m, r = MAX_A * m + 1, mid;
    while(r - l > 1)
    {
        mid = l + ((r - l) >> 1);
        //cout <<"L: " <<l <<" r: " <<r <<" m: " <<mid <<endl;
        if(is_possible(mid))
        {
            l = mid;
        }
        else
        {
            r = mid;
        }
    }

    return l;
}


int main()
{
    cin >>n >>m;

    for(int i = 0; i < n; ++i)
    {
        cin >>sbs[i].a;
    }
    for(int i = 0; i < n; ++i)
    {
        cin >>sbs[i].b;
    }

    sort(sbs, sbs + n, [](const Subj x, const Subj y) {
         return x.a != y.a ? x.a > y.a : x.b > x.b;
         });


    //for(int i = 0; i < n; ++i) cout <<"(a:" <<sbs[i].a <<", b:" <<sbs[i].b <<"), "; cout <<endl;

    cout <<bin_search() <<endl;
}
