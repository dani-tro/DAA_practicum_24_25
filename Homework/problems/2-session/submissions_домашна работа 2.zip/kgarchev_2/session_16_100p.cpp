#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int MAX_N = 3e5;
const ll MAX_M = 1e9;
const ll MAX_A = MAX_M;

int n;
ll m;
int minR = INT_MAX, maxR = 0;

struct Subj
{
    int a, b;
};

Subj sbs[MAX_N];

inline ll int_ceil_div(ll x, int y)
{
    return x / y + (x % y != 0);
}

#define find_min_hours_for(a, b, k) \
   ((b >= a) ? int_ceil_div(k, b) : \
    (k <= m * a) ? int_ceil_div(k, a) : \
    m + int_ceil_div(k - m * a, b))

bool is_possible(ll minK)
{
    ll hours = m * n;
    for(Subj* sb = sbs; sb < sbs + n; ++sb)
    {
        hours -= find_min_hours_for(sb->a, sb->b, minK);
        if(hours < 0) return false;
    }

    return true;
}

ll bin_search()
{
    ll l = m * minR, r = m * maxR + 1, mid;
    while(r - l > 1)
    {
        mid = l + ((r - l) >> 1);
        if(is_possible(mid))
        {
            l = mid;
        }
        else
        {
            r = mid;
        }
    }

    return l;
}


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin >>n >>m;

    for(Subj* sb = sbs; sb < sbs + n; ++sb)
    {
        cin >>(sb->a);
        minR = min(minR, sb->a);
    }
    for(Subj* sb = sbs; sb < sbs + n; ++sb)
    {
        cin >>(sb->b);
        maxR = max({maxR, sb->a, sb->b});
    }

    cout <<bin_search() <<endl;
}
/*
8 7
1 3 9 7 7 3 5 1
3 4 6 8 6 8 4 2

30
*/
