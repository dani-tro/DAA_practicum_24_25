#include <bits/stdc++.h>
using namespace std;

const int maxn = 3e5 + 5;
long long a[maxn], b[maxn];
int n, m;

bool isPossible(long long K)
{
    long long total = 0;
    for (int i = 1; i <= n; i++)
    {
        if (b[i] >= K)
            continue;
        if (a[i] <= b[i])
        {
            if (m * b[i] < K)
                return false;
            continue;
        }
        long long numerator = K - m * b[i];
        long long denominator = a[i] - b[i];
        long long x = (numerator + denominator - 1) / denominator;
        if (x < 0)
            x = 0;
        total += x;
        if (total > m * n)
            return false;
    }
    return true;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i <= n; i++)
        cin >> b[i];

    long long l = 0, r = 0, mid;
    r = 1e9;

    long long answer = 0;
    while (l <= r)
    {
        mid = (l + r) / 2;
        if (isPossible(mid))
        {
            answer = mid;
            l = mid + 1;
        }
        else
            r = mid - 1;
    }

    cout << answer << endl;

    return 0;
}