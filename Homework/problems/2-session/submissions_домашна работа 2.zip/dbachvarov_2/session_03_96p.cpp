#include <bits/stdc++.h>
using namespace std;

const int maxn = 3e5 + 5;
long long a[maxn], b[maxn];
long long n, m;

bool isPossible(long long k)
{
    long long total = 0;
    for (int i = 1; i <= n; i++)
    {
        long long x = min(m, (k / a[i] +((k % a[i]) > 0)));
        if (k <= m * a[i]) total += m - x;
        else
        {
            long long y = (k - m * a[i]) / b[i] + (((k - m * a[i]) % b[i]) > 0);
            total -= y;
        }

        if (total + (n - i) * m < 0) return 0;
    }
    return total >= 0;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i <= n; i++)
    {
        cin >> b[i];
        if (b[i] > a[i]) a[i] = b[i];
    }

    long long l = 0, r = 1e18 + 1, mid;

    while (l < r - 1)
    {
        mid = (l + r) / 2;
        if (isPossible(mid))
        {
            l = mid;
        }
        else
            r = mid;
    }

    cout << l << endl;

    return 0;
}