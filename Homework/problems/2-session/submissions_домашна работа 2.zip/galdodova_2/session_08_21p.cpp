#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long ll;

bool canAchieveK(int N, int M, const vector<ll>& a, const vector<ll>& b, ll K) {
    ll total_slots = (ll)N * M;
    ll used_slots = 0;

    for (int i = 0; i < N; i++) {
        // We want minimum number of slots to reach at least K knowledge
        // Best is to use max(a[i], b[i]) per slot
        // But we can choose any x lectures and y self-studies such that x + y <= M
        // and a[i]*x + b[i]*y >= K

        // Idea: Try best combo of x and y: binary search or greedy
        // Try 0..M lecture attendances, rest self-study, find minimal total

        // But since it's monotonic in x, we can binary search the minimal total needed for subject i
        ll low = 0, high = M, min_needed = M + 1;
        while (low <= high) {
            ll x = (low + high) / 2;
            ll lecture_knowledge = a[i] * x;
            ll remaining = max(0LL, K - lecture_knowledge);
            ll y = (b[i] == 0 ? 1e18 : (remaining + b[i] - 1) / b[i]);

            if (x + y <= M) {
                min_needed = x + y;
                high = x - 1;
            } else {
                low = x + 1;
            }
        }

        if (min_needed > M) return false;
        used_slots += min_needed;
        if (used_slots > total_slots) return false;
    }

    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;

    vector<ll> a(N), b(N);
    for (int i = 0; i < N; ++i) cin >> a[i];
    for (int i = 0; i < N; ++i) cin >> b[i];

    ll left = 0, right = 1e15, answer = 0;

    while (left <= right) {
        ll mid = (left + right) / 2;
        if (canAchieveK(N, M, a, b, mid)) {
            answer = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << answer << '\n';
    return 0;
}
