#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
typedef long long ll;

ll N, M;
vector<ll> a, b;

bool feasible(ll K) {
    ll totalReq = 0;

    cout << "Checking K = " << K << "\n";

    for (int i = 0; i < N; i++) {
        // Ако само self-study осигурява поне K, няма нужда от native часове.
        if (M * b[i] >= K) {

            cout << "Subject " << i+1 << ": M*b = " << M * b[i] << " >= K (" << K << ") -> req = 0\n";

            continue;
        }
        // Ако дори лекциите не достигат K, невъзможно.
        if (M * a[i] < K) {

            cout << "Subject " << i+1 << ": M*a = " << M * a[i] << " < K (" << K << ") -> not feasible\n";

            return false;
        }
        ll diff = a[i] - b[i];
        ll needed = K - M * b[i]; // Колко допълнителни знания трябва да се добавят чрез native часове
        ll req = (needed + diff - 1) / diff; // ceil(needed/diff)

        cout << "Subject " << i+1 << ": M*a = " << M * a[i] << ", M*b = " << M * b[i]
             << ", needed = " << needed << ", diff = " << diff
             << ", req = " << req << "\n";

        totalReq += req;
    }

    cout << "Total required native hours = " << totalReq << " (Available = " << M << ")\n";

    return totalReq <= M;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> M;
    a.resize(N); b.resize(N);
    for (int i = 0; i < N; i++)
        cin >> a[i];
    for (int i = 0; i < N; i++)
        cin >> b[i];

    ll lo = 0, hi = M * 1000000000LL, ans = 0;
    while (lo <= hi) {
        ll mid = (lo + hi) / 2;

        cout << "\nBinary search: lo = " << lo << ", hi = " << hi << ", mid = " << mid << "\n";

        if (feasible(mid)) {
            ans = mid;

            cout << "K = " << mid << " is feasible, updating answer to " << ans << " and moving lo to " << mid+1 << "\n";

            lo = mid + 1;
        } else {

            cout << "K = " << mid << " is NOT feasible, moving hi to " << mid-1 << "\n";

            hi = mid - 1;
        }
    }

    cout << ans << "\n";
    return 0;
}
