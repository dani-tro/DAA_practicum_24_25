#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long ll;

bool canAchieveK(int N, int M, const vector<ll>& a, const vector<ll>& b, ll K) {
    ll total_hours = (ll)N * M;
    ll needed_extra_study = 0;

    for (int i = 0; i < N; ++i) {
        ll max_from_lectures = a[i] * M;
        if (max_from_lectures >= K) continue;

        if (b[i] == 0) return false; // Няма как да наваксаме
        ll need = K - max_from_lectures;
        ll sessions = (need + b[i] - 1) / b[i];
        needed_extra_study += sessions;

        if (needed_extra_study > total_hours - M) return false; // Няма време (всеки предмет има M часа)
    }

    return true;
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<ll> a(N), b(N);
    for (int i = 0; i < N; ++i) cin >> a[i];
    for (int i = 0; i < N; ++i) cin >> b[i];

    ll left = 0, right = 1e15, ans = 0;
    while (left <= right) {
        ll mid = (left + right) / 2;
        if (canAchieveK(N, M, a, b, mid)) {
            ans = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << ans << endl;
    return 0;
}
