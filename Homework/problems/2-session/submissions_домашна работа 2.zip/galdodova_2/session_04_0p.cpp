#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool canAchieveK(int N, int M, const vector<long long>& a, const vector<long long>& b, long long K) {
    cout << "Checking if we can achieve K = " << K << endl; // Дебъг съобщение за текущото K

    // Създаваме масив за минималния брой часове за всеки предмет
    vector<long long> hours(N, 0);

    // Разпределяме часовете по предметите
    for (int i = 0; i < N; i++) {
        cout << "For subject " << i + 1 << " (a[" << i << "] = " << a[i] << ", b[" << i << "] = " << b[i] << "): ";

        // Ако предметът има нужда от по-малко знания от K, не е необходимо да учим за него
        if (a[i] >= K) {
            hours[i] = 0; // Този предмет може да се остави без допълнително учене
            cout << "We don't need extra hours for this subject. Hours = " << hours[i] << endl;
        } else {
            long long needed = K - a[i];  // Колко знания липсват до K
            cout << "Need " << needed << " more knowledge for subject " << i + 1 << endl;

            // Проверяваме дали можем да достигнем необходимото чрез самостоятелно учене
            if (b[i] > 0) {
                hours[i] = (needed + b[i] - 1) / b[i];  // Колко часа са нужни за да се достигне K
                cout << "To achieve K, we need " << hours[i] << " hours of self-study" << endl;
            }
        }
    }

    // Проверяваме дали можем да разпределим всичките M * N часа
    long long totalHoursRequired = 0;
    for (int i = 0; i < N; i++) {
        totalHoursRequired += hours[i];
    }

    cout << "Total hours required: " << totalHoursRequired << endl;

    // Ако можем да разпределим часовете така, че всички предмети да имат минимум K знания
    bool canAchieve = totalHoursRequired <= M * N;
    cout << "Can we achieve this K? " << (canAchieve ? "Yes" : "No") << endl;

    return canAchieve;
}

int main() {
    int N, M;
    cin >> N >> M;

    vector<long long> a(N), b(N);
    for (int i = 0; i < N; i++) {
        cin >> a[i];
    }

    for (int i = 0; i < N; i++) {
        cin >> b[i];
    }

    long long left = 0, right = 1e9, ans = 0;

    // Бинарно търсене за максимално възможно K
    while (left <= right) {
        long long mid = (left + right) / 2;
        cout << "Binary Search - Trying K = " << mid << endl;

        if (canAchieveK(N, M, a, b, mid)) {
            ans = mid; // Това K е възможно, пробваме по-голямо
            cout << "K = " << mid << " is achievable, trying higher values." << endl;
            left = mid + 1;
        } else {
            cout << "K = " << mid << " is not achievable, trying lower values." << endl;
            right = mid - 1;
        }
    }

    cout << "Maximum achievable K is: " << ans << endl;
    return 0;
}
