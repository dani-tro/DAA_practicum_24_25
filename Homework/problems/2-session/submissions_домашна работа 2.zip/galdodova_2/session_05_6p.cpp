#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

typedef long long ll;

bool canAchieveK(int N, int M, const vector<ll>& a, const vector<ll>& b, ll K) {
    vector<ll> needed(N);
    for (int i = 0; i < N; i++) {
        needed[i] = K;
    }

    // Min heap for greedy selection of best way to gain knowledge
    priority_queue<pair<ll, int>> pq;

    // Try to simulate the entire N*M hours
    for (int week = 0; week < M; week++) {
        for (int subject = 0; subject < N; subject++) {
            // For this hour (week x subject), we can:
            // - go to the lecture for subject `subject` (gain a[subject])
            // - OR self-study any subject j (gain b[j]) — pick best available

            // Greedy: push both options into the heap
            if (a[subject] > 0)
                pq.emplace(a[subject], subject); // lecture option
        }

        // We process exactly N actions this week
        for (int i = 0; i < N && !pq.empty(); i++) {
            auto [gain, subj] = pq.top(); pq.pop();
            if (needed[subj] > 0) {
                needed[subj] -= min(gain, needed[subj]);
            }
        }
    }

    // Check if we reached at least K knowledge for each subject
    for (int i = 0; i < N; i++) {
        if (needed[i] > 0)
            return false;
    }

    return true;
}

int main() {
    int N, M;
    cin >> N >> M;

    vector<ll> a(N), b(N);
    for (int i = 0; i < N; i++) cin >> a[i];
    for (int i = 0; i < N; i++) cin >> b[i];

    ll left = 0, right = 1e15, ans = 0;

    while (left <= right) {
        ll mid = (left + right) / 2;
        if (canAchieveK(N, M, a, b, mid)) {
            ans = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << ans << endl;
    return 0;
}
