#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long ll;

bool canAchieveK(int N, int M, const vector<ll>& a, const vector<ll>& b, ll K) {
    vector<ll> extra_needed(N, 0);
    ll total_slots = (ll)N * M;

    // В колко от часовете Боби трябва да учи самостоятелно, за да навакса
    // Опитваме greedy: винаги използваме максимум от лекции (M пъти a[i])
    // и ако не стигне, наваксваме с b[i] — колкото трябва

    ll extra_study_sessions = 0;

    for (int i = 0; i < N; i++) {
        ll max_lecture_gain = a[i] * M;
        if (max_lecture_gain >= K) continue;  // Стига само с лекции

        ll need = K - max_lecture_gain;
        if (b[i] == 0) return false;  // Не можем да наваксаме

        // Колко самостоятелни часа са нужни
        ll required_sessions = (need + b[i] - 1) / b[i];
        extra_study_sessions += required_sessions;
        if (extra_study_sessions > total_slots - N * M) return false; // няма време
    }

    return true;
}

int main() {
    int N, M;
    cin >> N >> M;

    vector<ll> a(N), b(N);
    for (int i = 0; i < N; i++) cin >> a[i];
    for (int i = 0; i < N; i++) cin >> b[i];

    ll left = 0, right = 1e15, answer = 0;

    while (left <= right) {
        ll mid = (left + right) / 2;
        if (canAchieveK(N, M, a, b, mid)) {
            answer = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << answer << endl;
    return 0;
}
