#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

// Функция за проверка дали можем да постигнем минимално ниво K за всички предмети
bool canAchieveK(long long K, long long N, long long M, const vector<long long>& a, const vector<long long>& b) {
    long long totalReq = 0;
    for (int i = 0; i < N; i++) {
        long long lectureKnowledge = M * a[i];
        if (lectureKnowledge < K) {
            long long deficit = K - lectureKnowledge;
            // Изчисляваме минималния брой самостоятелни часове, нужни за да компенсираме дефицита:
            long long req = (deficit + b[i] - 1) / b[i]; // Това е ceil(deficit / b[i])
            totalReq += req;
        }
    }
    return totalReq <= M;
}



int main() {
    long long N, M;
    cin >> N >> M;

    vector<long long> a(N), b(N);
    for (long long i = 0; i < N; i++) {
        cin >> a[i];  // Знания от лекции
    }
    for (long long i = 0; i < N; i++) {
        cin >> b[i];  // Знания от самостоятелно учене
    }

    // Двоично търсене на максималното възможно минимално ниво K
    long long l = 0, r = 1000000000;  // Начален диапазон за K
    long long answer = 0;

    while (l <= r) {
        long long m = (l + r) / 2;
        if (canAchieveK(m, N, M, a, b)) {
            answer = m;  // Можем да постигнем поне K = m
            l = m + 1;  // Търсим по-голямо K
        } else {
            r = m - 1;  // Намаляваме диапазона за търсене на K
        }
    }

    cout << answer << endl;  // Отпечатваме максималното възможно минимално ниво K

    return 0;
}
