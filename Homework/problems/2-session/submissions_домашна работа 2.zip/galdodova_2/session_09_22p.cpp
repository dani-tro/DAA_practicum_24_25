#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long ll;

// Проверява дали може да се постигне знание K за всички предмети
bool canAchieveK(int N, int M, const vector<ll>& a, const vector<ll>& b, ll K) {
    ll total_time = (ll)N * M;
    ll used_time = 0;

    for (int i = 0; i < N; i++) {
        ll min_time = M + 1;

        // Пробваме всички възможни лекции от 0 до M
        for (ll lectures = 0; lectures <= M; ++lectures) {
            ll gain = lectures * a[i];
            ll remain = max(0LL, K - gain);

            if (b[i] == 0 && remain > 0) continue;

            ll self_study = (b[i] == 0) ? 0 : (remain + b[i] - 1) / b[i];
            if (lectures + self_study <= M) {
                min_time = min(min_time, lectures + self_study);
            }
        }

        if (min_time > M) return false;
        used_time += min_time;

        if (used_time > total_time) return false;
    }

    return true;
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<ll> a(N), b(N);
    for (int i = 0; i < N; i++) cin >> a[i];
    for (int i = 0; i < N; i++) cin >> b[i];

    ll left = 0, right = 1e15, answer = 0;

    while (left <= right) {
        ll mid = (left + right) / 2;
        if (canAchieveK(N, M, a, b, mid)) {
            answer = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << answer << endl;
    return 0;
}
