#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

long long N, M;
vector<long long> a, b;

// Проверка дали можем да постигнем дадено K
bool canAchieveK(long long K) {
    long long extraHours = 0;

    for (int i = 0; i < N; i++) {
        long long needed = K - M * a[i]; // Колко знания трябва да добавим за предмет i
        if (needed > 0) {
            extraHours += needed; // Сумираме допълнителните знания, които ни трябват
        }
    }

    // Проверяваме дали можем да компенсираме с индивидуалното учене
    long long maxSelfStudy = M * *max_element(b.begin(), b.end()); // Най-доброто b_j
    return extraHours <= maxSelfStudy;
}

int main() {
    // Входни данни
    cin >> N >> M;
    a.resize(N);
    b.resize(N);

    for (int i = 0; i < N; i++) cin >> a[i];
    for (int i = 0; i < N; i++) cin >> b[i];

    // Бинарно търсене на максималното K
    long long left = 0, right = M * *max_element(b.begin(), b.end()), answer = 0;

    while (left <= right) {
        long long mid = (left + right) / 2;

        if (canAchieveK(mid)) {
            answer = mid;
            left = mid + 1; // Пробваме по-голямо K
        } else {
            right = mid - 1; // Намаляваме K
        }
    }

    cout << answer << endl;
    return 0;
}
