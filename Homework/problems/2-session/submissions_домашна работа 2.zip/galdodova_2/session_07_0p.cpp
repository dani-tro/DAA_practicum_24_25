#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long ll;

bool canAchieveK(int N, int M, const vector<ll>& a, const vector<ll>& b, ll K) {
    ll max_actions = (ll)N * M;
    ll extra_hours = 0;

    for (int i = 0; i < N; i++) {
        ll max_from_lectures = a[i] * M;
        if (max_from_lectures >= K) continue;

        if (b[i] == 0) return false;

        ll missing = K - max_from_lectures;
        ll needed_sessions = (missing + b[i] - 1) / b[i];
        extra_hours += needed_sessions;

        if (extra_hours > max_actions) return false;
    }

    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;

    vector<ll> a(N), b(N);
    for (int i = 0; i < N; ++i) cin >> a[i];
    for (int i = 0; i < N; ++i) cin >> b[i];

    ll left = 0, right = 1e15, best = 0;

    while (left <= right) {
        ll mid = (left + right) / 2;
        if (canAchieveK(N, M, a, b, mid)) {
            best = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << best << "\n";
    return 0;
}
