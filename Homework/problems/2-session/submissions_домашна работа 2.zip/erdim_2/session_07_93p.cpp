#include <bits/stdc++.h>
using namespace std;

const int MAXN = 3e5 + 10;
int n, m;
long long a[MAXN], b[MAXN];

bool check(long long k)
{
    long long left = 0;
    for (int i = 1; i <= n; i++)
    {
        if (a[i] < b[i])
            a[i] = b[i];
        long long days = k / a[i] + (bool)(k % a[i]);
        long long study = k - 1LL * m * a[i];
        if (m >= days)
            left += m - days;
        else
            left -= (study / b[i] + (bool)(study % b[i]));

        // if (left + (n - i) * m < 0)
        //   break;
    }

    return (left >= 0);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i <= n; i++)
        cin >> b[i];

    long long l = 0, r = 1e18 + 10;
    while (l <= r)
    {
        long long mid = (l + r) / 2;
        if (check(mid))
            l = mid + 1;
        else
            r = mid - 1;
    }

    cout << r << endl;

    return 0;
}