#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
typedef unsigned long long lin;
using namespace std;
lin a[300010];
lin b[300010];

bool check(lin k, lin n, lin m) {
	long long debt = 0;
	for (size_t i = 0; i < n; i++)
	{
		lin best = a[i] >= b[i] ? a[i] : b[i];
		if (best * m > k) {
			debt -= (best * m - k) / best;
		}
		else if (best * m < k) {
			debt += (k - best * m + b[i] - 1) / b[i];
		}
	}
	return debt <= 0;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	lin n, m, max = 0;
	cin >> n >> m;
	for (size_t i = 0; i < n; i++)
	{
		cin >> a[i];
		max = max >= a[i] ? max : a[i];
	}
	for (size_t i = 0; i < n; i++)
	{
		cin >> b[i];
		max = max >= b[i] ? max : b[i];
	}
	lin low = 0, high = 5*max*n*m, mid = (low + high + 1) / 2;
	while (low < high - 1) {
		if (check(mid, n, m)) {
			low = mid;
		}
		else {
			high = mid - 1;
		}
		mid = (low + high + 1) / 2;
	}
	if (check(mid, n, m))
		cout << mid;
	else
		cout << mid - 1;
}