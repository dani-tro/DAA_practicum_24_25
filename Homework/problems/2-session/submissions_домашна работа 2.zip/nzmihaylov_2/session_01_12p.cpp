#include <climits>
#include <iostream>
#include <queue>

using namespace std;
using llong = long long;

int const MAX = 3*1e5;

llong a[MAX+10], b[MAX+10], c[MAX+10];

struct Triple {
  llong acc;
  llong value;
  int index;

  bool operator<(Triple const& other) const {
    if (acc != other.acc) return value > other.value;
    return acc < other.acc;
  }
};

llong solve(int n, int m) {
  priority_queue<Triple> q;
  llong minv = 0;

  for (llong i = 0; i < m; ++i) {
    for (int j = 0; j < n; ++j) {
      q.push({c[j], a[j], j});
    }

    for (int j = 0; j < n; ++j) {
      if (a[j] < q.top().value) {
        Triple top = q.top();
        q.pop();
        top.acc += b[top.index];
        q.push(top);
      }
      else {
        c[j] += a[j];
      }
    }

    llong curmin = LLONG_MAX;
    while (!q.empty()) {
      c[q.top().index] = max(c[q.top().index], q.top().value);
      curmin = min(curmin, c[q.top().index]);
      q.pop();
    }

    minv = max(minv,curmin);
  }

  return minv;
}

int main() {

  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);

  int n, m;
  cin >> n >> m;

  for (int i = 0; i < n; ++i)
    cin >> a[i];

  for (int i = 0; i < n; ++i)
    cin >> b[i];
  
  cout << solve(n, m) << '\n';

  return 0;
}