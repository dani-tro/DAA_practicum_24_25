#include <iostream>
#include <queue>

using namespace std;
using llong = long long;

int const MAX = 3*1e5;

llong a[MAX+10], b[MAX+10];

struct Pair {
  llong value;
  int index;

  bool operator<(Pair const& other) const {
    return value > other.value;
  }
};

priority_queue<Pair> q;

llong solve(int n, int m) {
  for (llong i = 0; i < n*m; ++i) {
    Pair top = q.top();
    q.pop();
    top.value += max(a[top.index], b[top.index]);
    q.push(top);
  }

  return q.top().value;
}

int main() {

  int n;
  llong m;
  cin >> n >> m;

  for (int i = 0; i < n; ++i)
    cin >> a[i];

  for (int i = 0; i < n; ++i)
    cin >> b[i];

  for (int i = 0; i < n; ++i)
    q.push({0, i});

  cout << solve(n,m) << '\n';

  return 0;
}