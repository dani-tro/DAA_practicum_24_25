#include <bits/stdc++.h>

#define llong long long

const llong MAXN = 300000;

llong n, m;
llong lectures[MAXN], fifthFloor[MAXN];

bool check(llong k) {
    llong freeHours = m * n;
    for (int i = 0; i < n; ++i) {
        if (lectures[i] >= fifthFloor[i]) {
            llong lectureCount = k / lectures[i] + (k % lectures[i] != 0);
            if (lectureCount > m) {
                lectureCount = m;
                llong remaining = k - lectureCount * lectures[i];
                freeHours -= remaining / fifthFloor[i] + (remaining % fifthFloor[i] != 0);
            }
            freeHours -= lectureCount;
        } else {
            llong fifthCount = k / fifthFloor[i] + 1;
            freeHours -= fifthCount;
        }
        if (freeHours < 0) {
            return false;
        }
    }
    return freeHours >= 0;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    std::cin >> n >> m;

    for (size_t i = 0; i < n; ++i) {
        std::cin >> lectures[i];
    }

    for (size_t i = 0; i < n; ++i) {
        std::cin >> fifthFloor[i];
    }

    llong start = 0, end = LLONG_MAX;

    while (start <= end) {
        llong mid = (start + end) / 2;

        if (check(mid)) {
            start = mid + 1;
        } else {
            end = mid - 1;
        }
    }

    std::cout << end << std::endl;
}