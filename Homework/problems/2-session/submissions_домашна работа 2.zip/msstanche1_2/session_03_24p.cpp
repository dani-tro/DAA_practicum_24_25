#include <iostream>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;

long long N, M;
const size_t maxsize = 3e5;
long long a[maxsize];
long long b[maxsize];
long long passedLectures[maxsize];
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> N >> M;
	for (size_t i = 0; i < N; i++)
	{
		cin >> a[i];
	}
	for (size_t i = 0; i < N; i++)
	{
		cin >> b[i];
	}
	priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<pair<long long, int>>> pq;
	for (size_t i = 0; i < N; i++)
	{
		pq.push({ 0, i });
	}

	stack<pair<long long, int>> helpStack;

	for (size_t i = 0; i < N * M;)
	{
		pair<long long, int> minSubject = pq.top();
		pq.pop();
		if (passedLectures[minSubject.second] < M)
		{
			long long maxKnowledge = max(a[minSubject.second], b[minSubject.second]);
			long long lectures = min(M - passedLectures[minSubject.second], (pq.top().first - minSubject.first) / maxKnowledge + 1);
			minSubject.first += lectures * maxKnowledge;
			passedLectures[minSubject.second] += lectures;
			pq.push(minSubject);
			i += lectures;
		}
		else
		{
			while (passedLectures[pq.top().second] == M)
			{
				helpStack.push(pq.top());
				pq.pop();
			}
			long long knowledge = b[pq.top().second];
			long long lectures = min(M - passedLectures[pq.top().second], (pq.top().first - minSubject.first) / knowledge + 1);
			minSubject.first += lectures * knowledge;
			passedLectures[pq.top().second] += lectures;
			pq.push(minSubject);
			i += lectures;
		}
		if (!helpStack.empty())
		{
			pq.push(helpStack.top());
			helpStack.pop();
		}
	}

	while (!helpStack.empty())
	{
		pq.push(helpStack.top());
		helpStack.pop();
	}

	/*for (size_t i = 0; i < M; i++)
	{
		bool passedLectures[maxsize];
		for (size_t i = 0; i < N; i++)
		{
			passedLectures[i] = 0;
		}
		stack<pair<long long, int>> helpStack;
		for (size_t i = 0; i < N; i++)
		{
			pair<long long, int> minSubject = pq.top();
			pq.pop();
			if (passedLectures[minSubject.second] == 0)
			{
				minSubject.first += max(a[minSubject.second], b[minSubject.second]);
				passedLectures[minSubject.second] = 1;
				pq.push(minSubject);
			}
			else
			{
				while (passedLectures[pq.top().second] == 1)
				{
					helpStack.push(pq.top());
					pq.pop();
				}
				minSubject.first += b[minSubject.second];
				passedLectures[pq.top().second] = 1;
				pq.push(minSubject);
			}
			if (!helpStack.empty())
			{
				pq.push(helpStack.top());
				helpStack.pop();
			}
		}
		while(!helpStack.empty())
		{
			pq.push(helpStack.top());
			helpStack.pop();
		}
	}
	*/
	/*
	3 3
	19 4 5
	2 6 2

	4 25
	1 2 3 4
	1 2 3 4
	*/
	cout << pq.top().first << endl;
	return 0;
}