#include <iostream>

using namespace std;

long long N, M;
const size_t maxsize = 3e5;
long long a[maxsize];
long long b[maxsize];

bool possibleMinKnowledge(long long K)
{
	long long lectures = 0;
	long long maxKnowledge, neededLectures, remainingKnowledge;
	for (size_t i = 0; i < N; ++i)
	{
		maxKnowledge = max(a[i], b[i]);
		neededLectures = K / maxKnowledge;
		if(K % maxKnowledge != 0)
			++neededLectures;
		if (neededLectures <= M)
		{
			lectures += M - neededLectures;
		}
		else
		{
			remainingKnowledge = K - M * maxKnowledge;
			lectures -= remainingKnowledge / b[i];
			if (remainingKnowledge % b[i] != 0)
				--lectures;
		}
	}
	return lectures >= 0;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> N >> M;
	for (size_t i = 0; i < N; i++)
	{
		cin >> a[i];
	}
	for (size_t i = 0; i < N; i++)
	{
		cin >> b[i];
	}

	long long left = 1, right = 1e18 + 20;
	while (left + 1 < right)
	{
		long long mid = (left + right) / 2;
		if (possibleMinKnowledge(mid))
		{
			left = mid;
		}
		else
		{
			right = mid;
		}
	}
	cout << left << endl;
	return 0;
	/*
	3 3
	19 4 5
	2 6 2

	2 1
	9 7
	2 6

	4 25
	1 2 3 4
	1 2 3 4
	*/
}