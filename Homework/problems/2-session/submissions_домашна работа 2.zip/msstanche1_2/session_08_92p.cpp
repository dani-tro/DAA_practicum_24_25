#include <iostream>

using namespace std;

long long N, M;
const size_t maxsize = 3e5;
long long a[maxsize];
long long b[maxsize];

bool possibleMinKnowledge(long long K)
{
	long long remainingLectures = 0;
	long long remainingNeededLectures = 0;
	for (size_t i = 0; i < N; i++)
	{
		long long maxKnowledge = max(a[i], b[i]);
		long long neededLecturesWithMaxKnowledge = K / maxKnowledge;
		if(K % maxKnowledge != 0)
			++neededLecturesWithMaxKnowledge;
		if (neededLecturesWithMaxKnowledge <= M)
		{
			remainingLectures += M - neededLecturesWithMaxKnowledge;
		}
		else
		{
			long long remainingKnowledge = K - M * maxKnowledge;
			remainingNeededLectures += remainingKnowledge / b[i];
			if (remainingKnowledge % b[i] != 0)
				++remainingNeededLectures;
		}
	}
	return remainingLectures >= remainingNeededLectures;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> N >> M;
	for (size_t i = 0; i < N; i++)
	{
		cin >> a[i];
	}
	for (size_t i = 0; i < N; i++)
	{
		cin >> b[i];
	}

	long long left = 1, right = 1e18;
	
	while (left + 1 < right)
	{
		long long mid = (left + right) / 2;
		if (possibleMinKnowledge(mid))
		{
			left = mid;
		}
		else
		{
			right = mid - 1;
		}
	}
	if (possibleMinKnowledge(left + 1))
	{
		cout << left + 1 << endl;
	}
	else
	{
		cout << left << endl;
	}
	/*
	3 3
	19 4 5
	2 6 2

	2 1
	9 7
	2 6

	4 25
	1 2 3 4
	1 2 3 4
	*/
	return 0;
}