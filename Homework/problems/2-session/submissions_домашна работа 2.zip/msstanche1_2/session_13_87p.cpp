#include <iostream>

using namespace std;

long long N, M;
const size_t maxsize = 3e5;
long long a[maxsize];
long long b[maxsize];

bool possibleMinKnowledge(long long K)
{
	long long lectures = 0;
	long long neededLectures, remainingKnowledge;
	for (size_t i = 0; i < N; ++i)
	{
		if (b[i] >= a[i])
		{
			neededLectures = K / b[i];
			if (K % b[i] != 0)
				++neededLectures;
			if (neededLectures <= M)
			{
				lectures += M - neededLectures;
			}
			else
			{
				lectures -= neededLectures - M;
			}
		}
		else
		{
			neededLectures = K / a[i];
			if (K % a[i] != 0)
				++neededLectures;
			if (neededLectures <= M)
			{
				lectures += M - neededLectures;
			}
			else
			{
				remainingKnowledge = K - M * a[i];
				lectures -= remainingKnowledge / b[i];
				if (remainingKnowledge % b[i] != 0)
					--lectures;
			}
		}
	}
	return lectures >= 0;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> N >> M;
	for (size_t i = 0; i < N; i++)
	{
		cin >> a[i];
	}
	for (size_t i = 0; i < N; i++)
	{
		cin >> b[i];
	}

	long long left = 1, right = 8e18 + 20;
	while (left + 1 < right)
	{
		long long mid = (left + right) / 2;
		if (possibleMinKnowledge(mid))
		{
			left = mid;
		}
		else
		{
			right = mid - 1;
		}
	}
	if (possibleMinKnowledge(left + 1))
		cout << left + 1 << endl;
	else
		cout << left << endl;
	return 0;
	/*
	3 3
	19 4 5
	2 6 2

	2 1
	9 7
	2 6

	4 25
	1 2 3 4
	1 2 3 4
	*/
}