#include <iostream>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;

long long N, M;
const size_t maxsize = 3e5;
long long a[maxsize];
long long b[maxsize];
long long passedLectures[maxsize];
long long knowledge[maxsize];

bool possibleMinKnowledge(long long K)
{
	for (size_t i = 0; i < N; i++)
	{
		long long maxKnowledge = max(a[i], b[i]);
		long long neededLectures = 0;
		if (K % maxKnowledge == 0)
			neededLectures = K / maxKnowledge;
		else
			neededLectures = K / maxKnowledge + 1;
		long long lectures = min(M, neededLectures);
		passedLectures[i] = lectures;
		knowledge[i] = lectures * maxKnowledge;
	}
	long long moreLectures = 0;
	for (size_t i = 0; i < N; i++)
	{
		while (knowledge[i] < K)
		{
			while (moreLectures < N && passedLectures[moreLectures] >= M)
				++moreLectures;
			if (moreLectures == N)
				return false;
			long long neededLectures = 0;
			if ((K - knowledge[i]) % b[moreLectures] == 0)
				neededLectures = (K - knowledge[i]) / b[moreLectures];
			else
				neededLectures = (K - knowledge[i]) / b[moreLectures] + 1;
			long long lectures = min(M - passedLectures[moreLectures], neededLectures);
			knowledge[i] += lectures * b[i];
			passedLectures[moreLectures] += lectures;
		}
	}
	return true;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> N >> M;
	for (size_t i = 0; i < N; i++)
	{
		cin >> a[i];
	}
	for (size_t i = 0; i < N; i++)
	{
		cin >> b[i];
	}

	long long left = 1, right = 1e18;
	
	while (left + 1 < right)
	{
		long long mid = (left + right) / 2;
		if (possibleMinKnowledge(mid))
		{
			left = mid;
		}
		else
		{
			right = mid - 1;
		}
	}
	if (possibleMinKnowledge(left + 1))
	{
		cout << left + 1 << endl;
	}
	else
	{
		cout << left << endl;
	}
	/*
	3 3
	19 4 5
	2 6 2

	21
	97
	26

	4 25
	1 2 3 4
	1 2 3 4
	*/
	return 0;
}