#include <iostream>
#include <algorithm>
#include <queue>

using namespace std;

long long N, M;
const size_t maxsize = 3e5;
long long a[maxsize];
long long b[maxsize];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> N >> M;
	for (size_t i = 0; i < N; i++)
	{
		cin >> a[i];
	}
	for (size_t i = 0; i < N; i++)
	{
		cin >> b[i];
	}
	priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<pair<long long, int>>> pq;
	for (size_t i = 0; i < N; i++)
	{
		pq.push({ 0, i });
	}
	for (size_t i = 0; i < M; i++)
	{
		bool passedLectures[maxsize];
		for (size_t i = 0; i < N; i++)
		{
			passedLectures[i] = 0;
		}
		for (size_t i = 0; i < N; i++)
		{
			pair<long long, int> minSubject = pq.top();
			pq.pop();
			if (passedLectures[minSubject.second] == 0)
			{
				minSubject.first += max(a[minSubject.second], b[minSubject.second]);
				passedLectures[minSubject.second] = 1;
				pq.push(minSubject);
			}
			else
			{
				queue<pair<long long, int>> helpQueue;
				while (passedLectures[pq.top().second] == 1)
				{
					helpQueue.push(pq.top());
					pq.pop();
				}
				minSubject.first += b[minSubject.second];
				passedLectures[pq.top().second] = 1;
				pq.push(minSubject);
				while (!helpQueue.empty())
				{
					pq.push(helpQueue.front());
					helpQueue.pop();
				}
			}
		}
	}
	/*
	3 3
	19 4 5
	2 6 2

	4 25
	1 2 3 4
	1 2 3 4
	*/
	cout << pq.top().first << endl;
	return 0;
}