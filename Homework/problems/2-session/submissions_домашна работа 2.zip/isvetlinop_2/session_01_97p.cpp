#include <bits/stdc++.h>

#define ull unsigned long long

const int MAXN = 3e5 + 2;

int a[MAXN], b[MAXN];

bool can(ull tar, ull n, ull m)
{
    ull needed = 0;
    for(int i = 0; i < n && needed <= n * m; ++ i)
    {
        if(b[i] >= a[i])
        {
            needed += (tar + b[i] - 1) / b[i];
            continue;
        }
        ull neededLect = (tar + a[i] - 1) / a[i];
        if(neededLect <= m)
        {
            needed += neededLect;
            continue;
        }
        needed += m + (tar - m * a[i] + b[i] - 1) / b[i];
    }

    return needed <= n * m;
}

int main()
{
    ull n, m;
    std::cin >> n >> m;

    for(int i = 0; i < n; ++ i)
    {
        std::cin >> a[i];
    }
    for(int i = 0; i < n; ++ i)
    {
        std::cin >> b[i];
    }

    ull l = 0, r = 2e18;

    while(l < r - 1)
    {
        ull mid = (l + r) / 2;
        if(can(mid, n, m))
        {
            l = mid;
        }else
        {
            r = mid;
        }
    }

    std::cout << l << '\n';

    return 0;
}