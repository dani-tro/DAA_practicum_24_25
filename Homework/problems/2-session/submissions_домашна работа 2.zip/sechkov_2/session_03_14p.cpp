#include <bits/stdc++.h>
using namespace std;

// M = 1
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    int n, m, min;
    min = 1e9 + 10;
    
    cin >> n >> m;
    vector<int> a;
    vector<int> b;
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a.push_back(x);
    }
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        b.push_back(x);
    }
    
    for (int i = 0; i < n; i++) {
        int m = 0;
        if (a[i] > b[i]) {
            m = a[i];
        } else {
            m = b[i];
        }
        
        if (min > m) {
            min = m;
        }
    }
    
    cout << min;

    return 0;
}