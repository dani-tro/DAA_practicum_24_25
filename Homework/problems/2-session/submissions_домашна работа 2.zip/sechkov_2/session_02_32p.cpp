#include <bits/stdc++.h>
using namespace std;


//𝑁.𝑀 ≤ 3.105 && 𝑎𝑖 = 𝑏 i
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    int n, m;
    
    cin >> n >> m;
    vector<int> a;
    vector<int> b;
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a.push_back(x);
    }
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        b.push_back(x);
    }
    
    if (m == 1) {
        int min = 1e9 + 10;
        for (int i = 0; i < n; i++) {
            int m = 0;
            if (a[i] > b[i]) {
                m = a[i];
            } else {
                m = b[i];
            }
        
            if (min > m) {
                min = m;
            }
        }
        cout << min;
        return 0;
    }
    
    priority_queue<pair<int, int>> p;
    
    for (int i = 0; i < n; i++) {
        p.push({-a[i], i});
    }
    
    for (int j = 1; j < m; j++) {
        for (int i = 0; i < n; i++) {
            pair<int, int> x = p.top();
            p.pop();
            p.push({x.first - a[x.second], x.second});
        }
    }
    
    cout << -p.top().first;

    return 0;
}