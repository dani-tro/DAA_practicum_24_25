#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    int n, m, min, max;
    min = 1e9 + 10;
    max = 0;
    
    cin >> n >> m;
    int* a = new int[n];
    vector<int> b;
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a[i] = x;
        if (min > x) {
            min = x;
        }
        if (max < x) {
            max = x;
        }
    }
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        b.push_back(x);
    }
    
    int l = min;
    int r = (n * (m - 1) + 1) * max;
    int slots = n * m;
    int opt = 0;
    
    while (l <= r) {
        int k = (l + r) / 2;
        int count = 0;
        for (int i = 0; i < n; i++) {
            count += k / a[i];
            if (k % a[i] > 0) {
                count += 1;
            }
        }
        if (count > slots) {
            r = k - 1;
        } else {
            opt = k;
            l = k + 1;
        }
    }
    
    cout << opt;
    
    delete [] a;
    
    return 0;
}