#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    int n, m;
    
    cin >> n >> m;
    int* a = new int[n];
    vector<int> b;
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a[i] = x;
    }
    
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        b.push_back(x);
    }
    
    sort(a, a + n);
    
    int l = a[0];
    int r = (n * (m - 1) + 1) * a[0];
    int opt = 0;
    
    while (l <= r) {
        int mid = (l + r) / 2;
        int slots = (n * m) - (mid / a[0]);
        int count = 0;
        for (int i = 1; i < n; i++) {
            count += mid / a[i];
            if (mid % a[i] > 0) {
                count += 1;
            }
        }
        if (count > slots) {
            r = mid - a[0];
        } else {
            opt = mid;
            l = mid + a[0];
        }
    }
    
    cout << opt;
    
    delete [] a;
    
    return 0;
}