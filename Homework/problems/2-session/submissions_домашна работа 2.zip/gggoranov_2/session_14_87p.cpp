#include <bits/stdc++.h>
using namespace std;


const long long MAXN = 3e6 + 3;
long long n, m, a[MAXN], b[MAXN];


bool check(long long k){
    __int128 hrs_left = (__int128)n * m, res;
    for(int i = 1; i <= n; ++i){
        if(k < m * a[i]){
            res = min(ceil(double(k) / double(b[i])), ceil(double(k)/ double(a[i])));
            cout << "";
        }
        else {
            res = min(ceil(double(k) / double(b[i])), ceil(double(k - m * a[i]) / double(b[i])) + m);
        }
        hrs_left -= res;
        if(hrs_left < 0) return false;
    }

    return true;
}


int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
    }
    for(int i = 1; i <= n; ++i){
        cin >> b[i];
    }

    long long l = 0, r = (long long)1e18 + 3, mid;
    while(l < r){
        mid = l + (r - l + 1) / 2;
        if(check(mid))l = mid;
        else
            r = mid - 1;
    }

    cout << l << endl;
}