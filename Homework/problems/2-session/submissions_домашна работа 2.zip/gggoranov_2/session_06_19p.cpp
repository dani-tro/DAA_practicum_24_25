#include <bits/stdc++.h>
using namespace std;


const long long MAXN = 3e6 + 3;
long long n, m, a[MAXN], b[MAXN];


bool check(long long k){
    long long hrs_left = n * m, res;
    for(int i = 1; i <= n; ++i){
        if(k < m * a[i]){
            res = min(ceil(float(k) / float(b[i])), ceil(float(k)/ float(a[i])));
            cout << "";
        }
        else {
            res = min(ceil(float(k) / float(b[i])), ceil(float(k - m * a[i]) / float(b[i])) + m);
        }
        hrs_left -= res;
        if(hrs_left < 0) return false;
    }
    if(hrs_left < 0) return false;
    return true;
}


int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
    }
    for(int i = 1; i <= n; ++i){
        cin >> b[i];
    }

    long long l = 0, r = 1e9 + 3, mid;
    while(l < r){
        mid = (l+r)/2;
        if(check(mid))l = mid;
        else
            r = mid;
        if(r - l == 1){
            if(check(r)) l = r;
            else r = l;
        }
    }

    cout << l << endl;
}