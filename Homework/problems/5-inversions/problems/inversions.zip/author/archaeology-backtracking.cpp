#include <iostream>
using namespace std;

int Rec(int n, int l, int r)
{
    if (r < 0 or l > n * (n - 1) / 2) return 0;
    if (n == 1) return 1;

    int ans = 0;
    for (int i = 0; i < n; ++ i)
    {
        ans += Rec(n - 1, l - i, r - i);
    }

    return ans;
}

int main()
{
    int n, l, r;
    cin >> n >> l >> r;
    cout << Rec(n, l, r) << endl;
    return 0;
}

