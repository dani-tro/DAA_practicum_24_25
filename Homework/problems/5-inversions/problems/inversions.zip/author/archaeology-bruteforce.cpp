#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int main()
{
    int n, l, r;
    cin >> n >> l >> r;

    vector<int> v;
    for (int i = 1; i <= n; ++ i)
    {
        v.push_back(i);
    }

    int ans = 0;
    do
    {
        int cnt = 0;
        for (int i = 0; i < n; ++ i)
        {
            for (int j = i + 1; j < n; ++ j)
            {
                if (v[i] > v[j]) cnt++;
            }
        }
        if (cnt >= l and cnt <= r) ans++;
    }
    while (next_permutation(v.begin(), v.end()));

    cout << ans << endl;
    return 0;
}
