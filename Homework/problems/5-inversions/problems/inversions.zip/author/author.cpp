#include <iostream>
using namespace std;

const int MAXN = 502;
const int MOD = 1000000007;

int n, l, r;
int dp[2][MAXN * MAXN];
int pr[2][MAXN * MAXN];

void calc()
{
    for (int i = 1; i <= n; ++ i)
    {
        dp[i & 1][0] = pr[i & 1][0] = 1;
        for (int j = 1; j <= i * (i - 1) / 2; ++ j)
        {
            int val = pr[(i & 1) ^ 1][j];
            if (j >= i) val -= pr[(i & 1) ^ 1][j - i];
            if (val < 0) val += MOD;

            dp[i & 1][j] = val;
            pr[i & 1][j] = (pr[i & 1][j - 1] + val) % MOD;

        }
        for (int j = i * (i - 1) / 2 + 1; j <= n * (n - 1) / 2; ++ j)
        {
            pr[i & 1][j] = pr[i & 1][j - 1];
        }
    }
}

int main()
{
    cin >> n >> l >> r;

    calc();

    int ans = 0;
    for (int i = l; i <= r; ++ i)
    {
        ans = (ans + dp[n & 1][i]) % MOD;
    }

    cout << ans << endl;
    return 0;
}

