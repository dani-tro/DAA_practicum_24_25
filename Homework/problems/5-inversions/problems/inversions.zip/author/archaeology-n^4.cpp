#include <iostream>
using namespace std;

const int MAXN = 102;
const int MOD = 1000000007;

int n, l, r;
int dp[MAXN][MAXN * MAXN];

void calc()
{
    for (int i = 1; i <= n; ++ i)
    {
        dp[i][0] = 1;
        for (int j = 1; j <= i * (i - 1) / 2; ++ j)
        {
            for (int k = 0; k < i; ++ k)
            {
                if (j >= k)
                {
                    dp[i][j] += dp[i - 1][j - k];
                    dp[i][j] %= MOD;
                }
            }
        }
    }
}

int main()
{
    cin >> n >> l >> r;

    calc();

    int ans = 0;
    for (int i = l; i <= r; ++ i)
    {
        ans = (ans + dp[n][i]) % MOD;
    }

    cout << ans << endl;
    return 0;
}

