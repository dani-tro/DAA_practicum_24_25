#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int config[14][3] =
{
/* 01 */ {1, 0, 0},
/* 02 */ {5, 3, 4},
/* 03 */ {6, 0, 15},
/* 04 */ {9, 8, 32},
/* 05 */ {10, 23, 45},
/* 06 */ {15, 2, 10},
/* 07 */ {18, 144, 151},
/* 08 */ {19, 1, 9},
/* 09 */ {20, 180, 187},
/* 10 */ {56, 420, 1200},
/* 11 */ {78, 1000, 3000},
/* 12 */ {99, 256, 4595},
/* 13 */ {300, 31863, 43047},
/* 14 */ {500, 6896, 62574}
};

int main()
{
    for (int i = 1; i <= 14; ++ i)
    {
        string no = "  ";
        no[0] = i / 10 + 48;
        no[1] = i % 10 + 48;

        ofstream test("archaeology." + no + ".in");
        test << config[i - 1][0] << ' ' << config[i - 1][1] << ' ' << config[i - 1][2] << endl;
        test.close();

        string comm = "..\\author\\author.exe < archaeology." + no + ".in > archaeology." + no + ".sol";
        cout << comm << endl;
        system(comm.c_str());
    }
}
