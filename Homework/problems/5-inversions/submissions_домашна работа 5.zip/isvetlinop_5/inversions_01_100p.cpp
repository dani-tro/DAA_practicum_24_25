#include <iostream>

const int MAXN = 512;
const long long mod = 1e9 + 7;

long long dp[MAXN][MAXN * MAXN];

int main()
{
    int n, l, r;
    std:: cin >> n >> l >> r;
    dp[1][0] = 1;
    dp[2][0] = 1;
    dp[2][1] = 1;
    dp[3][0] = 1;
    dp[3][1] = 2;
    dp[3][2] = 2;
    dp[3][3] = 1;

    for(int i = 4; i <= n; ++ i)
    {
        dp[i][0] = 1;
        for(int j = 1; j < i; ++ j)
        {
            dp[i][j] = (dp[i][j - 1] + dp[i - 1][j]) % mod;
            //std::cout << dp[i][j] << ' ';
        }
        for(int j = i; j <= (i * (i - 1)) / 2; ++ j)
        {
            dp[i][j] = (mod + dp[i][j - 1] + dp [i - 1][j] - dp[i - 1][j - i]) % mod;
            //std::cout << dp[i][j] << ' ';
        }
        //std::cout << '\n';
    }

    long long ans = 0;
    for(int i = l; i <= r; ++ i)
    {
        ans += dp[n][i];
        ans %= mod;
    }

    std::cout << ans << '\n';

    return 0;
}