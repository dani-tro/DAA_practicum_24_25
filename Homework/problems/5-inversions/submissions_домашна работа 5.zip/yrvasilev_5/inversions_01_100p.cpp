#include<iostream>
#include<string>
#include<cstdio>
#include<cmath>
#include<stack>
#include<algorithm>
using namespace std;
int n,m, l, r, t1, t2;
long long a[150000], b[150000], sum;
const long long MOD=1000000007;
int main (){
    int i,j=0;
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin>>n>>l>>r;
    a[0]=1;
    for(i=2;i<=n;i++){
        sum=0; t1=min(r+1,i);
        t2=min(r,i*(i-1)/2);
        //cout<<"i="<<i<<" t1="<<t1<<" t2="<<t2<<endl;
        for(j=0; j<t1; j++){
            sum=(sum+a[j])%MOD;
            b[j]=sum;
        }
        for(j=t1;j<=t2; j++){
            sum=(sum+a[j]-a[j-i]+MOD)%MOD;
            b[j]=sum;
        }
        for(j=0;j<=t2;j++) a[j]=b[j]; 
        // for(j=0;j<=t2;j++) {a[j]=b[j]; cout<<b[j]<<" "; }
        // cout<<endl;
    }

    sum=0;
    for(i=l;i<=r;i++) sum=(sum+a[i])%MOD;
    cout<<sum<<endl;
    // for(int i=0;i<n;i++) printf("%lld ",a[i]); cout<<endl;
    
    return 0;
}

/*
10
4 2 5 1 6 3 5 2 1 5

10
5 2 1 5 4 2 5 1 6 3

10
1 6 3 5 2 1 5 4 2 5

b
*/


