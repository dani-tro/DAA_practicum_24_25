#include <bits/stdc++.h>
using namespace std;


const int MAXN = 505;
long long n, l, r, dp[MAXN][MAXN];


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> l >> r;
    for(int j = 2; j <= n; ++j){
        dp[1][j] = j - 1;
    }

    for(int i = 2; i <= n; ++i){
        for(int j = i+1; j <= n; ++j){
            dp[i][j] = (dp[i-1][j-1] + 1 + dp[i][j-1]) % long(1e9 + 7);
        }
    }

    long long ans = 0;
    for(int i = l; i <= r; ++i){
        ans += dp[i][n];
    }

    cout << ans << endl;

    return 0;
}