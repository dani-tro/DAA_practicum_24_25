#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const ll MOD = 1000000007;
const ll MAXN = 500;
const ll MAXR = MAXN * (MAXN - 1) / 2;   

ll dp[MAXN + 1][MAXR + 1];  
ll pref[MAXR + 1]; 

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll N, L, R;
    if (!(cin >> N >> L >> R)) return 0;

    dp[0][0] = 1;                 

    for (ll i = 1; i <= N; ++i) {
        pref[0] = dp[i - 1][0];
        for (ll j = 1; j <= R; ++j)
            pref[j] = (pref[j - 1] + dp[i - 1][j]) % MOD;

        for (ll j = 0; j <= R; ++j) {
            ll lo = j - i;            
            ll val = pref[j];
            if (lo >= 0) {
                val -= pref[lo];
                if (val < 0) 
                    val += MOD;
            }
            dp[i][j] = val;
        }
    }

    ll bigdick = 0;
    for (ll j = L; j <= R; ++j) {
        bigdick += dp[N][j];
        if (bigdick >= MOD) 
            bigdick -= MOD;
    }
    cout << bigdick;
    return 0;
}
