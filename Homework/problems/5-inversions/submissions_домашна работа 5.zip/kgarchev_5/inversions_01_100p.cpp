#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 500;
const int MOD = 1e9 + 7;

#define UPPER(x) (((x) * ((x) - 1)) >> 1)

int n, l, r;
int dp[2][UPPER(MAX_N) + 1];


int solve()
{
    int upper;
    dp[1][0] = 1;
    int fact = 1;
    for(int t = 2; t <= n; ++t)
    {
        upper = min(UPPER(t), r);
        dp[t & 1][0] = 1;
        for(int i = 1; i <= upper; ++i)
        {
            // dp[t & 1][i] = sum(dp[(t - 1) & 1][j], max(i - (t - 1), 0) <= j <= i) // # of perms with j inversions
            // dp[t & 1][i] = dp[t & 1][i - 1] + (i <= UPPER(t - 1) ? dp[(t - 1) & 1][i] : fact(t - 1)) - (i >= t ? dp[(t - 1) & 1][i - t] : 0) // # of perms with <= j inversions
            dp[t & 1][i] = (dp[t & 1][i - 1] + (i <= UPPER(t - 1) ? dp[(t - 1) & 1][i] : fact)) % MOD;
            dp[t & 1][i] = i >= t ? (dp[t & 1][i] + MOD - dp[(t - 1) & 1][i - t]) % MOD : dp[t & 1][i];
        }

        fact = 1LL * fact * t % MOD;
    }

    int res = dp[n & 1][r];
    res = l - 1 >= 0 ? (res + MOD - dp[n & 1][l - 1]) % MOD : res;
    return res;
}


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    cin >>n >>l >>r;
    cout <<solve() <<endl;
}
