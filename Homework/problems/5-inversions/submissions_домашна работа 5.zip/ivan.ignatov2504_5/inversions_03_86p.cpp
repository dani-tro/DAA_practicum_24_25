#include <bits/stdc++.h>

#define llong long long

const int MAXN = 500;
const int MAXK = 200e3;
const llong MOD = 1e9 + 7;

llong dp[MAXN][MAXK];
llong n, l, r;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    std::cin >> n >> l >> r;

    dp[0][0] = 1;

    for (llong i = 1; i <= n; ++i) {
        for (llong j = 0; j <= r; ++j) {
            for (llong k = 0; k <= j && k <= i - 1; ++k) {
                dp[i][j] = (dp[i][j] + dp[i - 1][j - k]) % MOD;
            }
        }
    }

    llong res = 0;
    for (llong i = l; i <= r; ++i) {
        res = (res + dp[n][i]) % MOD;
    }

    std::cout << res << std::endl;
}