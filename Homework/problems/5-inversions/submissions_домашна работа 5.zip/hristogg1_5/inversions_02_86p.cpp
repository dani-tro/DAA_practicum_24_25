#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;
const int MAX_N = 500;
const int MAX_INV = MAX_N * (MAX_N - 1) / 2;

int dp[MAX_N + 1][MAX_INV + 1];
int prefix[MAX_N + 1][MAX_INV + 2];

int N, L, R;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> L >> R;

    dp[0][0] = 1;
    prefix[0][0] = 1;
    for (int j = 1; j <= MAX_INV; ++j)
        prefix[0][j] = (prefix[0][j - 1] + dp[0][j]) % MOD;

    for (int n = 1; n <= N; ++n) {
        for (int inv = 0; inv <= MAX_INV; ++inv) {
            dp[n][inv] = prefix[n - 1][inv];
            if (inv >= n)
                dp[n][inv] = (dp[n][inv] - prefix[n - 1][inv - n] + MOD) % MOD;
        }

        prefix[n][0] = dp[n][0];
        for (int j = 1; j <= MAX_INV; ++j)
            prefix[n][j] = (prefix[n][j - 1] + dp[n][j]) % MOD;
    }

    int result = 0;
    for (int i = L; i <= R && i <= MAX_INV; ++i)
        result = (result + dp[N][i]) % MOD;

    cout << result << "\n";
    return 0;
}
