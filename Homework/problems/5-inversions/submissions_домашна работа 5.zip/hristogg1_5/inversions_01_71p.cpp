#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;
const int MAX_N = 500;
const int MAX_INV = MAX_N * (MAX_N - 1) / 2;

int dp[MAX_N + 1][MAX_INV + 1];

int N, L, R;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> L >> R;

    dp[0][0] = 1;

    for (int n = 1; n <= N; ++n) {
        for (int inv = 0; inv <= MAX_INV; ++inv) {
            dp[n][inv] = 0;
            for (int k = 0; k <= n - 1; ++k) {
                if (inv >= k)
                    dp[n][inv] = (dp[n][inv] + dp[n - 1][inv - k]) % MOD;
            }
        }
    }

    int result = 0;
    for (int i = L; i <= R && i <= MAX_INV; ++i) {
        result = (result + dp[N][i]) % MOD;
    }

    cout << result << "\n";
    return 0;
}
