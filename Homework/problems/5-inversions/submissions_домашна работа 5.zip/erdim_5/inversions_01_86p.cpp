#include <bits/stdc++.h>
using namespace std;

const int MAXN = 501;
long long dp[MAXN][MAXN * MAXN / 2];
const int MOD = 1e9 + 7;

int main()
{
    int n, l, r;
    cin >> n >> l >> r;
    dp[1][0] = 1;
    for (int i = 2; i <= n; i++)
    {
        for (int j = 0; j <= r; j++)
        {
            for (int t = 0; t <= min(j, i - 1); t++)
            {
                dp[i][j] = (dp[i][j] + dp[i - 1][j - t]) % MOD;
            }
        }
    }

    long long ans = 0;
    for (int i = l; i <= r; i++)
    {
        ans = (ans + dp[n][i]) % MOD;
    }

    cout << ans << endl;

    return 0;
}