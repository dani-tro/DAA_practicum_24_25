#include <bits/stdc++.h>
using namespace std;

const int MAXN = 501;
long long dp[MAXN][MAXN * MAXN / 2];
long long pref[MAXN][MAXN * MAXN / 2];
const int MOD = 1e9 + 7;

int main()
{
    int n, l, r;
    cin >> n >> l >> r;
    dp[1][0] = 1;
    for (int j = 0; j <= r; j++)
        pref[1][j] = 1;

    for (int i = 2; i <= n; i++)
    {
        for (int j = 0; j <= r; j++)
        {
            int t = min(j, i - 1);
            if (j <= i - 1)
                dp[i][j] = pref[i - 1][j];
            else
                dp[i][j] = (pref[i - 1][j] - pref[i - 1][j - i] + MOD) % MOD;

            if (j > 0)
                pref[i][j] = (pref[i][j - 1] + dp[i][j]) % MOD;
            else
                pref[i][j] = dp[i][j];
        }
    }

    long long ans = 0;
    for (int i = l; i <= r; i++)
    {
        ans = (ans + dp[n][i]) % MOD;
    }

    cout << ans << endl;

    return 0;
}