#include <iostream>
#include <climits>

using namespace std;
const int MOD = 1e9 + 7;
const int maxn = 505;
long long dp[maxn][maxn * maxn / 2];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int n, l, r;
	cin >> n >> l >> r;
	for (size_t i = 1; i <= n; i++)
	{
		dp[i][0] = 1;
	}
	for (int i = 2; i <= n; i++)
	{
		for (int j = 1; j <= r; j++)
		{
			dp[i][j] = (dp[i][j - 1] + dp[i - 1][j]) % MOD;
			if (i - j <= 0)
			{
				dp[i][j] = (dp[i][j] - dp[i - 1][j - i] + MOD) % MOD;
			}
			//dp[i][j] = dp[i][j] % MOD;
			/*for (int k = max(i - j, 1); k <= i; k++)
			{
				dp[i][j] = (dp[i][j] + dp[i - 1][j - (i - k)]) % MOD;
			}*/
		}
	}
	long long sum = 0;
	for (size_t j = l; j <= r; j++)
	{
		sum = (sum + dp[n][j]) % MOD;
	}
	cout << sum << endl;
	return 0;
}