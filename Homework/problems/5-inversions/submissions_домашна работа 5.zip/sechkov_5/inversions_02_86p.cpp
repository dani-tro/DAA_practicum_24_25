#include <bits/stdc++.h>
using namespace std;

const int maxN = 510;
const int maxR = 250010;
const int modulo = 1e9 + 7;

int dp[maxN][maxR];

int main() {
    
    int n, l, r;
    cin >> n >> l >> r;
    
    for (int i = 0; i <= n; i++) {
        dp[i][0] = 1;
    }
    
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= r; j++) {
            if (j > i * (i - 1) / 2) {
                break;
            }
            for (int k = 0; k <= i - 1; k++) {
                if (j - k < 0) continue;
                dp[i][j] += dp[i - 1][j - k];
                dp[i][j] %= modulo;
            }
        }
    }
    
    int res = 0;
    
    for (int i = l; i <= r; i++) {
        res += dp[n][i];
        res %= modulo;
    }
    
    cout << res;
    
    return 0;
}