#include <vector>
#include <iostream>
#include <cmath>

using namespace std;

const int MOD = 1000000007;

int main() {
	int N, L, R;
	cin >> N >> L >> R;

	vector<vector<long long>> dp(N + 1, vector<long long>(R + 1, 0));
	for (int i = 1; i <= N; ++i) {
		dp[i][0] = 1;
	}

	for (int i = 2; i <= N; ++i) {
		for (int j = 1; j <= min(R, i*(i-1)/2); ++j) {
			dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
		}
	}

	long long res = 0;
	for (int j = L; j <= R; ++j) {
		res = (res + dp[N][j]) % MOD;
	}

	cout << res;

	return 0;
}