#include <iostream>
#include <vector>
using namespace std;

const int MOD = 1e9 + 7;

int main() {
    int N, L, R;
    cin >> N >> L >> R;

    int maxInv = N * (N - 1) / 2;
    vector<int> dp(maxInv + 1, 0);
    dp[0] = 1;  // 0 елемента -> само 1 начин с 0 инверсии

    for (int n = 1; n <= N; ++n) {
        vector<int> new_dp(maxInv + 1, 0);
        vector<int> prefix(maxInv + 2, 0);  // за префиксна сума

        // Изчисляваме префиксни суми на dp
        for (int i = 0; i <= maxInv; ++i) {
            prefix[i + 1] = (prefix[i] + dp[i]) % MOD;
        }

        for (int k = 0; k <= maxInv; ++k) {
            int left = max(0, k - (n - 1));
            int right = k;
            new_dp[k] = (prefix[right + 1] - prefix[left] + MOD) % MOD;
        }

        dp = new_dp;
    }

    int result = 0;
    for (int k = L; k <= R; ++k) {
        if (k <= maxInv)
            result = (result + dp[k]) % MOD;
    }

    cout << result << endl;
    return 0;
}
