#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 3e5;

struct building {
 int w, h;
};

struct rocket
{
    int x, y;

    inline bool operator< (const rocket other) const {
        return this->x <= other.x;
    }
};

int n, m;

building buildings[MAX_N + 1];
rocket rockets[MAX_N];


void readInput()
{
    cin >>n >>m;
    for(int i = 0; i < n; ++i)
    {
        cin >>buildings[i].w >>buildings[i].h;
    }
    for(int i = 0; i < m; ++i)
    {
        cin >>rockets[i].x >>rockets[i].y;
    }
}

void preprocess()
{
    for(int i = 1; i < n; ++i)
    {
        buildings[i].w += buildings[i - 1].w;
    }

    sort(rockets, rockets + m);
}

int calcHits()
{
    int ans = 0;
    int rId = 0;
    for(int bldId = 0; bldId < n; ++bldId)
    {
        for(; rId < m && rockets[rId].x < buildings[bldId].w; ++rId)
        {
            ans += rockets[rId].y <= buildings[bldId].h;
        }

        if(rId == m) break;
        for(; rId < m && rockets[rId].x == buildings[bldId].w; ++rId)
        {
            ans += rockets[rId].y <= max(buildings[bldId].h, bldId + 1 < n ? buildings[bldId + 1].h : INT_MIN);
        }
    }

    return ans;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    readInput();
    preprocess();
    cout <<calcHits() <<endl;
}
