#include<iostream>
#include<string>
#include<cstdio>
#include<cmath>
#include<stack>
#include<algorithm>

using namespace std;
int n,m, k, ans=0, h=-1, r=0, t=0, hmx;
pair <int, int> a[300005], b[300005];


int main (){
    int i,j=0;
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin>>n>>m;
    for(i=1;i<=n;i++) cin>>a[i].first>>a[i].second;
    for(i=1;i<=m;i++) cin>>b[i].first>>b[i].second;
    sort(b+1,b+m+1);
    for(i=1;i<=n;i++){
        //if(b[t].first==r && b[t].second>h && b[t].second<=a[i].second) ans++;//гранична, която не влиза в предния
        //cout<<i<<" ans="<<ans<<endl;
        r+=a[i].first;
        hmx=h=a[i].second;
        if(i<n && a[i+1].second>h)hmx=a[i+1].second;
        //cout<<"r="<<r<<" h="<<h<<endl;
        while(t<m && b[t+1].first<=r){
            t++;
            if(b[t].second<=h || (b[t].first==r && b[t].second<=hmx)) ans++;
        }
            //cout<<"t="<<t<<" x="<<b[t].first<<" y="<<b[t].second<<" ans="<<ans<<endl;
    }

    cout<<ans<<endl;
    // for(int i=0;i<n;i++) printf("%lld ",a[i]); cout<<endl;
    
    return 0;
}
/*
4 8
2 3
3 6
2 4
4 2
1 2
3 7
4 2
5 8
7 4
9 1
9 5
12 8
-4


4 8
2 3
3 6
2 4
4 2

9 5
12 8
4 2
1 2
3 7
5 8
7 4
9 1
-4

3 18
2 2
2 4
3 3
4 3
4 1
5 3
2 1
7 2
7 4
2 4
0 2
2 3
3 5
6 1
0 1
1 2
1 20
0 3
4 5
4 4
3 4

*/