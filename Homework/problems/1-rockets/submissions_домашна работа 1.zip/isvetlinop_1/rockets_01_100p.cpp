#include <bits/stdc++.h>

const int MAXN = 3e5 + 5;

std::pair<long long, int> skyscrapers[MAXN];

int binSearch(int x, int n)
{
    int l = -1, r = n;
    while(l < r - 1)
    {
        int mid = (l + r + 1) / 2;
        if(x <= skyscrapers[mid].first)
        {
            r = mid;
        }else
        {
            l = mid;
        }
    }

    return r;
}

int main()
{
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);

    int n, m;
    std::cin >> n >> m;
    std::cin >> skyscrapers[0].first >> skyscrapers[0].second;
    for(int i = 1; i < n; ++ i)
    {
        int h, w;
        std::cin >> w >> h;
        skyscrapers[i] = {skyscrapers[i - 1].first + w, h};
    }
    skyscrapers[n] = {skyscrapers[n - 1].first + 1, 0};

    int cnt = 0;
    while(m --)
    {
        int x, y;
        std::cin >> x >> y;
        int pos = binSearch(x, n);
        if(pos == n)
        {
            continue;
        }
        if(skyscrapers[pos].first == x)
        {
            cnt += (skyscrapers[pos].second >= y || skyscrapers[pos + 1].second >= y);
            continue;
        }
        cnt += skyscrapers[pos].second >= y;
    }

    std::cout << cnt << '\n';

    return 0;
}