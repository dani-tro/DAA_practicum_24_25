#include <iostream>
struct Building
{
	long long start;
	long long end;
	long long height;
};

struct Point
{
	long long x;
	long long y;
};

const size_t MAXSIZE = 300000;
Building builds[MAXSIZE];
Point rockets[MAXSIZE];

long long n, m;
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m;
	long long lastEnd = 0, currWidth;
	for (size_t i = 0; i < n; i++)
	{
		cin >> currWidth >> builds[i].height;
		builds[i].start = lastEnd;
		builds[i].end = lastEnd + currWidth;
		lastEnd = builds[i].end;
	}
	for (size_t i = 0; i < m; i++)
	{
		cin >> rockets[i].x >> rockets[i].y;
	}
	long long count = 0;
	for (size_t i = 0; i < m; i++)
	{
		long long left = 0, right = n - 1;
		while (left <= right)
		{
			long long mid = (left + right) / 2;
			if (builds[mid].start > rockets[i].x)
			{
				right = mid - 1;
			}
			else if (builds[mid].end < rockets[i].x)
			{
				left = mid + 1;
			}
			else
			{
				if (builds[mid].height >= rockets[i].y)
				{
					++count;
					break;
				}
				else if (mid > 0 && builds[mid - 1].height >= rockets[i].y)
				{
					++count;
					break;
				}
				else if (mid + 1 < n && builds[mid + 1].height >= rockets[i].y)
				{
					++count;
					break;
				}
			}
		}
	}
	cout << count << endl;
	return 0;
}