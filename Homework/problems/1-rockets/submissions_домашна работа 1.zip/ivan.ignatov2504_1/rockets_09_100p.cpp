#include <bits/stdc++.h>

#define llong long long
const llong MAXN = 300300;

llong rectStarts[MAXN], rectEnds[MAXN], rectHeights[MAXN];
llong n, m;

llong find(llong start, llong end, llong x) {
    llong mid;
    while (start < end) {
        mid = (start + end) / 2;
        llong rectStart = rectStarts[mid], rectEnd = rectEnds[mid];
        if (rectStart < x && rectEnd > x) {
            return rectHeights[mid];
        }
        if (rectStart == x) {
            return rectHeights[mid - 1] > rectHeights[mid] ? rectHeights[mid - 1] : rectHeights[mid];
        }
        if (rectEnd == x) {
            return rectHeights[mid + 1] > rectHeights[mid] ? rectHeights[mid + 1] : rectHeights[mid];
        }
        if (rectStart > x) {
            end = mid;
        } else {
            start = mid;
        }
    }
    return rectHeights[start];
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    llong currX = 0, wi, hi;
    std::cin >> n >> m;

    for (size_t i = 0; i < n; ++i) {
        std::cin >> wi >> hi;
        rectHeights[i] = hi;

        rectStarts[i] = currX;
        currX += wi;
        rectEnds[i] = currX;
    }

    llong xi, yi, counter = 0;
    for (size_t i = 0; i < m; ++i) {
        std::cin >> xi >> yi;
        if(xi > currX) continue;

        llong height = find(0, n, xi);
        if (height >= yi) counter++;
    }

    std::cout << counter << std::endl;
}