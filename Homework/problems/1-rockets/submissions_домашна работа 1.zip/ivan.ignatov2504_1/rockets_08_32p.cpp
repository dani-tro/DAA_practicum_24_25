#include <bits/stdc++.h>

#define llong long long

llong n, m;

struct Event {
    llong x;
    llong y;
    // -1 - increase
    // 0 - point
    // 1 - decrease
    llong type;
};

bool cmp(Event& e1, Event& e2) {
    if (e1.x == e2.x) {
        return e1.type <= e2.type;
    }
    return e1.x < e2.x;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    std::cin >> n >> m;

    std::vector<Event> events;

    llong currX = 0, currY = 0;

    for (size_t i = 0; i < n; ++i) {
        llong wi, hi;
        std::cin >> wi >> hi;

        llong type = hi > currY ? -1 : 1;
        events.push_back({currX, hi, type});
        currX += wi;
        currY = hi;
    }

    for (size_t i = 0; i < m; ++i) {
        llong xi, yi;
        std::cin >> xi >> yi;
        events.push_back({xi, yi, 0});
    }

    std::sort(events.begin(), events.end(), cmp);

    currY = 0;
    llong res = 0;
    for (size_t i = 0; i < events.size(); ++i) {
        Event e = events[i];

        if (e.type == 0) {
            if (currY >= e.y) {
                ++res;
            }
        } else { 
            currY = e.y;
        }
    }

    std::cout << res << std::endl;
}