#include <bits/stdc++.h>
using namespace std;

const int maxn = 300100;

struct building
{
    long long begin;
    long long end;
    long long height;
};

struct rocket
{
    long long x;
    long long y;

    bool operator<(const rocket& other) const
    {
        if (x < other.x) return true;
        return x == other.x && y < other.y;
    }
};

building b[maxn];
rocket r[maxn];

int n, m;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m;
    long long w, h;

    cin >> w >> h;
    b[0].begin = 0;
    b[0].end = w;
    b[0].height = h;

    for (int i = 1; i < n; i++)
    {
        cin >> w >> h;
        b[i].begin = b[i-1].end;
        b[i].end = b[i].begin + w;
        b[i].height = h;
    }

    for (int i = 0; i < m; i++)
    {
        cin >> w >> h;
        r[i].x = w;
        r[i].y = h;
    }

    sort(r, r+m);

    int i = 0, j = 0;
    int cnt = 0;

    while (i < m && j < n)
    {
        if (r[i].x >= b[j].begin && r[i].x <= b[j].end)
        {
            if (r[i].y <= b[j].height) cnt++;
            i++;
        }
        else
        {
            j++;
        }
    }

    cout << cnt << endl;
    return 0;
}