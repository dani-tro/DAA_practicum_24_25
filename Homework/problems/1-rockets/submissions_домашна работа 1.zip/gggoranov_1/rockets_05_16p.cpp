#include <bits/stdc++.h>
using namespace std;


const long long MAXN = 3e6 + 3;
long long n, m, w[MAXN], h[MAXN], x, y;


int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    for(int i = 1; i <= n; ++i){
        cin >> w[i] >> h[i];
        w[i] += w[i-1];
    }


    long long cnt = 0;
    for(int i = 1; i <= m; ++i){
        cin >> x >> y;
        long long l = 0, r = n, mid, p1, p2;
        // bool midpoint = false;
        // while(r - l > 1){
        //     mid = (l+r)/2;
        //     if(w[mid] < x){
        //         l = mid;
        //     }
        //     else if(w[mid] > x){
        //         r = mid;
        //     }
        //     if(w[mid] == x){
        //         if(h[mid] >= y)++cnt;
        //         if(h[mid+1] >= y)++cnt;
        //         midpoint = true;
        //         break;
        //     }
        // }
        // if((!midpoint) && h[r] >= y)++cnt;
        // midpoint = false;

        bool midpoint = false;
        while(l < r){
            mid = (l+r)/2;
            if(w[mid] < x){
                if(w[mid+1] > x){
                    p1 = mid;
                    p2 = mid + 1;
                    break;
                } else
                    l = mid+1;
            }
            else if(w[mid] == x){
                midpoint = true;
                p1 = mid;
                p2 = mid + 1;
                break;
            }
            else{
                if(w[mid-1] < x){
                    p1 = mid - 1;
                    p2 = mid;
                    break;
                }
                else
                    r = mid-1;
            }
        }
        if(midpoint){
            if(h[p1] >= y)++cnt;
            if(h[p2] >= y)++cnt;
        } else {
            if(h[p2] >= y)++cnt;
        }
        midpoint = false;
    }

    cout << cnt << endl;
}