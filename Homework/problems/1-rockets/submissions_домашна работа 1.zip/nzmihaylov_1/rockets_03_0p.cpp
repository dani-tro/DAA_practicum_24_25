#include <iostream>
#include <algorithm>

using namespace std;
using llong = long long;

int const MAX = 12*1e5;

struct Event {
  llong x, y;
  int type;

  bool operator<(Event const& other) const {
    if (x != other.x) return x < other.x;
    return type < other.type;
  }
};

Event events[MAX+10];

int solve(llong size) {
  llong rockets = 0;
  llong active = 0;
  llong ltop = -1, rtop = -1;
  for (llong i = 0; i < size; ++i) {
    Event const& event = events[i];
    if (event.type == -1) {
      active++;
      ltop = rtop;
      rtop = event.y;
    }
    else if (event.type == 1) {
      active--;
      ltop = -1;
    }
    else {
      if (active && event.y <= max(ltop, rtop)) rockets++;
    }
  }
  return rockets;
}

int main() {

  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);

  size_t n, m;
  cin >> n >> m;

  llong curx = 0;
  for (size_t i = 0; i < 2*n; i+=2) {
    llong x, y;
    cin >> x >> y;
    events[i] = {curx, y, -1};
    curx += x;
    events[i+1] = {curx, y, 1};
  }

  for (size_t i = 0; i < m; ++i) {
    llong x, y;
    cin >> x >> y;
    events[2*n+i] = {x, y, 0};
  } 

  sort(events,events+m+n);

  cout << solve(m+n) << '\n';

  return 0;
}