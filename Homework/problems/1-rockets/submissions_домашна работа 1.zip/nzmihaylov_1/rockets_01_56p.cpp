#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
using llong = long long;

struct Event {
  llong x, y;
  int type;

  bool operator<(Event const& other) const {
    if (x != other.x) return x < other.x;
    return type < other.type;
  }
};

int solve(vector<Event> const& events) {
  llong rockets = 0;
  llong active = 0;
  llong ltop = -1, rtop = -1;
  for (Event const& event : events) {
    if (event.type == -1) {
      active++;
      ltop = rtop;
      rtop = event.y;
    }
    else if (event.type == 1) {
      active--;
      ltop = -1;
    }
    else {
      if (active && event.y <= max(ltop, rtop)) rockets++;
    }
  }
  return rockets;
}

int main() {

  size_t n, m;
  cin >> n >> m;

  vector<Event> events;

  llong curx = 0;
  for (size_t i = 0; i < n; ++i) {
    llong x, y;
    cin >> x >> y;
    events.push_back({curx,y,-1});
    curx += x;
    events.push_back({curx, y, 1});
  }

  for (size_t i = 0; i < m; ++i) {
    llong x, y;
    cin >> x >> y;
    events.push_back({x, y, 0});
  }  

  sort(events.begin(), events.end());

  cout << solve(events) << '\n';

  return 0;
}