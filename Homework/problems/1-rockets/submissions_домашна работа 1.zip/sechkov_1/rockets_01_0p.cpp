#include <iostream>
#include <vector>
using namespace std;

int main()
{
    long long n, m;
    vector<pair<int, int>> build;
    vector<pair<int, int>> rockets;
    
    cin >> n >> m;
    
    for (int i = 0; i < n; i++) {
        long long x, y;
        cin >> x >> y;
        build.push_back({x, y});
    }
    
    for (int i = 0; i < m; i++) {
        long long x, y;
        cin >> x >> y;
        rockets.push_back({x, y});
    }
    
    long long count = 0;
    long long x = 0;
    int j = 0;
    
    for (int i = 0; i < n; i++) {
        while (rockets[j].first <= build[i].first + x) {
            if (rockets[j].second <= build[i].second) {
                count++;
            }
            j++;
        }
        x = x + build[i].first;
    }
    
    cout << count;

    return 0;
}