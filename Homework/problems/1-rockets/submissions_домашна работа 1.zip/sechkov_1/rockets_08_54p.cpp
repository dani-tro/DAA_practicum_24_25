#include <bits/stdc++.h>
#include <vector>
using namespace std;

mt19937 myrand(243613443);

void quick_sort(vector <pair<int, int>>& a) {
    if (a.size() <= 1) return;

    vector <pair<int, int>> low, high, eq;
    int n = a.size();
    pair<int, int> pivot = a[myrand() % n];

    for (auto i : a) {
        if (i.first < pivot.first) low.push_back(i);
        else if (i.first == pivot.first) eq.push_back(i);
        else high.push_back(i);
    }

    quick_sort(low);
    quick_sort(high);

    int ptr = 0;
    for (auto i : low) {
        a[ptr] = i;
        ptr++;
    }
    for (auto i : eq) {
        a[ptr] = i;
        ptr++;
    }
    for (auto i : high) {
        a[ptr] = i;
        ptr++;
    }
}

int main()
{
    long long n, m;
    vector<pair<int, int>> build;
    vector<pair<int, int>> rockets;
    
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    
    cin >> n >> m;
    
    for (int i = 0; i < n; i++) {
        long long x, y;
        cin >> x >> y;
        build.push_back({x, y});
    }
    
    for (int i = 0; i < m; i++) {
        long long x, y;
        cin >> x >> y;
        rockets.push_back({x, y});
    }
    
    quick_sort(rockets);
    
    long long count = 0;
    long long x = 0;
    int j = 0;
    
    for (int i = 0; i < n; i++) {
        while (rockets[j].first < build[i].first + x) {
            if (rockets[j].second <= build[i].second) {
                count++;
            }
            j++;
        }
        if ((i < n - 1 && build[i].second > build[i + 1].second) || i == n - 1) {
            while (rockets[j].first == build[i].first + x) {
                if (rockets[j].second <= build[i].second) {
                    count++;
                }
                j++;
            }
        }
        x = x + build[i].first;
    }
    
    cout << count;

    return 0;
}