#include <iostream>
#include <iomanip>
#include <cmath>
#include <climits>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <queue>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>

using namespace std;

struct Event {
    long long x;
    long long height;
    int type;
};

bool compareEvents(const Event& ev1, const Event& ev2) {
    if (ev1.x == ev2.x) {
        return ev1.type > ev2.type;
    }
    return ev1.x < ev2.x;
}

int main() {
	ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n, m;
    cin >> n >> m;
    vector<Event> events(n * 2 + m);
    long long currWidth, currHeight, currX = 0;
    for (int i = 0; i < n * 2; ++i) {
        cin >> currWidth >> currHeight;
        
        events[i].x = currX;
        events[i].height = currHeight;
        events[i].type = 1;

        currX += currWidth;
        ++i;

        events[i].x = currX;
        events[i].height = currHeight;
        events[i].type = -1;
    }
    for (int i = n * 2; i < events.size(); ++i) {
        cin >> events[i].x >> events[i].height;
        events[i].type = 0;
    }
    sort(events.begin(), events.end(), compareEvents);

    currHeight = 0;
    int hittingRockets = 0, currBuildings = 0;
    long long prevEventHeightTemp = events[0].height;
    for (const Event& event : events) {
        if (event.type == 0) {
            if (currBuildings > 0 && event.height <= currHeight) {
                ++hittingRockets;
            }
        }
        else {
            currBuildings += event.type;
            if (currBuildings == 0) {
                currHeight = 0;
            }
            else if (currBuildings == 1) {
                currHeight = prevEventHeightTemp;
            }
            else if (currBuildings == 2) {
                prevEventHeightTemp = event.height;
                currHeight = max(currHeight, event.height);
            }
        }
    }

    cout << hittingRockets;

    return 0;
}