#include <iostream>
#include <iomanip>
#include <cmath>
#include <climits>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <queue>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>

using namespace std;

struct Event {
    int x;
    int height;
    int type;
};

bool compareEvents(const Event& ev1, const Event& ev2) {
    if (ev1.x == ev2.x) {
        return ev1.type > ev2.type;
    }
    return ev1.x < ev2.x;
}

int main() {
	ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n, m;
    cin >> n >> m;
    vector<Event> events(n * 2 + m);
    int currWidth, currHeight, currX = 0;
    for (int i = 0; i < n * 2; ++i) {
        cin >> currWidth >> currHeight;
        
        events[i].x = currX;
        events[i].height = currHeight;
        events[i].type = 1;

        currX += currWidth;
        ++i;

        events[i].x = currX;
        events[i].height = currHeight;
        events[i].type = -1;
    }
    for (int i = n * 2; i < events.size(); ++i) {
        cin >> events[i].x >> events[i].height;
        events[i].type = 0;
    }
    sort(events.begin(), events.end(), compareEvents);

    currHeight = 0;
    int hittingRockets = 0, currBuildings = 0;
    for (const Event& event : events) {
        if (event.type == 0) {
            if (currBuildings > 0 && event.height <= currHeight) {
                ++hittingRockets;
            }
        }
        else {
            currBuildings += event.type;
            if (currBuildings == 0) {
                currHeight = 0;
            }
            if (currBuildings == 1) {
                currHeight = event.height;
            }
            if (currBuildings == 2) {
                currHeight = max(currHeight, event.height);
            }
        }
    }

    cout << hittingRockets;

    return 0;
}

//int main() {
//    ios::sync_with_stdio(false);
//    cin.tie(NULL);
//    cout.tie(NULL);
//
//    long long n, f;
//    cin >> n >> f;
//
//    if (n <= f || n == 1) {
//        cout << 1;
//        return 0;
//    }
//
//    long long left = 2, right = n / f + 1, pos = right;
//
//    while (left <= right) {
//        long long middle = left + (right - left) / 2;
//
//        // Compute middle * f safely
//        long long currSum = middle * f;
//        if (currSum >= n) {
//            pos = min(pos, middle);
//            right = middle - 1;
//            continue;
//        }
//
//        // Compute (middle * (middle - 1)) / 2 safely
//        long long extraSum;
//        if (middle % 2 == 0) {
//            extraSum = (middle / 2); // First divide to prevent overflow
//            if (extraSum >= n / (middle - 1)) { // Overflow check
//                pos = min(pos, middle);
//                right = middle - 1;
//                continue;
//            }
//            extraSum *= (middle - 1);
//        } else {
//            extraSum = (middle - 1) / 2; // First divide to prevent overflow
//            if (middle >= n / extraSum) { // Overflow check
//                pos = min(pos, middle);
//                right = middle - 1;
//                continue;
//            }
//            extraSum *= middle;
//        }
//
//        if (currSum >= n - extraSum) { // Check final sum safely
//            pos = min(pos, middle);
//            right = middle - 1;
//        } else {
//            left = middle + 1;
//        }
//    }
//
//    cout << pos;
//    return 0;
//}

//struct Event {
//	int coordinate;
//	int type;
//};
//
//bool compareEvents(const Event& ev1, const Event& ev2) {
//	if (ev1.coordinate == ev2.coordinate) {
//		return ev1.type > ev2.type;
//	}
//	return ev1.coordinate < ev2.coordinate;
//}
//
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	vector<Event> eventsHorizontal(n * 2);
//	vector<Event> eventsVertical(n * 2);
//	for (int i = 0; i < n * 2; i += 2) {
//		cin >> eventsHorizontal[i].coordinate >> eventsVertical[i].coordinate
//			>> eventsHorizontal[i + 1].coordinate >> eventsVertical[i + 1].coordinate;
//		eventsHorizontal[i].type = 1;
//		eventsHorizontal[i + 1].type = -1;
//		eventsVertical[i].type = 1;
//		eventsVertical[i + 1].type = -1;
//		if (eventsHorizontal[i].coordinate > eventsHorizontal[i + 1].coordinate)
//			swap(eventsHorizontal[i].coordinate, eventsHorizontal[i + 1].coordinate);
//		if (eventsVertical[i].coordinate > eventsVertical[i + 1].coordinate)
//			swap(eventsVertical[i].coordinate, eventsVertical[i + 1].coordinate);
//	}
//	sort(eventsHorizontal.begin(), eventsHorizontal.end(), compareEvents);
//	sort(eventsVertical.begin(), eventsVertical.end(), compareEvents);
//
//	int maxRes = 0, currRes = 0;
//	for (const Event& event : eventsHorizontal) {
//		currRes += event.type;
//		maxRes = max(maxRes, currRes);
//	}
//	currRes = 0;
//	for (const Event& event : eventsVertical) {
//		currRes += event.type;
//		maxRes = max(maxRes, currRes);
//	}
//
//	cout << maxRes;
//
//	return 0;
//}

//struct Event {
//	int time;
//	int type;
//	int nationality;
//};
//
//bool compareEvents(const Event& ev1, const Event& ev2) {
//	if (ev1.nationality == ev2.nationality) {
//		if (ev1.time == ev2.time) {
//			return ev1.type > ev2.type;
//		}
//		return ev1.time < ev2.time;
//	}
//	return ev1.nationality < ev2.nationality;
//}
//
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//	
//	int n;
//	cin >> n;
//	vector<Event> events(n * 2);
//	for (int i = 0; i < events.size(); i += 2) {
//		cin >> events[i].time >> events[i + 1].time >> events[i].nationality;
//		events[i + 1].nationality = events[i].nationality;
//		events[i].type = 1;
//		events[i + 1].type = -1;
//	}
//
//	sort(events.begin(), events.end(), compareEvents);
//
//	int currPeople = 0, maxPeople = 0;
//	for (const Event& event : events) {
//		currPeople += event.type;
//		maxPeople = max(maxPeople, currPeople);
//	}
//
//	cout << maxPeople;
//
//	return 0;
//}


//struct Event {
//	int x;
//	int type;
//	int index;
//};
//
//bool compareEvents(const Event& ev1, const Event& ev2) {
//	if (ev1.x == ev2.x) {
//		return ev1.type > ev2.type;
//	}
//
//	return ev1.x < ev2.x;
//}
//
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n, m;
//	cin >> n >> m;
//	vector<Event> events(n * 2 + m);
//	for (int i = 0; i < n * 2; i += 2) {
//		cin >> events[i].x >> events[i + 1].x;
//		if (events[i].x > events[i + 1].x) {
//			swap(events[i].x, events[i + 1].x);
//		}
//		events[i].type = 1;
//		events[i + 1].type = -1;
//	}
//	int originalPointIndex = 0;
//	for (int i = n * 2; i < events.size(); ++i) {
//		cin >> events[i].x;
//		events[i].type = 0;
//		events[i].index = originalPointIndex++;
//	}
//
//	/*for (int i = 0; i < events.size(); ++i) {
//		cout << events[i].x << " " << events[i].type << "\n";
//	}*/
//
//	sort(events.begin(), events.end(), compareEvents);
//
//	int activeSegments = 0;
//	vector<int> ans(m);
//	for (const Event& event : events) {
//		if (event.type == 0) {
//			ans[event.index] = activeSegments;
//		}
//		activeSegments += event.type;
//	}
//
//	for (int i = 0; i < m; ++i) {
//		cout << ans[i] << ' ';
//	}
//
//	return 0;
//}

//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	vector<pair<int, int>> segments(n);
//	for (int i = 0; i < n; ++i) {
//		cin >> segments[i].first;
//		cin >> segments[i].second;
//	}
//	sort(segments.begin(), segments.end());
//
//	int maxSegment = segments[0].second - segments[0].first, segmentsCount = n;
//	for (int i = 1; i < n; ++i) {
//		if (segments[i].first <= segments[i - 1].second) {
//			segments[i].first = segments[i - 1].first;
//			segments[i].second = max(segments[i].second, segments[i - 1].second);
//			--segmentsCount;
//		}
//		maxSegment = max(maxSegment, segments[i].second - segments[i].first);
//	}
//
//	cout << segmentsCount << " " << maxSegment;
//
//	return 0;
//}

//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	vector<long long> x(n);
//	vector<long long> y(n);
//	for (int i = 0; i < n; ++i) {
//		cin >> x[i];
//	}
//	for (int i = 0; i < n; ++i) {
//		cin >> y[i];
//	}
//
//	int maxDist = 0;
//	for (int i = 0; i < n; ++i) {
//		int l = i, r = n - 1;
//		while (l <= r) {
//			int mid = (l + r) / 2;
//			if (y[mid] >= x[i]) {
//				maxDist = max(maxDist, mid - i);
//				l = mid + 1;
//			}
//			else {
//				r = mid - 1;
//			}
//		}
//	}
//
//	cout << maxDist;
//
//	return 0;
//}

//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	vector<long long> arr(n);
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	sort(arr.begin(), arr.end());
//	for (auto el : arr) {
//		cout << el << ' ';
//	}
//
//	return 0;
//}

//ksumconsecutive
//int main() {
//ios::sync_with_stdio(false);
//cin.tie(NULL);
//cout.tie(NULL);
//
//	int n, k;
//	cin >> n >> k;
//	vector<long long> arr(n);
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	set<long long> prefixes;
//	prefixes.insert(0);
//	long long currSum = 0, maxSum = INT_MIN;
//	for (int i = 0; i < n; ++i) {
//		currSum += arr[i];
//		auto it = prefixes.lower_bound(currSum - k);
//		if (it != prefixes.end() && currSum - *it > maxSum) {
//			maxSum = currSum - *it;
//		}
//
//		prefixes.insert(currSum);
//	}
//
//	if (maxSum > INT_MIN) {
//		cout << maxSum;
//	}
//	else {
//		cout << -1;
//	}
//
//	return 0;
//}

// merge
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n, m;
//	cin >> n >> m;
//	long long* arr1 = new long long[n], * arr2 = new long long[m];
//	for (int i = 0; i < n; ++i) {
//		cin >> arr1[i];
//	}
//	for (int i = 0; i < m; ++i) {
//		cin >> arr2[i];
//	}
//
//	int i = 0, j = 0;
//	while (i < n && j < m) {
//		if (arr1[i] <= arr2[j]) {
//			cout << arr1[i++] << ' ';
//		}
//		else {
//			cout << arr2[j++] << ' ';
//		}
//	}
//	while (i < n) {
//		cout << arr1[i++] << ' ';
//	}
//	while (j < m) {
//		cout << arr2[j++] << ' ';
//	}
//
//	return 0;
//}

//monuments
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	long long n , r;
//	cin >> n >> r;
//	vector<int> distances(n);
//	for (long long i = 0; i < n; ++i) {
//		cin >> distances[i];
//	}
//
//	long long j = 0, count = 0;
//	for (long long i = 0; i < n; ++i) {
//		while (j < n && distances[j] - distances[i] <= r) {
//			++j;
//		}
//		count += n - j;
//	}
//
//	cout << count;
//
//	return 0;
//}

//counting sort for nums 0-999
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	vector<int> numCount(1000, 0);
//	int n;
//	cin >> n;
//
//	int currEl;
//	for (int i = 0; i < n; ++i) {
//		cin >> currEl;
//		++numCount[currEl];
//	}
//
//	for (int i = 0; i < 1000; ++i) {
//		while (numCount[i]) {
//			cout << i << ' ';
//			--numCount[i];
//		}
//	}
//
//	return 0;
//}

//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	int* arr = new int[n];
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	for (int i = 1; i < n; ++i) {
//		int j = i;
//		while (j > 0 && arr[j] < arr[j - 1]) {
//			std::swap(arr[j - 1], arr[j]);
//			--j;
//		}
//
//		for (int k = 0; k < n; ++k) {
//			cout << arr[k] << ' ';
//		}
//		cout << '\n';
//	}
//
//	return 0;
//}

// bubble sort
//int main() {
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	int* arr = new int[n];
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	for (int i = 1; i < n; ++i) {
//		for (int j = 0; j < n - i; ++j) {
//			if (arr[j] > arr[j + 1]) {
//				std::swap(arr[j], arr[j + 1]);
//			}
//		}
//
//		for (int k = 0; k < n; ++k) {
//			cout << arr[k] << ' ';
//		}
//		cout << '\n';
//	}
//}

//mt19937 myrand(243613443);
//
//void my_quick_sort(vector<int>& arr) {
//	int n = arr.size();
//	if (n <= 1) {
//		return;
//	}
//
//	vector<int> low, eq, high;
//	int pivot = arr[myrand() % n];
//
//	for (auto el : arr) {
//		if (el < pivot) {
//			low.push_back(el);
//		}
//		else if (el > pivot) {
//			high.push_back(el);
//		}
//		else {
//			eq.push_back(el);
//		}
//	}
//
//	my_quick_sort(low);
//	my_quick_sort(high);
//
//	int i = 0;
//	for (auto el : low) {
//		arr[i++] = el;
//	}
//	for (auto el : eq) {
//		arr[i++] = el;
//	}
//	for (auto el : high) {
//		arr[i++] = el;
//	}
//}
//
//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	vector<int> arr(n);
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	//quick sorting
//	my_quick_sort(arr);
//
//	//print result
//	for (auto el : arr) {
//		cout << el << ' ';
//	}
//
//	return 0;
//}

//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	int* arr = new int[n];
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	for (int i = 0; i < n - 1; ++i) {
//		for (int j = 1; j < n - i; ++j) {
//			if (arr[j - 1] > arr[j]) {
//				std::swap(arr[j - 1], arr[j]);
//			}
//		}
//
//		for (int k = 0; k < n; ++k) {
//			cout << arr[k] << ' ';
//		}
//		cout << '\n';
//	}
//}

//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	int* arr = new int[n];
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	for (int i = 0; i < n - 1; ++i) {
//		int minEl = arr[i], minIndex = i;
//		for (int j = i + 1; j < n; ++j) {
//			if (arr[j] < minEl) {
//				minEl = arr[j];
//				minIndex = j;
//			}
//		}
//		std::swap(arr[i], arr[minIndex]);
//
//		for (int k = 0; k < n; ++k) {
//			cout << arr[k] << ' ';
//		}
//		cout << '\n';
//	}
//}

//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	vector<long long> arr(n);
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//	
//	std::sort(arr.begin(), arr.end());
//	for (long long el : arr) {
//		cout << el << ' ';
//	}
//}

//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	long long n;
//	cin >> n;
//	long long *arr = new long long [n];
//	for (int i = 0; i < n; ++i) {
//		cin >> arr[i];
//	}
//
//	long long sum = 0;
//	for (int subArrLen = 1; subArrLen <= n; subArrLen += 2) {
//		long long currSum = 0;
//		for (int i = 0; i < subArrLen; ++i) {
//			currSum += arr[i];
//		}
//		sum += currSum;
//		for (int i = 0; i < n - subArrLen; ++i) {
//			currSum -= arr[i];
//			currSum += arr[i + subArrLen];
//			sum += currSum;
//		}
//	}
//
//	cout << sum;
//}

//int calc(int x) {
//	int res = 0;
//	while (x) {
//		res += x % 2;
//		x /= 2;
//	}
//	return res;
//}
//
//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//
//	int x;
//	for (int i = 0; i < n; ++i) {
//		cin >> x;
//		cout << calc(x) << '\n';
//	}
//}

//const int maxx = 25;
//long long A[maxx][maxx], B[maxx][maxx], C[maxx][maxx];
//
//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n, m, k, i, j, t;
//	cin >> n >> m >> k;
//	for (i = 1; i <= n; i++) {
//		for (j = 1; j <= m; j++) {
//			cin >> A[i][j];
//		}
//	}
//	for (i = 1; i <= m; i++) {
//		for (j = 1; j <= k; j++) {
//			cin >> B[i][j];
//		}
//	}
//
//	for (i = 1; i <= n; i++) {
//		for (j = 1; j <= k; j++) {
//			for (t = 1; t <= m; t++) {
//				C[i][j] += A[i][t] * B[t][j];
//			}
//		}
//	}
//
//	for (i = 1; i <= n; i++) {
//		for (j = 1; j <= k; j++) {
//			cout << C[i][j] << " ";
//		}
//		cout << endl;
//	}
//}

//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	vector<long long> st;
//	long long currNum;
//	while (cin >> currNum) {
//		st.push_back(currNum);
//	}
//
//	double currRes;
//	while (!st.empty()) {
//		currRes = sqrt(st.back());
//		st.pop_back();
//		cout << fixed << setprecision(7) << currRes << '\n';
//	}
//}

//int main() {
//
//	ios::sync_with_stdio(false);
//	cin.tie(NULL);
//	cout.tie(NULL);
//
//	int n;
//	cin >> n;
//	long long sum = 0;
//
//	long long currNum;
//	for (int i = 0; i < n; ++i) {
//		cin >> currNum;
//		sum += currNum;
//	}
//
//	cout << sum;
//}

//int main() {
//	long long x, y;
//	cin >> x >> y;
//	long long res = x + y;
//	cout << res << '\n';
//
//}

//int main() {
//	string name;
//	std::cin >> name;
//	std::cout << "Hello, " << name << '\n';
//
//	return 0;
//}