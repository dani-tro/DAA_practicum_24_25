#include <bits/stdc++.h>
using namespace std;

const int MAXN = 3e5 + 10;
int n, m;

struct Building
{
    int w, h;
};
Building buildings[MAXN];

struct Rocket
{
    int x, y;
    bool operator<(const Rocket &other) const
    {
        return x < other.x;
    }
};
Rocket rockets[MAXN];

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> buildings[i].w >> buildings[i].h;

    for (int i = 1; i <= m; i++)
        cin >> rockets[i].x >> rockets[i].y;

    sort(rockets + 1, rockets + m + 1);

    int cnt = 0;
    int pos = 1, last = 0;
    for (int i = 1; i <= n; i++)
    {
        last += buildings[i].w;
        while (rockets[pos].x <= last)
        {
            if (rockets[pos].y <= buildings[i].h)
                cnt++;
            pos++;
        }
    }

    cout << cnt << endl;

    return 0;
}