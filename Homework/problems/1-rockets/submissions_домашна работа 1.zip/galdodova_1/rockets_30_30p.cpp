#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool sortedRockets(pair<long long, long long> a, pair<long long, long long> b) {
    return a.first < b.first; // Сортиране по широчина
}

int main() {
    long long N, M;
    cin >> N >> M;
    vector<pair<long long, long long>> buildings(N); // {широчина, височина}
    vector<pair<long long, long long>> rockets(M);   // {позиция по широчина, височина}
    vector<long long> startPositions(N); // Начални позиции на сградите
    long long currentX = 0; // Текуща позиция на небостъргача
    
    for (long long i = 0; i < N; ++i) {
        cin >> buildings[i].first >> buildings[i].second; // Широчина и височина
        startPositions[i] = currentX; // Запазваме началната позиция на сградата
        currentX += buildings[i].first; // Изместваме позицията за следващата сграда
    }
    
    for (long long j = 0; j < M; ++j) {
        cin >> rockets[j].first >> rockets[j].second; // Широчина и височина
    }
    
    sort(rockets.begin(), rockets.end(), sortedRockets); // Сортираме ракетите
    
    long long result = 0;
    for (long long i = 0; i < M; ++i) {
        if (rockets[i].first > currentX) { // Ако ракетата е извън обхвата на сградите
            break;
        }
        long long bIndx = 0;
        while (bIndx < N) {
            long long startX = startPositions[bIndx]; // Начална позиция на сградата
            long long endX = startX + buildings[bIndx].first; // Край на сградата
            if (rockets[i].first >= startX && rockets[i].first <= endX) { // Ракетата попада в обхвата
                if (rockets[i].second <= buildings[bIndx].second) { // Проверяваме височината
                    result++;
                    break; // Ако ракетата удари една сграда, спираме
                }
            }
            bIndx++; // Отиваме към следващата сграда
        }
    }
    
    cout << result << endl;
    return 0;
}
