#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N, M;
    std::cin >> N >> M;

    // Вектор за съхранение на широчините и височините на небостъргачите
    std::vector<std::pair<int, int>> skyscrapers(N);
    
    // Въвеждаме небостъргачите
    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        skyscrapers[i] = {w, h};
    }

    // Вектор за съхранение на ракетите
    std::vector<std::pair<int, int>> rockets(M);
    
    // Въвеждаме ракетите
    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;
        rockets[j] = {x, y};
    }

    // Сортираме небостъргачите по широчина
    std::sort(skyscrapers.begin(), skyscrapers.end());

    // Подготовка на масив за предвиждане на ударените небостъргачи
    int result = 0;

    // За всяка ракета проверяваме дали удря поне един небостъргач
    for (const auto& rocket : rockets) {
        int x = rocket.first;
        int y = rocket.second;
        
        // Състояние за ракета - дали ще удари някой небостъргач
        bool hit = false;
        
        // Проверяваме само тези небостъргачи, които попадат в зоната на ракетата
        for (const auto& skyscraper : skyscrapers) {
            int w = skyscraper.first;
            int h = skyscraper.second;
            
            // Проверяваме дали ракета удря този небостъргач
            if (x >= w && y <= h) {
                hit = true;
                break;  // Ако ракета удари, спираме да търсим
            }
        }
        
        if (hit) {
            result++;
        }
    }

    std::cout << result << "\n";

    return 0;
}
