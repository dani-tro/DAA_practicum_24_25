#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool sortedRockets(pair<long long, long long> a, pair<long long, long long> b) {
    return a.first < b.first; // Сортиране по широчина
}

int main() {
    ios::sync_with_stdio(false); // Оптимизация за бърз вход/изход
    cin.tie(NULL);
    
    long long N, M;
    cin >> N >> M;
    vector<pair<long long, long long>> buildings(N); // {широчина, височина}
    vector<pair<long long, long long>> rockets(M);   // {позиция по широчина, височина}
    vector<long long> startPositions(N); // Начални позиции на сградите
    long long currentX = 0; // Текуща позиция на небостъргача
    
    for (long long i = 0; i < N; ++i) {
        cin >> buildings[i].first >> buildings[i].second; // Широчина и височина
        startPositions[i] = currentX; // Запазваме началната позиция на сградата
        currentX += buildings[i].first; // Изместваме позицията за следващата сграда
    }
    
    for (long long j = 0; j < M; ++j) {
        cin >> rockets[j].first >> rockets[j].second; // Широчина и височина
    }
    
    sort(rockets.begin(), rockets.end(), sortedRockets); // Сортираме ракетите
    
    long long result = 0;
    for (long long i = 0; i < M; ++i) {
        long long x = rockets[i].first;
        long long y = rockets[i].second;
        
        // Бинарно търсене за сградата, която съдържа x
        long long bIndx = lower_bound(startPositions.begin(), startPositions.end(), x) - startPositions.begin();
        
        if (bIndx > 0 && (bIndx == N || startPositions[bIndx] > x)) {
            bIndx--;
        }
        
        if (bIndx < N && x >= startPositions[bIndx] && x < startPositions[bIndx] + buildings[bIndx].first) {
            if (y <= buildings[bIndx].second) {
                result++;
            }
        }
    }
    
    cout << result << endl;
    return 0;
}
