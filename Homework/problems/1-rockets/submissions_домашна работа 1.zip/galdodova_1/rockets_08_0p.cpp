#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N, M;
    std::cin >> N >> M;

    std::vector<int> prefixWidth(N + 1, 0);
    std::vector<int> maxHeight(N + 1, 0);

    for (int i = 1; i <= N; ++i) {
        int w, h;
        std::cin >> w >> h;
        prefixWidth[i] = prefixWidth[i - 1] + w; // Пресмятаме началната позиция на всеки небостъргач
        maxHeight[i] = h;
    }

    // Подготвяме най-високата сграда до даден индекс (важно за бързо търсене)
    for (int i = 1; i <= N; ++i) {
        maxHeight[i] = std::max(maxHeight[i], maxHeight[i - 1]);
    }

    int result = 0;

    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;

        // Намерете индекса на сградата, която покрива x
        int bIndex = std::upper_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin() - 1;

        // Проверяваме дали височината на сградата е достатъчна
        if (bIndex >= 1 && maxHeight[bIndex] >= y) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}
