#include <iostream>
#include <vector>
#include <map>

int main() {
    int N, M;
    std::cin >> N >> M;

    std::map<int, int> skyline; // ще държим максималната височина на всяка x-координата
    int xPos = 0;

    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        xPos += w; // Запазваме границата на тази сграда
        skyline[xPos] = std::max(skyline[xPos], h); // Ако има повече от една сграда на тази x-координата, вземаме максималната височина
    }

    int result = 0;

    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;

        auto it = skyline.lower_bound(x); // Намери първата сграда, която има граница >= x
        if (it != skyline.end() && it->second >= y) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}
