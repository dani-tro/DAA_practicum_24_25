#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Структура, която ще използваме за да съхраняваме информация за небостъргачите
struct Skyscraper {
    long long start, end, height;
};

bool isHit(const Skyscraper& s, long long x, long long y) {
    // Проверяваме дали ракета с координати (x, y) удря небостъргач
    return (x >= s.start && x <= s.end && y >= s.height);
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<Skyscraper> skyscrapers(n);
    vector<pair<long long, long long>> rockets(m);

    // Въвеждаме небостъргачите
    long long current_pos = 0;
    for (int i = 0; i < n; i++) {
        long long w, h;
        cin >> w >> h;
        skyscrapers[i] = {current_pos, current_pos + w - 1, h};
        current_pos += w;
    }

    // Въвеждаме ракетите
    for (int i = 0; i < m; i++) {
        cin >> rockets[i].first >> rockets[i].second;
    }

    int hit_count = 0;

    // Сортираме небостъргачите по началната позиция
    sort(skyscrapers.begin(), skyscrapers.end(), [](const Skyscraper& a, const Skyscraper& b) {
        return a.start < b.start;
    });

    // За всяка ракета проверяваме дали ще удари някой небостъргач
    for (const auto& rocket : rockets) {
        long long x = rocket.first;
        long long y = rocket.second;
        bool hit = false;

        // Използваме бинарно търсене, за да намерим небостъргачите, които могат да бъдат ударени
        int left = 0, right = n - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (skyscrapers[mid].start <= x && skyscrapers[mid].end >= x) {
                if (isHit(skyscrapers[mid], x, y)) {
                    hit = true;
                    break;
                }
                // Ако ракета не удря текущия небостъргач, проверяваме другата част от масива
                if (x < skyscrapers[mid].start) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            } else {
                if (x < skyscrapers[mid].start) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            }
        }

        if (hit) {
            hit_count++;
        }
    }

    // Отпечатваме броя на ракетите, които удрят небостъргач
    cout << hit_count << endl;

    return 0;
}
