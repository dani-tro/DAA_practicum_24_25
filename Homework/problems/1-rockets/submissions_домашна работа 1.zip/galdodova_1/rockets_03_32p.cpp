#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N, M;
    std::cin >> N >> M;
    
    std::vector<int> heights(N);
    std::vector<int> prefixWidth(N); // Префикс сума на ширините

    int widthSum = 0;
    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        widthSum += w; 
        prefixWidth[i] = widthSum; // Край на тази сграда
        heights[i] = h; // Височина на сградата
    }

    int result = 0;
    
    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;
        
        // Намери коя сграда е засегната от ракетата
        auto it = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x);
        int indx = it - prefixWidth.begin(); // Индекс на сградата

        if (indx < N && heights[indx] >= y) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}
