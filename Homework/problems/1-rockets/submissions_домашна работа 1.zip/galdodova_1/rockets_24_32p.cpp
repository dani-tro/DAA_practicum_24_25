#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);

    long long N, M;
    std::cin >> N >> M;

    std::vector<long long> prefixWidth(N);
    std::vector<long long> heights(N);

    // Въвеждане на небостъргачите
    long long accumulatedWidth = 0;
    for (long long i = 0; i < N; ++i) {
        long long w, h;
        std::cin >> w >> h;
        accumulatedWidth += w;
        prefixWidth[i] = accumulatedWidth;
        heights[i] = h;
    }

    long long result = 0;

    for (long long j = 0; j < M; ++j) {
        double x, y;
        std::cin >> x >> y;

        long long bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), static_cast<long long>(x)) - prefixWidth.begin();

        if (bIndex < N && heights[bIndex] >= static_cast<long long>(y)) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}