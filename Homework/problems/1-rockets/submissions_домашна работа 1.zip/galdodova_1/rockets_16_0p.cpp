#include <iostream>
#include <vector>

int main() {
    int N, M;
    std::cin >> N >> M;

    // Вектор за широчините и височините на небостъргачите
    std::vector<int> prefixWidth(N + 1, 0);
    std::vector<int> heights(N);

    // Въвеждаме широчините и височините на небостъргачите
    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w;
        heights[i] = h;
    }

    int result = 0;

    // Въвеждаме ракетите
    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;

        // Търсим сграда, която попада в диапазона на ракетата
        for (int i = 0; i < N; ++i) {
            int buildingStart = prefixWidth[i];
            int buildingEnd = prefixWidth[i + 1];

            if (x >= buildingStart && x < buildingEnd && y >= heights[i]) {
                result++;
                break;
            }
        }
    }

    // Извеждаме резултата
    std::cout << result << "\n";
    return 0;
}
