#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios::sync_with_stdio(false); // Оптимизация за бърз вход/изход
    std::cin.tie(NULL);

    long long N, M;
    std::cin >> N >> M;

    std::vector<long long> prefixWidth(N + 1, 0);
    std::vector<long long> heights(N);

    // Въвеждане на небостъргачите
    for (long long i = 0; i < N; ++i) {
        long long w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w;
        heights[i] = h;
    }


    long long result = 0;

    for (long long j = 0; j < M; ++j) {
        long long x, y;
        std::cin >> x >> y;


        long long bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin();

        if (bIndex >= N || (bIndex > 0 && prefixWidth[bIndex] >= x)) {
            bIndex--;
        }


        if (bIndex >= 0 && bIndex <= N && prefixWidth[bIndex] <= x && heights[bIndex] >= y) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}
