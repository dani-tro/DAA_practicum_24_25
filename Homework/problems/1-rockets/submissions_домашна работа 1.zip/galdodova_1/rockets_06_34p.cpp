#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N, M;
    std::cin >> N >> M;

    std::vector<int> prefixWidth(N + 1, 0);
    std::vector<int> heights(N);

    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w;
        heights[i] = h;
    }

    int result = 0;

    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;

        int bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin();
        if (bIndex == N + 1 || prefixWidth[bIndex] > x) {
            bIndex--;  // Намаляваме индекса, за да вземем правилната сграда
        }

        if (bIndex >= 0 && bIndex < N && heights[bIndex] >= y) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}
