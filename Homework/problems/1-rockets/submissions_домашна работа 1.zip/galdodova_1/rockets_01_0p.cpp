//
// Created by galya777 on 27.03.25.
//
#include <iostream>
#include <vector>
#include <algorithm>


bool sortedRockets(std::pair<int, int> a, std::pair<int, int> b){
    return a.first<b.first;
}
int main(){
int N, M;
std::cin>>N>>M;
std::vector<std::pair<int, int>> buildings(N);
std::vector<std::pair<int, int>> rockets(M);
    int widthSum=0;
    for (int i = 0; i < N; ++i) {
        std::cin>>buildings.at(i).first;//width
        std::cin>>buildings.at(i).second;//height
        widthSum+=buildings.at(i).first;
    }
    for (int j = 0; j < M; ++j) {
        std::cin>>rockets.at(j).first;//width
        std::cin>>rockets.at(j).second;//height
    }
    std::sort(rockets.begin(), rockets.end(), sortedRockets);

    int result=0;
    for (int i = 0; i < M; ++i) {
        if(rockets[i].first>widthSum){
            break;
        }
        else {
          int bIndx=0;
            while (bIndx<N){
                        if (rockets[i].first<=buildings[bIndx].first) {
                            result++;
                        }
                  bIndx+=buildings[bIndx].second;
                }
        }
    }

   std::cout<<result;

    return 0;
}