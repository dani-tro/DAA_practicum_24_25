#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Структура за съхранение на информация за небостъргач
struct Building {
    int start, end, height;
};

// Функция за проверка дали ракета удря небостъргач
bool willHit(const Building& building, int rocket_start, int rocket_height) {
    return rocket_start >= building.start && rocket_start <= building.end && rocket_height >= building.height;
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<Building> buildings(n);
    vector<pair<int, int>> rockets(m);

    // Въвеждаме небостъргачите
    for (int i = 0; i < n; ++i) {
        int width, height;
        cin >> width >> height;
        buildings[i] = {i, i + width - 1, height};  // Всеки небостъргач е интервал [i, i + width - 1]
    }

    // Въвеждаме ракетите
    for (int i = 0; i < m; ++i) {
        cin >> rockets[i].first >> rockets[i].second;  // ракета има стартова широчина и височина
    }

    // Сортиране на небостъргачите по стартова широчина
    sort(buildings.begin(), buildings.end(), [](const Building& a, const Building& b) {
        return a.start < b.start;
    });

    int hit_count = 0;
    
    // За всяка ракета проверяваме дали ще удари някой небостъргач
    for (const auto& rocket : rockets) {
        int rocket_start = rocket.first;
        int rocket_height = rocket.second;

        // Бинарно търсене за бързо намиране на подходящи небостъргачи
        bool hit = false;
        for (const auto& building : buildings) {
            if (willHit(building, rocket_start, rocket_height)) {
                hit = true;
                break;
            }
        }

        if (hit) {
            ++hit_count;
        }
    }

    cout << hit_count << endl;

    return 0;
}
