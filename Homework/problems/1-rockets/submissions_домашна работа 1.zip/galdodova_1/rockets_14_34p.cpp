#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N, M;
    std::cin >> N >> M;

    // Префиксна сума на широчините
    std::vector<int> prefixWidth(N + 1, 0);
    // Височини на небостъргачите
    std::vector<int> heights(N);

    // Въвеждаме небостъргачите и попълваме префиксната сума
    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w;
        heights[i] = h;
    }

    int result = 0;

    // Обработваме всяка ракета
    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;

        // Търсим най-близкия небостъргач, който се намира в интервала, в който попада ракета
        int bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin();

        // Ако bIndex сочи към последния елемент или по-голям, значи трябва да намалим индекса
        if (bIndex == N + 1 || prefixWidth[bIndex] > x) {
            bIndex--;
        }

        // Ако намерим валиден небостъргач, проверяваме височината му
        if (bIndex >= 0 && bIndex < N && prefixWidth[bIndex] <= x && heights[bIndex] >= y) {
            result++;
        }
    }

    // Извеждаме резултата
    std::cout << result << "\n";

    return 0;
}
