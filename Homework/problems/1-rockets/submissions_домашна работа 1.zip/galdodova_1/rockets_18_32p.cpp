#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios::sync_with_stdio(false); // Изключваме синхронизация с C стандартната библиотека
    std::cin.tie(NULL); // Развързване на връзката между cin и cout

    long long N, M;
    std::cin >> N >> M;

    // Префиксна сума на широчините
    std::vector<long long> prefixWidth(N + 1, 0);
    // Височини на небостъргачите
    std::vector<long long> heights(N);

    // Въвеждаме небостъргачите и попълваме префиксната сума
    for (long long i = 0; i < N; ++i) {
        long long w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w;
        heights[i] = h;
    }

    long long result = 0;

    // Обработваме всяка ракета
    for (long long j = 0; j < M; ++j) {
        long long x, y;
        std::cin >> x >> y;

        // Търсим най-близкия небостъргач, който се намира в интервала, в който попада ракета
        long long bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin();

        // Ако bIndex сочи към последния елемент или по-голям, значи трябва да намалим индекса
        if (bIndex == N + 1 || prefixWidth[bIndex] >= x) {
            bIndex--;
        }

        // Ако намерим валиден небостъргач, проверяваме височината му
        if (bIndex >= 0 && bIndex < N && prefixWidth[bIndex] <= x && heights[bIndex] >= y) {
            result++;
        }
    }

    // Извеждаме резултата
    std::cout << result << "\n";

    return 0;
}
