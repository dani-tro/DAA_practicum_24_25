#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::ios::sync_with_stdio(false); // Оптимизираме вход/изход
    std::cin.tie(NULL); // Развързваме cin и cout

    long long N, M;
    std::cin >> N >> M;

    // Префиксна сума за широчините
    std::vector<long long> prefixWidth(N + 1, 0);
    // Височини на сградите
    std::vector<long long> heights(N);

    // Четем сградите
    for (long long i = 0; i < N; ++i) {
        long long w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w; // Префиксна сума
        heights[i] = h;
    }

    long long result = 0;

    // Четем ракетите и проверяваме дали удрят сграда
    for (long long j = 0; j < M; ++j) {
        long long x, y;
        std::cin >> x >> y;

        // Намерете индекса на сградата, в която попада ракетата
        long long bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin();

        // Ако сме извън границите, коригираме
        if (bIndex == N + 1 || prefixWidth[bIndex] > x) {
            bIndex--;
        }

        // Проверяваме и предходната сграда, ако ракетата е на границата
        long long bestHeight = (bIndex >= 0 && bIndex < N) ? heights[bIndex] : 0;

        if (bIndex > 0 && prefixWidth[bIndex] == x) {
            bestHeight = std::max(bestHeight, heights[bIndex - 1]);
        }

        // Ако максималната намерена височина е >= височината на ракетата -> удар
        if (bestHeight >= y) {
            result++;
        }
    }

    // Извеждаме броя на ударените ракети
    std::cout << result << "\n";

    return 0;
}
