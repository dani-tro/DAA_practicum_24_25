#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int N, M;
    std::cin >> N >> M;

    std::vector<int> prefixWidth(N + 1, 0);
    std::vector<int> maxHeight(N);

    for (int i = 0; i < N; ++i) {
        int w, h;
        std::cin >> w >> h;
        prefixWidth[i + 1] = prefixWidth[i] + w;
        maxHeight[i] = h;
    }

    // **Оптимизация:** Преизчисляваме maxHeight като максимална височина до този момент
    for (int i = 1; i < N; ++i) {
        maxHeight[i] = std::max(maxHeight[i], maxHeight[i - 1]);
    }

    int result = 0;

    for (int j = 0; j < M; ++j) {
        int x, y;
        std::cin >> x >> y;

        // **Използваме binary search (O(log N)) за намиране на правилния индекс**
        int bIndex = std::lower_bound(prefixWidth.begin(), prefixWidth.end(), x) - prefixWidth.begin() - 1;

        // Проверяваме дали височината е достатъчна
        if (bIndex >= 0 && bIndex < N && maxHeight[bIndex] >= y) {
            result++;
        }
    }

    std::cout << result << "\n";
    return 0;
}
