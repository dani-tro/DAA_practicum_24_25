#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
typedef long long lin;
using namespace std;
lin h[300010];
lin w[300010];
lin x[300010];
lin y[300010];

lin bsearch(lin target, lin n) {
	if (target == 0) return 1;
	if (target > w[n]) return -1;
	if (target == w[n]) return n;
	lin low = 0, high = n, mid = (low + high) / 2;
	while (low != high) {
		if (target == w[mid]) {
			return h[mid - 1] > h[mid] ? (mid - 1) : mid;
		}
		else if (target == w[mid + 1]) {
			return h[mid] > h[mid + 1] ? mid : (mid + 1);
		}
		else if (target > w[mid] && target < w[mid + 1]) {
			return mid;
		}
		else {
			if (target < w[mid])
			{
				high = mid;
			}
			else {
				low = mid + 1;
			}
		}
		mid = (low + high) / 2;
	}
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	lin n, m, temp, counter = 0;
	w[0] = 0;
	cin >> n >> m;
	for (size_t i = 1; i <= n; i++)
	{
		cin >> temp >> h[i];
		w[i] = w[i - 1] + temp;
	}
	for (size_t i = 0; i < m; i++)
	{
		cin >> x[i] >> y[i];
	}
	for (size_t i = 0; i < m; i++)
	{
		if ((temp = bsearch(x[i], n)) != -1) {
			if (h[temp + 1] >= y[i])
			{
				++counter;
			}
		}
	}
	cout << counter;
}