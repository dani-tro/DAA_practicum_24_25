#include<bits/stdc++.h>
// using namespace std;

// pair<unsigned, unsigned long> buildings[300005];

// int main() {
//     size_t n, m;
//     cin >> n >> m;
//     unsigned long width = 0;
    
//     for (size_t i = 1; i <= n; ++i) {
//         cin >> buildings[i].second >> buildings[i].first;
//         width += buildings[i].second;
//         buildings[i].second = width;
//     }
    
//     unsigned result = 0;

//     for (size_t i = 0; i < m; ++i) {
//         unsigned x, y;
//         cin >> x >> y;

//         if (x > buildings[n].second) {
//             continue;
//         }

//         size_t left = 1, right = n, mid;
//         while (left < right) {
//             mid = (left + right) / 2;

//             if (buildings[mid].second < x) {
//                 left = mid + 1;
//             } else {
//                 right = mid;
//             }
//         }

//         if (buildings[left].first >= y || buildings[left].second == x && buildings[left + 1].first >= y) {
//             ++result;
//         }
//     }
    
//     cout << result;
//     return 0;
// }
using namespace std;

pair<unsigned, unsigned long> buildings[300005];
pair<unsigned, unsigned> rockets[300005];

bool compareRockets(pair<unsigned, unsigned> r1, pair<unsigned, unsigned> r2) {
    return r1.first < r2.first;
}

int main() {
    size_t n, m;
    cin >> n >> m;
    
    unsigned long width = 0;
    for (size_t i = 1; i <= n; ++i) {
        cin >> buildings[i].second >> buildings[i].first;
        width += buildings[i].second;
        buildings[i].second = width;
    }
    
    for (size_t i = 0; i < m; ++i) {
        cin >> rockets[i].first >> rockets[i].second;
    }
    
    sort(rockets, rockets + m, compareRockets);
    
    unsigned result = 0;
    size_t rocketI = 0;
    size_t left = 1;
    size_t buildingI = 0;

    for (size_t i = 0; i < m; ++i) {
        if (rockets[i].first > buildings[n].second) {
            break;
        }

        while (buildingI < n && buildings[buildingI].second < rockets[i].first) {
            ++buildingI;
        }

        if (buildings[buildingI].first >= rockets[i].second || buildings[buildingI].second == rockets[i].first && buildings[buildingI + 1].first >= rockets[i].second) {
            ++result;
        }
    }
    
    // for (size_t i = 0; i < n; ++i) {
    //     width += buildings[i].second;
        
    //     while (rocketI < m && rockets[rocketI].first <= width) {
    //         if (rockets[rocketI].second <= buildings[i].first
    //              ||  rockets[rocketI].first == width && i < n - 1 && rockets[rocketI].second <= buildings[i + 1].first) {
    //             ++result;
    //         }
            
    //         ++rocketI;
    //     }
    // }
    
    cout << result;
    return 0;
}