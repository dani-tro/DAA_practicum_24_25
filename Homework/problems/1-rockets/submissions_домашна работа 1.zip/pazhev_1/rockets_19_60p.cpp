#include<bits/stdc++.h>
// using namespace std;

// pair<unsigned, unsigned long> buildings[300005];

// int main() {
//     size_t n, m;
//     cin >> n >> m;
//     unsigned long width = 0;
    
//     for (size_t i = 1; i <= n; ++i) {
//         cin >> buildings[i].second >> buildings[i].first;
//         width += buildings[i].second;
//         buildings[i].second = width;
//     }
    
//     unsigned result = 0;

//     for (size_t i = 0; i < m; ++i) {
//         unsigned x, y;
//         cin >> x >> y;

//         if (x > buildings[n].second) {
//             continue;
//         }

//         size_t left = 1, right = n, mid;
//         while (left < right) {
//             mid = (left + right) / 2;

//             if (buildings[mid].second < x) {
//                 left = mid + 1;
//             } else {
//                 right = mid;
//             }
//         }

//         if (buildings[left].first >= y || buildings[left].second == x && buildings[left + 1].first >= y) {
//             ++result;
//         }
//     }
    
//     cout << result;
//     return 0;
// }
using namespace std;

struct event {
    unsigned x, y;
    bool is_rocket;

    bool operator<(const event& other) {
        return x < other.x || x == other.x && y > other.y || x == other.x && y == other.y && !is_rocket;
    }
};

event events[600010];

int main() {
    size_t n, m;
    cin >> n >> m;
    
    for (size_t i = 0; i < n; ++i) {
        cin >> events[i + 1].x >> events[i].y;
        events[i + 1].x += events[i].x;
        events[i].is_rocket = false;
    }
    
    unsigned end = events[n].x;
    
    for (size_t i = 0; i < m; ++i) {
        cin >> events[n + i].x >> events[n + i].y;
        events[n + i].is_rocket = true;
    }
    
    sort(events, events + n + m);
    unsigned result = 0, y = 0;

    for (size_t i = 0; i < n + m; ++i) {
        if (events[i].x > end) {
            break;
        }

        if (!events[i].is_rocket) {
            y = events[i].y;
        } else if (events[i].y <= y) {
            ++result;
        }
    }
    
    cout << result;
    return 0;
}