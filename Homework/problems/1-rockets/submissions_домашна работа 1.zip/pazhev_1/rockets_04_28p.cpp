#include<vector>
#include<algorithm>
#include<iostream>
using namespace std;

vector<pair<unsigned, unsigned>> buildings;
vector<pair<unsigned, unsigned>> rockets;

bool compareRockets(pair<unsigned, unsigned> r1, pair<unsigned, unsigned> r2) {
	return r1.first < r2.first;
}

int main() {
	size_t n, m;
	cin >> n >> m;
	
	for (size_t i = 0; i < n; ++i) {
		unsigned h, w;
		cin >> w >> h;
		buildings.push_back({h, w});
	}
	
	for (size_t i = 0; i < m; ++i) {
		unsigned x, y;
		cin >> x >> y;
		rockets.push_back({x, y});
	}
	
	sort(rockets.begin(), rockets.end(), compareRockets);
	
	unsigned long width = 0;
	unsigned result = 0;
	size_t rocketI = 0;
	
	for (size_t i = 0; i < n; ++i) {
		width += buildings[i].second;
		
		while (rocketI < m && rockets[rocketI].first <= width) {
			if (rockets[rocketI].second <= buildings[i].first) {
				++result;
			}
			
			rocketI += rockets[rocketI].first != width;
		}
	}
	
	cout << result;
	return 0;
}