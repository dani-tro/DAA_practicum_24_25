#include<bits/stdc++.h>
using namespace std;

struct event {
    unsigned x, y;
    bool is_rocket;

    bool operator<(const event& other) {
        return x < other.x || x == other.x && y > other.y || x == other.x && y == other.y && !is_rocket;
    }
};

event events[600010];

int main() {
    size_t n, m;
    cin >> n >> m;
    
    for (size_t i = 0; i < n; ++i) {
        cin >> events[i + 1].x >> events[i].y;
        events[i + 1].x += events[i].x;
        events[i].is_rocket = false;
    }
    
    unsigned end = events[n].x;
    
    for (size_t i = 0; i < m; ++i) {
        cin >> events[n + i].x >> events[n + i].y;
        events[n + i].is_rocket = true;
    }
    
    sort(events, events + n + m);
    unsigned result = 0, y = 0;

    for (size_t i = 0; i < n + m; ++i) {
        if (events[i].x > end) {
            break;
        }

        if (!events[i].is_rocket) {
            y = events[i].y;
        } else if (events[i].y <= y) {
            ++result;
        }
    }
    
    cout << result;
    return 0;
}