/* the checker has three arguments:
    - first - name of the input file
    - second - name of the correct output file
    - third - name of the contestant output file */
#include<iostream>
#include<fstream>
#include<vector>
#define MAXN 100000
#define MAXM 200000
#define MAXK 200000
using namespace std;
void output_message (double points, string message) {
    cout << points << endl ;
    cerr << message << endl ;
    exit(0);
}

vector <int> special;
int colors[MAXM];

vector <pair <int, int> > tree[4*(2*MAXK+1)];
void update (int ind, int l, int r, int ql, int qr, pair <int, int> edge) {
    if ((ql<=l)&&(r<=qr)) {
        tree[ind].push_back(edge);
        return ;
    }
    int mid=(l+r)/2;
    if (ql<=mid) update(2*ind+1,l,mid,ql,qr,edge);
    if (qr>=mid+1) update(2*ind+2,mid+1,r,ql,qr,edge);
}
struct change {
    int* addr;
    int val;
};
vector <vector <change> > undo;
void revert () {
    auto changes=undo.back();
    undo.pop_back();
    for (int i=changes.size()-1; i>=0; i--) {
        auto [addr, val]=changes[i];
        *addr=val;
    }
}
int p[MAXN],rank1[MAXN];
int get_root (int v) {
    if (v==p[v]) return v;
    int r=get_root(p[v]);
    return r;
    undo.back().push_back({p+v, p[v]});
    return p[v]=r;
}
void union1 (int u, int v) {
    u=get_root(u); v=get_root(v);
    if (rank1[u]>rank1[v]) swap(u,v);
    undo.back().push_back({p+u, p[u]});
    p[u]=v;
    if (rank1[u]==rank1[v]) {
        undo.back().push_back({rank1+v, rank1[v]});
        rank1[v]++;
    }
}
int n;
bool query () {
    return get_root(0)==get_root(n-1);
}
bool check (int ind, int l, int r) {
    undo.push_back({});
    for (auto edge : tree[ind]) {
        union1(edge.first,edge.second);
    }

    if (l==r) {
        if ((l%2!=0)&&(query()==true)) return false;

        revert();
        return true;
    }
    int mid=(l+r)/2;
    if (check(2*ind+1,l,mid)==false) return false;
    if (check(2*ind+2,mid+1,r)==false) return false;

    revert();
    return true;
}
int main (int argc, char** argv) {
    ifstream inp,ans,out;
    if (argc<4) output_message(0,"The checker needs input file, correct output and contestant output!");
    inp.open(argv[1]);
    if (inp.is_open()==false) output_message(0,"Could not open input file!");
    ans.open(argv[2]);
    if (ans.is_open()==false) output_message(0,"Could not open answer file!");
    out.open(argv[3]);
    if (out.is_open()==false) output_message(0,"Could not open contestant output file!");

    string ans_can;
    if (!(ans >> ans_can )) output_message(0,"Error reading answer file!");
    if ((ans_can!="Yes")&&(ans_can!="No")) output_message(0,"Invalid message in answer file!");
    string out_can;
    if (!(out >> out_can )) output_message(0,"Error reading output file!");
    if (ans_can!=out_can) output_message(0,"Wrong answer!");
    if (ans_can=="No") {
        char temp;
        if (out >> temp) output_message(0,"Extra output!");
        output_message(1,"OK!");
    }

    int m,k;
    if (!(inp >> n >> m >> k)) output_message(0,"Error reading input file!");
    if ((n<1)||(n>MAXN)) output_message(0,"Invalid N!");
    if ((m<1)||(m>MAXM)) output_message(0,"Invalid M!");
    if ((k<1)||(k>m)) output_message(0,"Invalid K!");
    special.reserve(m);
    for (int i=0; i<m; i++) {
        int x,y,t;
        if (!(inp >> x >> y >> t)) output_message(0,"Error reading input file!");
        if ((x<1)||(x>n)) output_message(0,"Invalid x_i!");
        if ((y<1)||(y>n)) output_message(0,"Invalid y_i!");
        if (x==y) output_message(0,"x_i is equal to y_i!");
        if ((t!=0)&&(t!=1)) output_message(0,"Invalid t_i!");
        x--; y--;
        if (t==0) update(0,0,2*k,0,2*k,{x, y});
        if (t==1) {
            int c;
            if (!(out >> c)) output_message(0,"Error reading output file!");
            if ((c<1)||(c>k)) output_message(0,"Wrong answer!");
            update(0,0,2*k,0,2*(c-1),{x, y});
            update(0,0,2*k,2*c,2*k,{x, y});
        }
    }
    char temp;
    if (inp >> temp) output_message(0,"Extra input!");
    if (out >> temp) output_message(0,"Extra output!");

    for (int i=0; i<n; i++) {
        p[i]=i;
    }
    if (check(0,0,2*k)==true) output_message(1,"OK!");
    else output_message(0,"Wrong answer!");
    return 0;
}
