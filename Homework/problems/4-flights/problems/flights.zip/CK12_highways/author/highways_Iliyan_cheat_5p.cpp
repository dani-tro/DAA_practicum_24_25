#include<iostream>
#include<unordered_set>
#include<algorithm>
#include<vector>
#define MAXN 100000
#define MAXM 200000
using namespace std;
vector <pair <int, int> > a[MAXN];
int ans[MAXM],n,k;
bool seen[MAXN];
void dfs0 (int vr) {
    seen[vr]=true;
    for (auto [to, num] : a[vr]) {
        if ((num>=0)||(seen[to]==true)) continue;
        dfs0(to);
    }
}
vector <vector <int> > paths;
vector <int> path;
void find_paths (int vr) {
    seen[vr]=true;
    if (vr==n-1) {
        paths.push_back(path);
        return ;
    }
    for (auto [to, num] : a[vr]) {
        if (seen[to]==true) continue;
        if (num>=0) path.push_back(num);
        find_paths(to);
        path.pop_back();
    }
    seen[vr]=false;
}
bool flag=true;
unordered_set <int> used;
void dfs (int vr, int prv, int col, int dep) {
    if ((vr==n-1)&&(dep<k)) flag=false;
    used.insert(col*n+vr);
    for (auto [to, num] : a[vr]) {
        if (to==prv) continue;
        if (num>=0) ans[num]=col+1;
        int nxt=(col+(num>=0))%k;
        if (used.count(nxt*n+to)==1) continue;
        dfs(to,vr,nxt,dep+(num>=0));
    }
}
bool col[MAXM];
int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int m;
    cin >> n >> m >> k ;
    int cnt=0;
    for (int i=0; i<m; i++) {
        int x,y,t;
        cin >> x >> y >> t ;
        x--; y--;
        a[x].push_back({y, (t==true)?cnt:-1});
        a[y].push_back({x, (t==true)?cnt++:-1});
    }
    dfs0(0);
    if (seen[n-1]==true) {
        cout << "No\n";
        return 0;
    }
    for (int i=0; i<n; i++) {
        seen[i]=true;
    }
    find_paths(0);
    for (int i=0; i<n; i++) {
        sort(a[i].begin(),a[i].end(),[](pair <int, int> l, pair <int, int> r){
             if (l.second<r.second) return true;
             if ((l.second==r.second)&&(l.first<r.first)) return true;
             return false;
        });
    }
    dfs(0,-1,0,0);
    if (flag==true) {
        for (auto path : paths) {
            for (int i=0; i<k; i++) {
                col[i]=false;
            }
            for (auto num : path) {
                col[ans[num]-1]=true;
            }
            bool flag=true;
            for (int i=0; i<k; i++) {
                if (col[i]==false) {
                    flag=false;
                    break;
                }
            }
            if (flag==false) {
                cout << "No\n";
                return 0;
            }
        }
    }
    if (flag==true) {
        cout << "Yes\n";
        for (int i=0; i<cnt; i++) {
            cout << ans[i] << " ";
        }
    }
    else cout << "No";
    cout << endl ;
    return 0;
}
