# include <bits/stdc++.h>
using namespace std;
const int maxn = 4e5;
vector <pair <int, int> > g[maxn];
int dist[maxn];
void dijkstra(int from)
{
    priority_queue <pair <int, int>, vector <pair <int, int> >, greater<pair<int, int> > > q;
    q.push({ 0, from});
    for (int i = 0; i < maxn; i++)
        dist[i] = INT_MAX;
    dist[from] = 0;
    while (!q.empty())
    {
        int u = q.top().second;
        int d = q.top().first;
        q.pop();
        if (dist[u] < d)
            continue;
        for (auto v : g[u])
        {
            if (dist[v.first] <= d + v.second)
                continue;
            dist[v.first] = d + v.second;
            q.push({dist[v.first], v.first});
        }
    }
}
vector <pair <pair <int, int>, int> > edges;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, k;
    int u, v, w;
    cin >> n >> m >> k;
    int from, to;
    from = 1;
    to = n;
    for (int i = 0; i < m; i++)
    {
        cin >> u >> v >> w;
        edges.push_back({{u, v}, w});
        g[u].push_back({v, w});
        g[v].push_back({u, w});
    }
    
    dijkstra(from);
    if (dist[to] < k)
    {
        cout << "No\n";
        return 0;
    }
    cout << "Yes\n";
    for (auto e : edges)
    {
        if (e.second == 0) continue;
        int u = e.first.first, v = e.first.second;
        int maxs = max(dist[u], dist[v]);
        if (maxs > k) maxs = k;
        cout << maxs << '\n';
    }
}