# include <bits/stdc++.h>
using namespace std;
const int maxn = 4e6;
vector <pair <int, int> > g[maxn];
int dist[maxn];
int vis[maxn], ids;
void bfs(int from, int col)
{
    queue <int> q;
    q.push(from);
    ids++;
    vis[from] = ids;
    while(!q.empty())
    {
        int u = q.front();
        q.pop();
        for (auto v : g[u])
        {
            if (vis[v.first] != ids && v.second != col)
            {
                vis[v.first] = ids;
                q.push(v.first);
            }

        }
    }
}  

bool check(int n, int k)
{
    for (int i = 1; i <= k; i++)
    {
        bfs(1, i);
        if (vis[n] == ids) return false;
    }
    return true;
}

vector <pair <int, int> > highways;
bool bruteforce(int n, int k, int pos)
{
    if (pos == highways.size())
    {
        if (check(n, k))
        {
            return true;
        }
        return false;
    }
    for (int i = 1; i <= k; i++)
    {
        g[highways[pos].first][highways[pos].second].second = i;
        g[highways[pos+1].first][highways[pos+1].second].second = i;
        
        if (bruteforce(n, k, pos + 2)) return true;
    }
    return false;
}
vector <pair <pair <int, int>, int> > edges;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, k;
    int u, v, w;
    cin >> n >> m >> k;
    int from, to;
    from = 1;
    to = n;
    for (int i = 0; i < m; i++)
    {
        cin >> u >> v >> w;
        edges.push_back({{u, v}, w});
        g[u].push_back({v, w});
        g[v].push_back({u, w});
        if (w == 0) continue;
        highways.push_back({u, g[u].size()-1});
        highways.push_back({v, g[v].size()-1});

    }

    
    if (bruteforce(n, k, 0) == false)
    {
        cout << "No\n";
        return 0;
    }
    else
    {
        cout << "Yes\n";
        for (int i = 0; i < highways.size(); i+=2)
        {
            auto e = highways[i];
            cout << g[e.first][e.second].second << '\n';
        }

    }
    //  cout << dist[to] << endl;


    // for (int i = 1; i <= n; i++)
    //      cout << i << " " << dist[i] << endl;

}