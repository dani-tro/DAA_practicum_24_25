#include<iostream>
#include<vector>
#include<deque>
#define MAXN 100000
using namespace std;
vector <pair <int, bool> > a[MAXN];
vector <pair <int, int> > special;
bool used[MAXN];
int dist[MAXN];
int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n,m,k;
    cin >> n >> m >> k ;
    special.reserve(m);
    for (int i=0; i<m; i++) {
        int x,y,t;
        cin >> x >> y >> t ;
        x--; y--;
        a[x].push_back({y, t});
        a[y].push_back({x, t});
        if (t==1) special.push_back({x, y});
    }

    deque <int> bfs;
    bfs.push_back(0);
    dist[0]=1;
    for (;;) {
        if (bfs.empty()==true) break;
        auto vr=bfs.front();
        if (dist[vr]==dist[n-1]) break;
        bfs.pop_front();
        if (used[vr]==true) continue;
        used[vr]=true;
        for (auto [to, t] : a[vr]) {
            if ((dist[to]==0)||(dist[to]>dist[vr]+t)) {
                dist[to]=dist[vr]+t;
                if (t==0) bfs.push_front(to);
                else bfs.push_back(to);
            }
        }
    }
    if (dist[n-1]-1<k) {
        cout << "No\n";
        return 0;
    }
    cout << "Yes\n";
    for (auto [x, y] : special) {
        if ((dist[x]==0)||(dist[y]==0)||(dist[x]==dist[y])||(min(dist[x],dist[y])>k)) {
            cout << 1 << " ";
            continue;
        }
        cout << min(dist[x],dist[y]) << " ";
    }
    cout << endl ;
    return 0;
}
