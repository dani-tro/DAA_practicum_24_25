#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll head[100005+1];
ll to[2*200005], nxt[2*200005], edge_cnt;

ll Fu[200005], Fv[200005], mnv[200005], mxv[200005], Fcnt;

ll q[100005+1], dista[100005+1];

ll diffarr[100005+2];
ll non_empty[100005+1];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll N, M, K;
    cin >> N >> M >> K;

    memset(head, -1, sizeof head);
    edge_cnt = 0;
    Fcnt = 0;

    for(ll i = 0; i < M; i++){
        ll u,v,w;
        cin >> u >> v >> w;
        to[edge_cnt]   = v;
        nxt[edge_cnt]  = head[u];
        head[u]        = edge_cnt++;
        to[edge_cnt]   = u;
        nxt[edge_cnt]  = head[v];
        head[v]        = edge_cnt++;

        if (w == 1) {
            Fu[Fcnt] = u;
            Fv[Fcnt] = v;
            ++Fcnt;
        }
    }

    memset(dista, -1, sizeof(ll)*(N+1));
    ll ql = 0, qr = 0;
    dista[1] = 0;
    q[qr++] = 1;
    while(ql < qr){
        ll x = q[ql++];
        for(ll ei = head[x]; ei != -1; ei = nxt[ei]){
            ll y = to[ei];
            if (dista[y] == -1){
                dista[y] = dista[x] + 1;
                q[qr++] = y;
            }
        }
    }

    ll D = dista[N];
    if (D < 0 || D < K) {
        cout << "No\n";
        return 0;
    }

    for(ll i = 0; i <= D; i++) 
        diffarr[i] = 0;

    for(ll i = 0; i < Fcnt; i++){
        ll du = dista[Fu[i]], dv = dista[Fv[i]];
        if (du < 0 || dv < 0){
            mnv[i] = mxv[i] = -1;
            continue;
        }
        ll mn = min(du,dv), mx = max(du,dv);
        if (mn < mx){
            mnv[i] = mn;
            mxv[i] = mx;
            diffarr[mn] += 1;
            diffarr[mx] -= 1;
        } else {
            mnv[i] = mxv[i] = -1;
        }
    }

    ll got = 0, cur = 0;
    for(ll i = 0; i < D && got < K; i++){
        cur += diffarr[i];
        if (cur > 0){
            non_empty[got++] = i;
        }
    }
    if (got < K){
        cout << "No\n";
        return 0;
    }

    cout << "Yes\n";
    for(ll i = 0; i < Fcnt; i++){
        ll mn = mnv[i], mx = mxv[i];
        ll comp = 1;  // default to company 1
        if (mn >= 0) {
            ll lo = 0, hi = K-1;
            while(lo < hi){
                ll mid = (lo + hi) >> 1;
                if (non_empty[mid] < mn) lo = mid + 1;
                else hi = mid;
            }
            if (non_empty[lo] < mx)
                comp = lo + 1;
        }
        cout << comp << "\n";
    }

    return 0;
}