#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M, K;
    cin >> N >> M >> K;

    vector<vector<int>> adj(N+1);
    struct Flight { int u, v; };
    vector<Flight> flights;
    flights.reserve(M);

    for(int i = 0; i < M; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back(v);
        adj[v].push_back(u);
        if (w == 1) {
            flights.push_back({u, v});
        }
    }

    vector<int> dist(N+1, -1);
    deque<int> dq;
    dist[1] = 0;
    dq.push_back(1);
    while(!dq.empty()){
        int u = dq.front(); dq.pop_front();
        for(int v: adj[u]){
            if(dist[v] == -1){
                dist[v] = dist[u] + 1;
                dq.push_back(v);
            }
        }
    }

    int D = dist[N];
    if (D < 0 || D < K) {
        cout << "No\n";
        return 0;
    }

    vector<ll> diff(D+1, 0);
    int F = flights.size();
    vector<int> mnv(F), mxv(F);
    for(int i = 0; i < F; i++){
        int u = flights[i].u, v = flights[i].v;
        int du = dist[u], dv = dist[v];
        if (du < 0 || dv < 0) {
            mnv[i] = mxv[i] = -1;
            continue;
        }
        int mn = min(du, dv);
        int mx = max(du, dv);
        if (mn < mx) {
            mnv[i] = mn;
            mxv[i] = mx;
            diff[mn] += 1;
            diff[mx] -= 1;
        } else {
            mnv[i] = mxv[i] = -1;
        }
    }

    vector<int> non_empty;
    non_empty.reserve(D);
    ll cur = 0;
    for(int i = 0; i < D; i++){
        cur += diff[i];
        if (cur > 0) {
            non_empty.push_back(i);
            if ((int)non_empty.size() == K) break;
        }
    }

    if ((int)non_empty.size() < K) {
        cout << "No\n";
        return 0;
    }

    non_empty.resize(K);

    cout << "Yes\n";
    for(int i = 0; i < F; i++){
        int mn = mnv[i], mx = mxv[i];
        int comp = 1;
        if (mn >= 0) {
            int j = int(std::lower_bound(non_empty.begin(), non_empty.end(), mn)
                        - non_empty.begin());
            if (j < K && non_empty[j] < mx) {
                comp = j + 1;
            }
        }
        cout << comp << "\n";
    }

    return 0;
}
