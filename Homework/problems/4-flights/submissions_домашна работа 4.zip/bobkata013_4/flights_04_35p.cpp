#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll head[100006], to[2*200005], nxt[2*200005], ecnt;
ll Fu[200005], Fv[200005], mnv[200005], mxv[200005], Fcnt;
ll q[100006], dista[100006];
ll diffarr[100008], non_empty[100006];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    ll N, M, K;
    cin >> N >> M >> K;

    fill(head+1, head+N+1, -1);
    ecnt = 0;
    Fcnt = 0;

    for(ll i = 0; i < M; i++){
        ll u, v, w;
        cin >> u >> v >> w;
        to[ecnt]  = v;
        nxt[ecnt] = head[u];
        head[u]   = ecnt++;
        to[ecnt]  = u;
        nxt[ecnt] = head[v];
        head[v]   = ecnt++;

        if (w == 1) {
            Fu[Fcnt] = u;
            Fv[Fcnt] = v;
            ++Fcnt;
        }
    }

    memset(dista+1, -1, N * sizeof(ll));
    ll ql = 0, qr = 0;
    dista[1] = 0;
    q[qr++] = 1;
    while(ql < qr){
        ll x = q[ql++];
        for(ll e = head[x]; e != -1; e = nxt[e]){
            ll y = to[e];
            if (dista[y] == -1){
                dista[y] = dista[x] + 1;
                q[qr++] = y;
            }
        }
    }

    ll D = dista[N];
    if (D < 0 || D < K) {
        cout << "No\n";
        return 0;
    }

    for(ll i = 0; i <= D; i++) 
        diffarr[i] = 0;

    for(ll i = 0; i < Fcnt; i++){
        ll du = dista[Fu[i]], dv = dista[Fv[i]];
        if (du < 0 || dv < 0) {
            mnv[i] = mxv[i] = -1;
            continue;
        }
        ll mn = du < dv ? du : dv;
        ll mx = du < dv ? dv : du;
        if (mn < mx) {
            mnv[i] = mn;
            mxv[i] = mx;
            diffarr[mn] += 1;
            diffarr[mx] -= 1;
        } else {
            mnv[i] = mxv[i] = -1;
        }
    }

    ll got = 0, cur = 0;
    for(ll i = 0; i < D && got < K; i++){
        cur += diffarr[i];
        if (cur > 0) {
            non_empty[got++] = i;
        }
    }
    if (got < K) {
        cout << "No\n";
        return 0;
    }

    cout << "Yes\n";
    for(ll i = 0; i < Fcnt; i++){
        ll comp = 1;
        ll mn = mnv[i], mx = mxv[i];
        if (mn >= 0) {
            ll lo = 0, hi = K-1;
            while(lo < hi){
                ll mid = (lo + hi) >> 1;
                if (non_empty[mid] < mn) lo = mid + 1;
                else hi = mid;
            }
            if (non_empty[lo] < mx)
                comp = lo + 1;
        }
        cout << comp << "\n";
    }
    return 0;
}