#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct DSU {
    vector<long> p, sz;
    DSU(long n = 0) : p(n+1), sz(n+1,1) { iota(p.begin(), p.end(), 0); }
    long find(long x){ return p[x]==x? x : p[x]=find(p[x]); }
    void unite(long a,long b){
        a=find(a); b=find(b);
        if(a==b) return;
        if(sz[a]<sz[b]) swap(a,b);
        p[b]=a; sz[a]+=sz[b];
    }
};

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    long N,M,K;
    if(!(cin>>N>>M>>K)) return 0;

    struct E{long u,v,w;};
    vector<E> edges(M);
    for(long i=0;i<M;i++){
        cin>>edges[i].u>>edges[i].v>>edges[i].w;
    }

    DSU dsu(N);
    for(auto &e:edges)
        if(e.w==0) dsu.unite(e.u,e.v);

    long S = dsu.find(1);
    long T = dsu.find(N);
    if(S==T){ cout<<"No\n"; return 0; }

    vector<long> compId(N+1,-1);
    long C=0;
    for(long v=1;v<=N;v++){
        long rt = dsu.find(v);
        if(compId[rt]==-1) compId[rt]=C++;
    }
    S = compId[S];
    T = compId[T];

    vector<vector<pair<long,long>>> adj(C);          
    vector<pair<long,long>> flightEnds;             
    flightEnds.reserve(M);
    vector<long> flightIdx;  flightIdx.reserve(M);  
    for(long i=0;i<M;i++){
        if(edges[i].w==0){
            flightIdx.push_back(-1);
            continue;
        }
        long a = compId[ dsu.find(edges[i].u) ];
        long b = compId[ dsu.find(edges[i].v) ];
        long id = (long)flightEnds.size();
        flightIdx.push_back(id);
        flightEnds.push_back({a,b});
        adj[a].push_back({b,id});
        adj[b].push_back({a,id});
    }
    long F = (long)flightEnds.size();

    const long INF = 1e9;
    vector<long> dist(C, INF);
    queue<long> q;
    dist[S]=0; q.push(S);
    while(!q.empty()){
        long v=q.front(); q.pop();
        for(auto [to, idx]: adj[v]){
            if(dist[to]==INF){
                dist[to]=dist[v]+1;
                q.push(to);
            }
        }
    }
    if(dist[T]==INF || dist[T] < K){
        cout<<"No\n"; return 0;
    }

    vector<long> company(F, 1);             
    for(long id=0; id<F; ++id){
        auto [a,b] = flightEnds[id];
        if(dist[a]==INF || dist[b]==INF){        
            company[id]=1;
        }else{
            long d = min(dist[a], dist[b]);
            company[id] = min(d+1, K);         
        }
    }

    cout<<"Yes\n";
    for(long i=0;i<M;i++){
        if(edges[i].w==0) continue; 
        long id = flightIdx[i];
        cout<<company[id]<<"\n";
    }
    return 0;
}
