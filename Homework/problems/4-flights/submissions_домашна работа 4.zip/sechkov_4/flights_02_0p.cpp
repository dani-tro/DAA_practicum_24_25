#include <bits/stdc++.h>
using namespace std;

const int maxN = 1e5 + 10;
const int maxM = 2e5 + 10;

int n, m, k;
vector<pair<int, int*>> g[maxN];
bool vis[maxN];

struct Edge {
    int u;
    int v;
    int w;
};

Edge e[maxM];

bool bfs(int s) {
    queue<int> q;
    q.push(s);
    
    int last = s;
    bool ok;
    int comp = 0;
    bool possible = false;
    
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        
        if (vis[v]) {
            continue;
        }
        
        if (last == v) {
            ok = true;
            comp++;
        } else {
            ok = false;
        }
        
        vis[v] = true;
        
        for (auto p : g[v]) {
            int u = p.first;
            int* w = p.second;
            
            if (vis[u]) continue;
            
            if (ok) {
                last = u;
            }
            
            q.push(u);
            
            if (*w == 1) {
                *w = comp % k;
            }
        }
        
        ok = false;
        
        if (comp == k) {
            possible = true;
        }
    }
    
    return possible;
}

int main() {
    
    cin >> n >> m >> k;
    
    for (int i = 0; i < m; i++) {
        cin >> e[i].u >> e[i].v >> e[i].w;
        g[e[i].u].push_back({e[i].v, &e[i].w});
        g[e[i].v].push_back({e[i].u, &e[i].w});
    }
    
    /***
    if (bfs(1)) {
        cout << "Yes" << endl;
        for (int i = 0; i < m; i++) {
            if (e[i].w == 0) continue;
            cout << e[i].w << endl;
        }
        
    } else {
        cout << "No" << endl;
    }
    ***/
    
    cout << "No" << endl;
    
    return 0;
}