#include <bits/stdc++.h>
using namespace std;

const int maxN = 1e5 + 10;
const int maxM = 2e5 + 10;

int n, m, k;
vector<pair<int, int&>> g[maxN];
bool vis[maxN];
int dist[maxN];

struct Edge {
    int u;
    int v;
    int w;
};

Edge e[maxM];

bool dijkstra(int s) {
    priority_queue<pair<long long, int>> q;
    q.push({0, s});
    
    for (int i = 1; i <= n; i++) {
        dist[i] = -1;
    }
    
    dist[s] = 0;
    
    while (!q.empty()) {
        pair<long long, int> v = q.top();
        q.pop();
        if (vis[v.second]) {
            continue;
        }
        
        vis[v.second] = true;
        
        for (auto u : g[v.second]) {
            if (vis[u.first]) continue;
            
            if (dist[u.first] == -1 || dist[u.first] > dist[v.second] + u.second) {
                dist[u.first] = dist[v.second] + u.second;
                q.push({-dist[u.first], u.first});
            }
        }
    }
    
    if (dist[n] >= k) {
        return true;
    }
    
    return false;
}

int main() {
    
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    cin >> n >> m >> k;
    
    for (int i = 0; i < m; i++) {
        cin >> e[i].u >> e[i].v >> e[i].w;
        g[e[i].u].push_back({e[i].v, e[i].w});
        g[e[i].v].push_back({e[i].u, e[i].w});
    }
    
    if (dijkstra(1)) {
        cout << "Yes" << endl;
        for (int i = 0; i < m; i++) {
            if (e[i].w == 0) continue;
            int x = max(dist[e[i].u], dist[e[i].v]) % k;
            if (x % k == 0) {
                cout << k << endl;
            } else {
                cout << x % k << endl;
            }
        }
        
    } else {
        cout << "No" << endl;
    }
    
    return 0;
}