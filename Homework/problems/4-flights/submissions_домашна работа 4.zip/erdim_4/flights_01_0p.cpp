#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 10;
const int MAXM = 2e5 + 10;
const int INF = 1e9;
struct Edge
{
    int ver, line, idx;
};
vector<Edge> v[MAXN];

struct InputEdge
{
    int from, to, line;
};
vector<InputEdge> edges;

int dist[MAXN];

int dijkstra(int from, int n)
{
    for (int i = 1; i <= n; i++)
        dist[i] = INF;
    dist[from] = 0;
    priority_queue<pair<int, int>> pq;
    pq.push({0, from});

    while (!pq.empty())
    {
        int ver = pq.top().second, lines = -pq.top().first;
        pq.pop();
        if (dist[ver] != lines)
            continue;
        for (Edge edge : v[ver])
        {
            int to = edge.ver, weight = edge.line;
            if (dist[to] > dist[ver] + weight)
            {
                dist[to] = dist[ver] + weight;
                pq.push({-dist[to], to});
            }
        }
    }

    return dist[n];
}

bool vis[MAXN];
int lines[MAXM];
void bfs(int ver, int k)
{
    queue<pair<int, int>> q;
    q.push({k, ver});
    vis[ver] = true;

    while (!q.empty())
    {
        pair<int, int> front = q.front();
        q.pop();
        int ver = front.second, line = front.first;
        for (Edge edge : v[ver])
        {
            int to = edge.ver, idx = edge.idx;
            if (edge.line == 1 && lines[idx] == 0)
                lines[idx] = line;
            if (!vis[to])
            {
                vis[to] = true;
                q.push({line - edge.line, to});
            }
        }
    }

    for (int i = 0; i < edges.size(); i++)
    {
        if (edges[i].line == 0)
            continue;
        if (lines[i + 1] == 0)
            lines[i + 1] = 1;
        cout << lines[i + 1] << "\n";
    }
}

int main()
{
    int n, m, k;
    cin >> n >> m >> k;
    for (int i = 1; i <= m; i++)
    {
        int p, q, l;
        cin >> p >> q >> l;
        v[p].push_back({q, l, i});
        v[q].push_back({p, l, i});
        edges.push_back({p, q, l});
    }

    int shortest = dijkstra(1, n);

    if (shortest < k)
    {
        cout << "No" << endl;
        return 0;
    }

    cout << "Yes" << endl;
    bfs(n, k);

    return 0;
}