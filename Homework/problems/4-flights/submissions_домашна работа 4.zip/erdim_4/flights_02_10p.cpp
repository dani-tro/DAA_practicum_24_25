#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 10;
const int MAXM = 2e5 + 10;
const int INF = 1e9;
struct Edge
{
    int ver, line, idx;
};
vector<Edge> v[MAXN];

struct InputEdge
{
    int from, to, line;
};
vector<InputEdge> edges;

int dist[MAXN];

int dijkstra(int from, int n)
{
    for (int i = 1; i <= n; i++)
        dist[i] = INF;
    dist[from] = 0;
    priority_queue<pair<int, int>> pq;
    pq.push({0, from});

    while (!pq.empty())
    {
        int ver = pq.top().second, lines = -pq.top().first;
        pq.pop();
        if (dist[ver] != lines)
            continue;
        for (Edge edge : v[ver])
        {
            int to = edge.ver, weight = edge.line;
            if (dist[to] > dist[ver] + weight)
            {
                dist[to] = dist[ver] + weight;
                pq.push({-dist[to], to});
            }
        }
    }

    return dist[n];
}

void distribute(int k)
{
    for (auto edge : edges)
    {
        if (edge.line == 0)
            continue;
        int line = min(dist[edge.from], dist[edge.to]);
        if (line >= k)
            line = 1;
        cout << line + 1 << endl;
    }
}

int main()
{
    int n, m, k;
    cin >> n >> m >> k;
    for (int i = 1; i <= m; i++)
    {
        int p, q, l;
        cin >> p >> q >> l;
        v[p].push_back({q, l, i});
        v[q].push_back({p, l, i});
        edges.push_back({p, q, l});
    }

    int shortest = dijkstra(1, n);

    if (shortest < k)
    {
        cout << "No" << endl;
        return 0;
    }

    cout << "Yes" << endl;
    distribute(k);

    return 0;
}