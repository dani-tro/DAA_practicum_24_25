//
// Created by galya777 on 18.05.25.
//
#include <vector>
#include <iostream>
using namespace std;

long long int n,m;
vector<int> positions(n);
vector<tuple<int, int, int>> edges(m); // всеки портал: от, до, ширина


vector<vector<int>> graph;
vector<bool> visited;

void dfs(int node) {
    visited[node] = true;
    cout << node << " ";

    for (int neighbor : graph[node]) {
        if (!visited[neighbor]) {
            dfs(neighbor);
        }
    }
}
void dfs_mark(int node, int cid, vector<int>& comp) {
    visited[node] = true;
    comp[node] = cid;
    for (int neighbor : graph[node]) {
        if (!visited[neighbor]) {
            dfs_mark(neighbor, cid, comp);
        }
    }
}

int main(){
    std::ios::sync_with_stdio(false); // Оптимизираме вход/изход
    std::cin.tie(NULL); // Развързваме cin и cout
    cin >> n >> m;
for (int i = 0; i < n; i++) {
    cin >> positions[i];
}
for (int i = 0; i < m; i++) {
    cin >> std::get<0>(edges[i]) >> std::get<1>(edges[i]) >> std::get<2>(edges[i]);
}
long long int answer = -1;
    long long left = 0, right = 1e9;

    while (left <= right) {
        long long mid = (left + right) / 2;
        graph.assign(n + 1, vector<int>());
        for (auto [a, b, w] : edges) {
            if (w >= mid) {
                graph[a].push_back(b);
                graph[b].push_back(a);
            }
        }
        visited.assign(n + 1, false);
        vector<int> component_id(n + 1, -1);
        int cid = 0;

        for (int i = 1; i <= n; i++) {
            if (!visited[i]) {
                dfs_mark(i, cid, component_id);
                cid++;
            }
        }
        bool ok = true;
        for (int i = 1; i <= n; i++) {
            if (component_id[i] != component_id[positions[i - 1]]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            answer = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

cout << answer;
    
    return 0;
}