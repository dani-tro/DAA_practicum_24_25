//
// Created by galya777 on 18.05.25.
//
#include <iostream>
#include <vector>
#include <tuple>

using namespace std;

int n, m, k;
vector<vector<int>> graph;
vector<pair<int, int>> train_lines;
vector<pair<int, int>> flight_corridors;
void dfs(int u, vector<vector<int>>& g, vector<bool>& vis) {
    vis[u] = true;
    for (int v : g[u]) {
        if (!vis[v]) dfs(v, g, vis);
    }
}


int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin>>n>>m>>k;
    vector<tuple<int, int, int>> roads;
    for (int i = 0; i < m; ++i) {
        int u, v, w;
        cin>>u>>v>>w;
        roads.emplace_back(u, v, w);
        if (w == 0) train_lines.emplace_back(u, v);
        else flight_corridors.emplace_back(u, v);
    }
    int num_corridors = flight_corridors.size();

     bool found = false;
    for (int mask = 0; mask < (1 << (k * num_corridors)); ++mask) {
        vector<vector<pair<int, int>>> company_edges(k);
        vector<int> assigned_company(num_corridors, -1); // индекс i -> компания j
        bool all_necessary = true;
        for (int i = 0; i < num_corridors; ++i) {
            int c = (mask >> (i * 2)) & ((1 << 2) - 1); // ако k <= 4
            if (c >= k) continue;
            assigned_company[i] = c;
            company_edges[c].push_back(flight_corridors[i]);
        }


        for (int company = 0; company < k; ++company) {
            // Създай граф само от ЖП линии + летателни коридори на всички други компании
            vector<vector<int>> g(n + 1);

            // Добави ЖП линиите
            for (auto [u, v]: train_lines) {
                g[u].push_back(v);
                g[v].push_back(u);
            }

            // Добави летателните коридори на ВСИЧКИ компании, освен тази
            for (int other = 0; other < k; ++other) {
                if (other == company) continue;
                for (auto [u, v]: company_edges[other]) {
                    g[u].push_back(v);
                    g[v].push_back(u);
                }
            }

            // DFS или BFS за проверка дали има път от 1 до N
            vector<bool> visited(n + 1, false);
            dfs(1, g, visited); // или bfs(1, g, visited)

            if (visited[n]) {
                all_necessary = false; // компанията НЕ е задължителна
                break;
            }
        }

// Ако всяка компания е задължителна → намерено решение
        if (all_necessary) {
            cout << "Yes\n";
            for (int i = 0; i < num_corridors; ++i) {
                cout << assigned_company[i] + 1 << " "; // индексиране от 1
            }
            cout << "\n";
            found = true;
            break;
        }
    }
if(!found){
    cout<<"No\n";
}

    return 0;
}