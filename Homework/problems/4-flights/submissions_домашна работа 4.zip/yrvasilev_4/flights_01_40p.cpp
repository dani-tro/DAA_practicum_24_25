#include<iostream>
#include<string>
#include<cstdio>
#include<cmath>
#include<stack>
#include<queue>
#include<algorithm>
#define MAX 100005
using namespace std;
int  n, m, k, ans[2*MAX], br=0, v1, v2, w ,t, best[MAX], cr, d;
bool fl[MAX], flag;
vector < pair<int, int> > v[MAX];
queue <int> q;
int main (){
    int i,j=0, u, to;
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin>>n>>m>>k;
    for(i=0;i<m;i++){
        cin>>v1>>v2>>t;
        if(t!=0)t=++br;
        v[v1].push_back({v2,t});
        v[v2].push_back({v1,t});
    }

    q.push(1);
    fill(best+1,best+n+1,MAX);
    
    best[1]=0;
    while(!q.empty()){
        u=q.front(); q.pop(); 
        if(fl[u])continue; 
        fl[u]=true;
        //cout <<"u="<<u<<", path="<<best[u]<< " "<< endl;
        for(pair<int, int> p : v[u]){
            to=p.first;
            //cout<<"to="<<to<<" "<<p.second<<endl;
            if(fl[to] && p.second!=0) ans[p.second]=best[to]+1;
            else{
                d=best[u];
                if(p.second!=0) ans[p.second]=++d;
                q.push(to); best[to]=min(best[to],d);
            }
        }
        //for(i=1;i<=br;i++)cout<<min(ans[i],k)<<" "; cout<<endl;
    }
    if(best[n]<k || best[n]==MAX) {cout<<"No\n"; return 0;}//==MAX -> not connected
    cout<<"Yes\n";
    for(i=1;i<=br;i++)cout<<min(ans[i],k)<<"\n";// cout<<endl;
    
    return 0;
}

/*
6 6 3
1 4 1
1 5 1
2 3 0
2 4 1
4 5 0
6 3 1
*/





/*
while(!q.empty()){
        u=q.front(); q.pop(); 
        if(fl[u])continue; 
        fl[u]=true;
        cr=3*MAX;
        cout<<"u="<<u<<endl;
        for(pair<int, int> p : v[u]){
            to=p.first;
            cout<<"to="<<to<<" "<<p.second<<endl;
            if(fl[to]) {
                cr=min(cr, best[to]);
                if(p.second!=0) ans[p.second]=best[to]+1;
            }
            else{
                //if(p.second!=0) ans[p.second]=best[]+1;
                q.push(to);
            }
        }
        best[u]=cr+1;
        cout <<"u="<<u<<" "<<best[u]<< endl;
    }


*/