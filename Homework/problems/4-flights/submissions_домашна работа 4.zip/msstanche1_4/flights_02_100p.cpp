#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <climits>

using namespace std;

int n, m, k;

struct Edge
{
	int v;
	bool type;
};

const int maxn = 1e5 + 10;
vector<Edge> gr[maxn];
int dist[maxn];

struct Edge2
{
	int u, v, comp;
};
vector<Edge2> edges;
bool used[maxn];

void bfs01()
{
	deque<Edge> dq;
	fill(dist, dist + maxn, INT_MAX);
	dist[1] = 0;
	for (auto p : gr[1])
	{
		if (p.type == 0)
		{
			dq.push_front(p);
			dist[p.v] = 0;
		}
		else
		{
			dq.push_back(p);
			dist[p.v] = 1;
		}
	}
	while (!dq.empty())
	{
		Edge e = dq.front();
		dq.pop_front();
		if (used[e.v])
			continue;
		used[e.v] = true;
		for (auto p : gr[e.v])
		{
			if (!used[p.v])
			{
				if (dist[p.v] > dist[e.v] + p.type)
				{
					dist[p.v] = dist[e.v] + p.type;
					if (p.type == 0)
						dq.push_front(p);
					else
						dq.push_back(p);
				}
			}
		}
	}
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m >> k;
	int x, y;
	bool type;
	for (int i = 0; i < m; i++)
	{
		cin >> x >> y >> type;
		if (type == 0)
		{
			gr[x].push_back({ y, 0 });
			gr[y].push_back({ x, 0 });
		}
		else
		{
			edges.push_back({ x, y, -1 });
			gr[x].push_back({ y, 1 });
			gr[y].push_back({ x, 1 });
		}
	}
	bfs01();
	if (dist[n] < k)
	{
		cout << "No" << endl;
		return 0;
	}
	for (Edge2 &e : edges)
	{
		int maxDist = max(dist[e.u], dist[e.v]);
		if (maxDist > k)
		{
			e.comp = 1;
		}
		else
		{
			e.comp = maxDist;
		}
	}
	cout << "Yes\n";
	for (Edge2& e : edges)
	{
		cout << e.comp << "\n";
	}
	return 0;
}