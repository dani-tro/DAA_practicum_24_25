#include <bits/stdc++.h>

#define PA pair<int, int>
using namespace std;
const int maxn = 2e5 + 10;

vector<PA> graph[maxn];
int dist[maxn];
int n, m, k, u, v, w, source, endd;
vector<pair<PA, int>> edges;

void dijkstra(int source)
{
    priority_queue<PA, vector<PA>, greater<PA>> pq;
    pq.push({0, source});

    for (int i = 0; i < maxn; i++)
        dist[i] = INT_MAX;
    dist[source] = 0;

    while (!pq.empty())
    {
        int u = pq.top().second;
        int d = pq.top().first;
        pq.pop();

        if(dist[u] < d)
            continue;
        for (auto v : graph[u])
        {
            if (dist[v.first] > d + v.first)
            {
                dist[v.first] = d + v.second;
                pq.push({dist[v.first], v.first});
            }
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m >> k;
    source = 1;
    endd = n;

    for (int i = 0; i < m; i++)
    {
        cin >> u >> v >> w;
        edges.push_back({{u, v}, w});
        graph[u].push_back({v, w});
        graph[v].push_back({u, w});
    }

    dijkstra(source);
    if (dist[endd] < k)
    {
        cout << "No" << endl;
        return 0;
    }
    cout << "Yes" << endl;
    for (auto e : edges)
    {
        if (e.second == 0) continue;
        int u = e.first.first;
        int v = e.first.second;
        int maxx = max(dist[u], dist[v]);
        if (maxx > k) maxx = k;
        cout << maxx << '\n';
    }

    return 0;
}
