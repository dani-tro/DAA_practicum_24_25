#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 1e5;
const int MAX_M = 2e5;
const int INF = MAX_N + 10;

struct To
{
    int v;
    int ord;
    bool isFlight;

    To(int v, bool isFlight, int ord) : v(v), ord(ord), isFlight(isFlight) {}
};

int n, m, k;
vector<To> g[MAX_N];
int ansLen = 0;
int ans[MAX_M];


void readInput()
{
    cin >>n >>m >>k;

    int from, to;
    bool isFlight;
    for(int i = 0; i < m; ++i)
    {
        cin >>from >>to >>isFlight;
        --from;
        --to;
        g[from].emplace_back(to, isFlight, ansLen);
        g[to].emplace_back(from, isFlight, ansLen);
        ansLen += isFlight;
    }
}

deque<int> q;
int d[MAX_N];

bool bfs01(int s, int e)
{
    fill(d, d + n, INF);
    q.push_back(s);
    d[s] = 0;
    int v;
    while(!q.empty())
    {
        v = q.front();
        q.pop_front();
        for(auto [nb, ord, w] : g[v])
        {
            if(d[v] + w < d[nb])
            {
                d[nb] = d[v] + w;
                if(w) q.push_back(nb);
                else q.push_front(nb);
            }
            if(w && d[v] < d[nb])
            {
                //cout <<"v: " <<v + 1 <<" nb: " <<nb + 1 <<" ord: " <<ord <<" d[v]: " <<d[v] <<" d[nb]: " <<d[nb] <<endl;
                ans[ord] = d[nb];
            }
        }
    }

    return d[e] != INF && d[e] >= k;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    readInput();

    if(!bfs01(0, n - 1))
    {
        cout <<"No" <<endl;
        return 0;
    }

    cout <<"Yes" <<endl;
    for(int i = 0; i < ansLen; ++i)
    {
        cout <<ans[i] <<endl;
    }
}
