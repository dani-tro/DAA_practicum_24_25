#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100005;

int N, M, K;
vector<tuple<int, int, int>> edges;
vector<pair<int, int>> graph[MAXN]; // u -> {v, edge_id}
vector<int> flights_ids;
vector<int> assign; // For each edge, assigned company (only for flight edges)

// Find path from 1 to N
bool dfs(int u, int parent, vector<int>& path, vector<bool>& visited, vector<int>& parent_edge) {
    visited[u] = true;
    if (u == N) return true;
    for (auto [v, id] : graph[u]) {
        if (!visited[v]) {
            parent_edge[v] = id;
            if (dfs(v, u, path, visited, parent_edge)) {
                return true;
            }
        }
    }
    return false;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    cin >> N >> M >> K;
    assign.resize(M, 0);

    for (int i = 0; i < M; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back({u, v, w});
        graph[u].push_back({v, i});
        graph[v].push_back({u, i});
        if (w == 1)
            flights_ids.push_back(i);
    }

    vector<bool> visited(N + 1, false);
    vector<int> parent_edge(N + 1, -1);
    vector<int> path;

    if (!dfs(1, -1, path, visited, parent_edge)) {
        cout << "No\n";
        return 0;
    }

    // Reconstruct path from 1 to N
    int curr = N;
    vector<int> path_flight_ids;
    while (curr != 1) {
        int edge_id = parent_edge[curr];
        auto [u, v, w] = edges[edge_id];
        if (w == 1)
            path_flight_ids.push_back(edge_id);
        curr = (u == curr) ? v : u;
    }

    if ((int)path_flight_ids.size() < K) {
        cout << "No\n";
        return 0;
    }

    // Assign K different companies to first K flight edges in the path
    for (int i = 0; i < K; i++) {
        assign[path_flight_ids[i]] = i + 1;
    }

    // Assign remaining flights (if not assigned) to company 1
    for (int id : flights_ids) {
        if (assign[id] == 0)
            assign[id] = 1;
    }

    cout << "Yes\n";
    for (int i = 0; i < M; i++) {
        auto [u, v, w] = edges[i];
        if (w == 1) {
            cout << assign[i] << '\n';
        }
    }

    return 0;
}
