#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100005;
const int INF = 1e9;

int N, M, K;

vector<int> adj[MAXN];         // adjacency list
vector<int> to, cap, rev, idx; // edges
vector<tuple<int, int, int>> edges; // input edges (u, v, w)
vector<int> company;           // company assignment

void add_edge(int u, int v, int c, int id) {
    int i = to.size();
    to.push_back(v); cap.push_back(c); rev.push_back(i + 1); idx.push_back(id);
    adj[u].push_back(i);

    to.push_back(u); cap.push_back(0); rev.push_back(i); idx.push_back(id);
    adj[v].push_back(i + 1);
}

int level[MAXN], ptr[MAXN];

bool bfs(int s, int t) {
    fill(level, level + N, -1);
    queue<int> q;
    q.push(s);
    level[s] = 0;

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int i : adj[u]) {
            int v = to[i];
            if (cap[i] > 0 && level[v] == -1) {
                level[v] = level[u] + 1;
                q.push(v);
            }
        }
    }
    return level[t] != -1;
}

int dfs(int u, int t, int flow) {
    if (u == t || flow == 0) return flow;
    for (; ptr[u] < adj[u].size(); ++ptr[u]) {
        int i = adj[u][ptr[u]];
        int v = to[i];
        if (level[v] != level[u] + 1 || cap[i] == 0) continue;
        int pushed = dfs(v, t, min(flow, cap[i]));
        if (pushed > 0) {
            cap[i] -= pushed;
            cap[rev[i]] += pushed;
            return pushed;
        }
    }
    return 0;
}

int maxflow(int s, int t) {
    int flow = 0;
    while (bfs(s, t)) {
        fill(ptr, ptr + N, 0);
        while (int pushed = dfs(s, t, INF)) {
            flow += pushed;
        }
    }
    return flow;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> M >> K;
    company.resize(M, 0);

    vector<int> flight_edges;

    for (int i = 0; i < M; ++i) {
        int u, v, w;
        cin >> u >> v >> w;
        u--; v--;
        edges.emplace_back(u, v, w);
        if (w == 1) {
            flight_edges.push_back(i);
            add_edge(u, v, 1, i); // само едно неориентирано ребро u->v с cap = 1
        }
    }

    int flow = maxflow(0, N - 1);

    if (flow < K) {
        cout << "No\n";
        return 0;
    }

    // Назначаваме компании на точно K използвани летателни коридора
    int assigned = 0;
    for (int u = 0; u < N && assigned < K; ++u) {
        for (int i : adj[u]) {
            if (idx[i] == -1) continue;
            if (cap[i] == 0 && company[idx[i]] == 0) {
                company[idx[i]] = assigned + 1;
                assigned++;
                if (assigned == K) break;
            }
        }
    }

    // Всички останали летателни коридори получават произволна (напр. 1-ва) компания
    for (int id : flight_edges) {
        if (company[id] == 0)
            company[id] = 1;
    }

    cout << "Yes\n";
    for (int i = 0; i < M; ++i) {
        int w = get<2>(edges[i]);
        if (w == 1) {
            cout << company[i] << '\n';
        }
    }

    return 0;
}
