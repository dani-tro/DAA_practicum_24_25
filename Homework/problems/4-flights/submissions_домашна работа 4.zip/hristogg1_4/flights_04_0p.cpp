#include <bits/stdc++.h>
using namespace std;

struct Edge {
    int to, rev;
    int cap, id, type; // type: 1=flight, 0=rail
};

const int MAXN = 100005;
vector<Edge> g[MAXN];
int level[MAXN], ptr[MAXN];
int N, M, K;

vector<tuple<int, int, int>> edges; // u, v, w
vector<int> flight_edge_indices;    // индекси на edges с w == 1
map<pair<int, int>, vector<pair<int, int>>> edge_ids; // (u,v) → { (index_in_input, w) }

void add_edge(int u, int v, int cap, int id, int type) {
    g[u].push_back({v, (int)g[v].size(), cap, id, type});
    g[v].push_back({u, (int)g[u].size() - 1, 0, id, type});
}

bool bfs(int s, int t) {
    fill(level, level + N + 1, -1);
    queue<int> q;
    q.push(s);
    level[s] = 0;
    while (!q.empty()) {
        int v = q.front(); q.pop();
        for (auto &e : g[v]) {
            if (e.cap && level[e.to] == -1) {
                level[e.to] = level[v] + 1;
                q.push(e.to);
            }
        }
    }
    return level[t] != -1;
}

int dfs(int v, int t, int pushed, vector<int> &path) {
    if (!pushed) return 0;
    if (v == t) return pushed;
    for (int &cid = ptr[v]; cid < g[v].size(); cid++) {
        Edge &e = g[v][cid];
        if (level[e.to] != level[v] + 1 || !e.cap) continue;
        int tr = dfs(e.to, t, min(pushed, e.cap), path);
        if (tr) {
            e.cap -= tr;
            g[e.to][e.rev].cap += tr;
            if (e.type == 1) path.push_back(e.id); // само летателни коридори
            return tr;
        }
    }
    return 0;
}

int dinic(int s, int t, vector<vector<int>> &flight_paths) {
    int flow = 0;
    while (bfs(s, t)) {
        fill(ptr, ptr + N + 1, 0);
        while (true) {
            vector<int> path;
            int pushed = dfs(s, t, 1, path);
            if (!pushed) break;
            flow += pushed;
            reverse(path.begin(), path.end());
            flight_paths.push_back(path); // запазваме по кой коридор минахме
            if (flow == K) return flow;
        }
    }
    return flow;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    cin >> N >> M >> K;

    for (int i = 0; i < M; ++i) {
        int u, v, w;
        cin >> u >> v >> w;
        edges.emplace_back(u, v, w);
        edge_ids[{u, v}].push_back({i, w});
        edge_ids[{v, u}].push_back({i, w});
        if (w == 0) {
            add_edge(u, v, 1, i, 0);
            add_edge(v, u, 1, i, 0);
        }
    }

    for (int i = 0; i < M; ++i) {
        auto [u, v, w] = edges[i];
        if (w == 1) {
            add_edge(u, v, 1, i, 1);
            add_edge(v, u, 1, i, 1);
        }
    }

    vector<vector<int>> flight_paths;
    int flow = dinic(1, N, flight_paths);

    if (flow < K) {
        cout << "No\n";
        return 0;
    }

    cout << "Yes\n";
    vector<int> assign(M, 1); // по подразбиране всичко = 1

    for (int company = 0; company < K; ++company) {
        for (int id : flight_paths[company]) {
            assign[id] = company + 1;
        }
    }

    for (int i = 0; i < M; ++i) {
        if (get<2>(edges[i]) == 1)
            cout << assign[i] << '\n';
    }

    return 0;
}
