#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100005;
const int MAXM = 200005;

int N, M, K;
vector<int> adj[MAXN];         // adjacency list (stores indices in edge list)
vector<int> to, rev, cap, idx; // edge properties
int level[MAXN], ptr[MAXN];
vector<tuple<int,int,int>> edges; // input edges
vector<int> flight_ids;

void add_edge(int u, int v, int c, int edge_idx) {
    int id1 = to.size();
    to.push_back(v); rev.push_back(to.size()); cap.push_back(c); idx.push_back(edge_idx);
    adj[u].push_back(id1);

    to.push_back(u); rev.push_back(id1); cap.push_back(0); idx.push_back(edge_idx);
    adj[v].push_back(id1 + 1);
}

bool bfs(int s, int t) {
    fill(level, level + N, -1);
    queue<int> q;
    q.push(s);
    level[s] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int i : adj[u]) {
            if (cap[i] > 0 && level[to[i]] == -1) {
                level[to[i]] = level[u] + 1;
                q.push(to[i]);
            }
        }
    }
    return level[t] != -1;
}

int dfs(int u, int t, int pushed) {
    if (u == t || pushed == 0) return pushed;
    for (; ptr[u] < adj[u].size(); ++ptr[u]) {
        int i = adj[u][ptr[u]];
        if (level[to[i]] != level[u] + 1 || cap[i] == 0) continue;
        int tr = dfs(to[i], t, min(pushed, cap[i]));
        if (tr > 0) {
            cap[i] -= tr;
            cap[rev[i]] += tr;
            return tr;
        }
    }
    return 0;
}

int maxflow(int s, int t) {
    int flow = 0;
    while (bfs(s, t)) {
        fill(ptr, ptr + N, 0);
        while (int pushed = dfs(s, t, INT_MAX))
            flow += pushed;
    }
    return flow;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> M >> K;
    vector<int> company(M, 0);

    for (int i = 0; i < M; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        u--; v--;
        edges.push_back({u, v, w});
        if (w == 1) {
            flight_ids.push_back(i);
            add_edge(u, v, 1, i);
            add_edge(v, u, 1, i); // тъй като е неориентирано
        }
    }

    int flow = maxflow(0, N - 1);
    if (flow < K) {
        cout << "No\n";
        return 0;
    }

    // Извличаме K летателни ребра, които участват във flow
    int assigned = 0;
    for (int u = 0; u < N && assigned < K; u++) {
        for (int i : adj[u]) {
            if (idx[i] != -1 && cap[i] == 0 && company[idx[i]] == 0) {
                company[idx[i]] = assigned + 1;
                assigned++;
            }
            if (assigned == K) break;
        }
    }

    // Всички останали – присвояваме 1
    for (int id : flight_ids) {
        if (company[id] == 0)
            company[id] = 1;
    }

    cout << "Yes\n";
    for (int i = 0; i < M; i++) {
        int w = get<2>(edges[i]);
        if (w == 1) {
            cout << company[i] << "\n";
        }
    }

    return 0;
}
