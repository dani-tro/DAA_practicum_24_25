#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <cstdlib>
#include <cassert>
#include <utility>
#include <algorithm>
using namespace std;

int config[20][5] = {
/* #01 */ {5, 100, 5, 1, 0},
/* #02 */ {200, 800, 200, 1, 0},
/* #03 */ {1000, 5000, 1000, 1, 0},
// -----------------------
/* #04 */ {1000, 5000, 10000, 1, 0},
/* #05 */ {1000, 4500, 10000, 1, 0},
/* #06 */ {1000, 4789, 10000, 1, 0},
/* #07 */ {1000, 4987, 10000, 1, 0},
/* #08 */ {1000, 4900, 10000, 1, 0},
/* #09 */ {1000, 4950, 10000, 1, 0},
// -----------------------
/* #10 */ {50, 5000, 200, 1, 100000},
/* #11 */ {50, 4999, 200, 10, 1000000},
// -----------------------
/* #12 */ {100, 4950, 1000, 75, 1000},
/* #13 */ {80, 4900, 1000, 100, 10000},
/* #14 */ {70, 4987, 1000, 80, 100000},
/* #15 */ {90, 4789, 1000, 70, 5000},
/* #16 */ {85, 4500, 1000, 90, 20000},
/* #17 */ {75, 5000, 1000, 85, 60000},
// -----------------------
/* #18 */ {750, 4999, 1000, 80, 1000},
/* #19 */ {900, 5000, 1000, 100, 10000},
/* #20 */ {500, 4950, 1000, 95, 100000}
};

mt19937 rg(879123654);

int rand_int(int l, int r)
{
    return l + rg() % (r - l + 1);
}

int rand_exp(int x)
{
    int y = 0;
    while (y == 0) y = rg() % 10;
    for (int i = 1; i < x; ++ i)
    {
        y = y * 10 + rg() % 10;
    }
    return y;
}

int rand_value()
{
    if (rg() % 2) return rand_int(1, 1000000);
    else return rand_exp(6);
}

pair<int, int> gen_pair(int m)
{
    int r = rg() % 100;
    if (r < 15) return make_pair(rand_value(), rand_int(1, 10));
    else if (r < 85) return make_pair(rand_value(), rand_int(10, m / 10));
    else return make_pair(rand_value(), rand_int(m / 10, m));
}

void create_test(string input, int idx)
{
    ofstream test(input);

    int n = config[idx - 1][0], m = config[idx - 1][1], ls = config[idx - 1][2], k = config[idx - 1][3], c = config[idx - 1][4];
    test << n << ' ' << m << ' ' << k << ' ' << c << endl;

    vector<int> v;
    if (idx > 3)
    {
        if (idx < 18)
        {
            v.push_back(rand_int(ls / 5, ls / 2));
            v.push_back(rand_int(ls / 20, ls / 10));
            ls -= v[0] + v[1];
        }
        v.push_back(rand_int(ls / 20, ls / 10));
        ls -= v.back();
    }
    while (v.size() < n - 1)
    {
        int avg = ls / (n - v.size());
        int l = rand_int(max(1, avg / 2), avg * 3 / 2);
        v.push_back(l);
        ls -= l;
    }
    v.push_back(ls);

    assert(v.size() == n);
    for (int i = 0; i < v.size(); ++ i)
    {
        assert(v[i] > 0);
    }

    random_shuffle(v.begin(), v.end());
    for (int i = 0; i < v.size(); ++ i)
    {
        test << v[i];
        for (int j = 1; j <= v[i]; ++ j)
        {
            pair<int, int> p = gen_pair(m);
            test << ' ' << p.first << ' ' << p.second;
        }
        test << endl;
    }

    test.close();
}

int main()
{
    for (int i = 1; i <= 20; ++ i)
    {
        string no = "  ";
        no[0] = i / 10 + '0';
        no[1] = i % 10 + '0';

        string input = "antiquing." + no + ".in";
        create_test(input, i);

        string command = "..\\author\\antiquing.exe < antiquing." + no + ".in > antiquing." + no + ".sol";
        cout << command << endl;
        system(command.c_str());
    }

    return 0;
}
