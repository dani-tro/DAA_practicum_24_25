#include <iostream>
#include <vector>
#include <utility>
#include <cassert>
using namespace std;

const int MAXN = 1003;
const int MAXM = 10004;
const int INF = 1 << 30;

int n, m, k, c;
vector<pair<int, int>> g;
int dp[MAXN][MAXM];

int main()
{
    cin >> n >> m >> k >> c;

    int xx = 0, yy = 0;
    for (int i = 1; i<= n; ++ i)
    {
        int l;
        cin >> l;
        assert(l == 1);

        int v, w;
        cin >> v >> w;
        g.emplace_back(v, w);
        if (w < 80) {
                yy += w;
                xx += v;
        }
    }

    //cout << xx << ' ' << yy << endl;
    //cout << g.size() << endl;

    for (int i = 1; i <= n; ++ i)
    {
        int v = g[i - 1].first, w = g[i - 1].second;
        for (int s = 0; s <= m; ++ s)
        {
            dp[i][s] = dp[i - 1][s];
            //cout << dp[i][s] << ' ';
        }
        for (int s = 0; s <= m; ++ s)
        {
            if (s >= w) dp[i][s] = max(dp[i][s], dp[i - 1][s - w] + v);
            //cout << dp[i][s] << ' ';
        }
        //cout << endl;
    }

    int ans = 0;
    for (int s = 0; s <= m; ++ s)
    {
        ans = max(ans, dp[n][s]);
    }

    cout << ans << endl;
    return 0;

}

/*
4 15 3 5
1 7 7
1 3 4
1 1 4
1 4 1
*/
