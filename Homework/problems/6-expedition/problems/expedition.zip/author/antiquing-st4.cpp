#include <iostream>
#include <vector>
#include <utility>
using namespace std;

const int MAXN = 102;
const int MAXM = 5003;
const int MAXK = 102;
const int INF = 1 << 30;

int n, m, k, c;
vector<pair<int, int>> g[MAXN];
int dp[MAXN][MAXM][MAXK];

int main()
{
    cin >> n >> m >> k >> c;
    for (int i = 1; i<= n; ++ i)
    {
        int l;
        cin >> l;
        for (int j = 1; j <= l; ++ j)
        {
            int v, w;
            cin >> v >> w;
            g[i].emplace_back(v, w);
        }
    }

    for (int s = 0; s <= m; ++ s)
    {
        for (int r = 0; r < k; ++ r)
        {
            dp[0][s][r] = -INF;
        }
    }
    dp[0][0][0] = 0;

    for (int i = 1; i <= n; ++ i)
    {
        for (int s = 0; s <= m; ++ s)
        {
            for (int r = 0; r < k; ++ r)
            {
                dp[i][s][r] = dp[i - 1][s][r];
            }
        }

        for (int j = 0; j < g[i].size(); ++ j)
        {
            int v = g[i][j].first, w = g[i][j].second;
            //cout << "adding: " << v << ' ' << w << endl;
            for (int s = 0; s <= m; ++ s)
            {
                for (int r = 0; r < k; ++ r)
                {
                    if (s >= w) dp[i][s][r] = max(dp[i][s][r], dp[i - 1][s - w][(r + j) % k] + v - (r + j) / k * c);
                    //cout << dp[i & 1][s][r] << ' ';
                }
                //cout << endl;
            }
        }
        //cout << "group end" << endl;
    }

    int ans = 0, ss, rr;
    for (int s = 0; s <= m; ++ s)
    {
        for (int r = 0; r < k; ++ r)
        {
            if (ans < dp[n][s][r])
            {
                ans = dp[n][s][r];
                ss = s;
                rr = r;
            }
        }
    }

    cerr << ss << ' ' << rr << endl;
    cout << ans << endl;
    return 0;

}

/*
4 15 3 5
1 7 7
2 3 4 8 5
3 1 4 6 3 7 4
4 3 1 4 3 10 5 12 6
*/
