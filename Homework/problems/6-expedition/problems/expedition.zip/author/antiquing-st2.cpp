#include <iostream>
#include <vector>
#include <utility>
#include <cassert>
using namespace std;

const int MAXN = 1003;
const int MAXM = 10004;
const int INF = 1 << 30;

int n, m, k, c;
vector<pair<int, int>> g[MAXN];
int dp[MAXN][MAXM];

int main()
{
    cin >> n >> m >> k >> c;
    assert(c == 0);

    int xx = 0, yy = 0;
    for (int i = 1; i<= n; ++ i)
    {
        int l;
        cin >> l;
        for (int j = 1; j <= l; ++ j)
        {
            int v, w;
            cin >> v >> w;
            g[i].emplace_back(v, w);
        }
    }

    for (int i = 1; i <= n; ++ i)
    {
        for (int s = 0; s <= m; ++ s)
        {
            dp[i][s] = dp[i - 1][s];
        }
        for (int j = 0; j < g[i].size(); ++ j)
        {
            int v = g[i][j].first, w = g[i][j].second;
            for (int s = 0; s <= m; ++ s)
            {
                if (s >= w) dp[i][s] = max(dp[i][s], dp[i - 1][s - w] + v);
            }
        }
    }

    int ans = 0;
    for (int s = 0; s <= m; ++ s)
    {
        ans = max(ans, dp[n][s]);
    }

    cout << ans << endl;
    return 0;

}

/*
4 15 3 5
1 7 7
1 3 4
1 1 4
1 4 1
*/
