#include <iostream>
#include <climits>
#include <vector>
#include <cmath>

using namespace std;
int n, m, k, c;
const int maxn = 1001;
vector<int> v[maxn];
vector<int> w[maxn];
const int maxm = 5001;
const int maxsuml = 2001;
int dp[2][maxm][maxsuml];

int backpack()
{
	int bp[2][maxm];
	bool curr = 0;
	for (size_t j = 0; j <= m; j++)
	{
		bp[curr][j] = 0;
		for (size_t p = 0; p < v[0].size(); p++)
		{
			if (w[0][p] <= j)
			{
				bp[curr][j] = max(bp[curr][j], v[0][p]);
			}
		}
	}
	for (size_t i = 1; i < n; i++)
	{
		curr = !curr;
		for (size_t j = 0; j <= m; j++)
		{
			bp[curr][j] = bp[!curr][j];
			for (size_t p = 0; p < v[i].size(); p++)
			{
				if(w[i][p] <= j)
					bp[curr][j] = max(bp[curr][j], bp[!curr][j - w[i][p]] + v[i][p]);
			}
		}
	}
	return bp[curr][m];
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m >> k >> c;
	int l; 
	int suml = 0;
	for (size_t i = 0; i < n; i++)
	{
		cin >> l;
		suml += l;
		int vtemp, wtemp;
		for (size_t j = 0; j < l; j++)
		{
			cin >> vtemp >> wtemp;
			v[i].push_back(vtemp);
			w[i].push_back(wtemp);
		}
	}
	if (c == 0)
	{
		cout << backpack() << endl;
		return 0;
	}
	bool curr = 0;
	for (size_t j = 0; j <= m; j++)
	{
		if (w[0][0] <= j)
			dp[curr][j][0] = v[0][0];
		else
			dp[curr][j][0] = 0;
	}
	for (size_t j = 0; j <= m; j++)
	{
		for (size_t t = 1; t <= suml - n; t++)
		{
			if (t < v[curr].size() && w[curr][t] <= j)
				dp[curr][j][t] = max(dp[curr][j][t - 1], v[curr][t]);
			else
				dp[curr][j][t] = dp[curr][j][t - 1];
		}
	}
	for (int i = 1; i < n; i++)
	{
		curr = !curr;
		for (int j = 0; j <= m; j++)
		{
			for (int t = 0; t < v[i].size(); t++)
			{
				dp[curr][j][t] = dp[!curr][j][t]; //Не вземаме нищо от станция i 
				for (int p = 0; p < v[i].size(); p++)
				{
					if (p > t)
						break;
					if (w[i][p] <= j)
					{
						dp[curr][j][t] = max(dp[curr][j][t], dp[!curr][j - w[i][p]][t - p] + v[i][p]);
					}
				}
			}
			for (int t = v[i].size(); t <= suml - n; t++)
			{
				dp[curr][j][t] = dp[curr][j][t - 1];
			}
		}
	}
	int maxdiff = 0;
	for (int t = 0; t <= suml - n; t++)
	{
		maxdiff = max(maxdiff, dp[curr][m][t] - (int)(ceil((double)t / k) * c));
	}
	cout << maxdiff << endl;
	/*
	4 15 3 5
	1 7 7
	2 3 4 8 5
	3 1 4 6 3 7 4
	4 3 1 4 3 10 5 12 6

	4 15 3 0
	1 7 7
	2 3 4 8 5
	3 1 4 6 3 7 4
	4 3 1 4 3 10 5 12 6
	*/
	return 0;
}