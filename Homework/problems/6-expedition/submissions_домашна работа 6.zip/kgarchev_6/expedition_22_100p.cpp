#include<bits/stdc++.h>
using namespace std;

using pis = pair<int, short>;
using ll = long long;

const int MAX_N = 10000;
const int MAX_M = 5000;
const int MAX_K = 100;
const ll N_INF = -(1LL << 60);

short N, M, K;
ll C;
pis item[MAX_N];

ll dp[MAX_M + 1][MAX_K];

ll knapsack0_1_2dim()
{
    cin >>N >>M >>K >>C;
    short j, prev_r;
    short sum_max_w = 0, max_w;
    for(int m = 0; m <= M; ++m)
    {
        for(int r = 0; r < K; ++r)
        {
            dp[m][r] = N_INF;
        }
    }
    dp[0][0] = 0;

    int l_i, v_ij, w_ij;
    for(short i = 0; i < N; ++i)
    {
        max_w = 0;
        cin >> l_i;
        for(short p = 0; p < l_i; ++p)
        {
            cin >>item[p].first >> item[p].second;
            max_w = max(max_w, item[p].second);
        }
        sum_max_w += max_w;
        sum_max_w = min(sum_max_w, M);

        for(int m = sum_max_w; m >= 0; --m)
        {
            for(short r = K - 1; r >= 0; --r)
            {
                j = -1;
                prev_r = r;
                for(short p = 0; p < l_i; ++p)
                {
                    v_ij = item[p].first;
                    w_ij = item[p].second;
                    ++j;
                    dp[m][r] = m < w_ij || dp[m - w_ij][prev_r] == N_INF ?
                               dp[m][r] :
                               max(dp[m][r], dp[m - w_ij][prev_r] + v_ij - ((prev_r + j + K - 1) / K - (prev_r > 0)) * C);
                    --prev_r;
                    prev_r = prev_r < 0 ? K - 1 : prev_r;
                }
            }
        }
    }

    ll res = 0;
    for(short m = 0; m <= M; ++m)
    {
        for(short r = 0; r < K; ++r)
        {
            res = max(res, dp[m][r]);
        }
    }
    return res;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    cout <<knapsack0_1_2dim() <<endl;
}



