#include<bits/stdc++.h>
using namespace std;

using pii = pair<int, int>;
using ll = long long;

const int MAX_N = 1000;
const int MAX_M = 5000;
const int MAX_K = 100;
const ll N_INF = -(1LL << 60);

int N, M, K;
ll C;
vector<pii> items[MAX_N];

ll dp[MAX_M + 1][MAX_K]; // Cost of items with weight

void readInput()
{
    cin >>N >>M >>K >>C;
    int l_i, v_ij, w_ij;
    for(int i = 0; i < N; ++i)
    {
        cin >>l_i;
        while(l_i--)
        {
            cin >>v_ij >> w_ij;
            items[i].emplace_back(v_ij, w_ij);
        }
    }
}

ll calc_cost_with(int crystals)
{
    return (crystals + K - 1) / K * C;
}

ll knapsack0_1_2dim()
{
    int j, new_dp_val, new_crystal_val;
    int sum_max_w = 0, max_w;

    for(int m = 0; m <= M; ++m)
    {
        for(int r = 0; r < K; ++r)
        {
            dp[m][r] = N_INF;
        }
    }
    dp[0][0] = 0;

    for(int i = 0; i < N; ++i)
    {
        max_w = 0;
        for(const auto [_, w_ij] : items[i])
        {
            max_w = max(max_w, w_ij);
        }
        sum_max_w += max_w;
        sum_max_w = min(sum_max_w, M);

        for(int m = sum_max_w; m >= 0; --m)
        {
            for(int r = 0; r < K; ++r)
            {
                j = -1;
                for(const auto [v_ij, w_ij] : items[i])
                {
                    ++j;
                    dp[m][r] = m < w_ij || dp[m - w_ij][(r - j + K) % K] == N_INF ?
                               dp[m][r] :
                               max(dp[m][r], dp[m - w_ij][(r - j + K) % K] + v_ij - (((r - j + K) % K + j + K - 1) / K - (r != j % K)) * C);
                }
            }
        }
    }

    ll res = 0;
    for(int m = 0; m <= M; ++m)
    {
        for(int r = 0; r < K; ++r)
        {
            res = max(res, dp[m][r]);
        }
    }
    return res;
}

ll solve()
{
    return knapsack0_1_2dim();
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    readInput();
    cout <<solve() <<endl;
}



