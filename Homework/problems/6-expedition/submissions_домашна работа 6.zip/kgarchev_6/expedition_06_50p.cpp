#include<bits/stdc++.h>
using namespace std;

using pii = pair<int, int>;
using ll = long long;

const int MAX_N = 1000;
const int MAX_M = 5000;
const int MAX_CRYSTALS = 1100;

int n, M, k, c;
int max_crystals = 0;
vector<pii> items[MAX_N];
int dp[MAX_CRYSTALS + 1][MAX_M + 1] = {0};

void readInput()
{
    cin >>n >>M >>k >>c;
    int l_i, v_ij, w_ij;
    for(int i = 0; i < n; ++i)
    {
        cin >>l_i;
        max_crystals += l_i;
        while(l_i--)
        {
            cin >>v_ij >> w_ij;
            items[i].emplace_back(v_ij, w_ij);
        }
    }
    max_crystals -= n;
    max_crystals += (k - max_crystals % k) % k;
}


ll knapsack0_1_1dim()
{
    for(int i = 0; i < n; ++i)
    {
        for(int m = M; m >= 0; --m)
        {
            for(const auto [v_ij, w_ij] : items[i])
            {
                if(m - w_ij < 0) continue;
                dp[0][m] = max(dp[0][m], dp[0][m - w_ij] + v_ij);
            }
        }
    }
    return dp[0][M];
}

ll knapsack0_1_2dim()
{
    int sum_li = 0, old_sum = 0;
    for(int i = 0; i < n; ++i)
    {
        sum_li += items[i].size() - 1;
        for(int c = sum_li; c >= 0; --c)
        {
            for(int m = M; m >= 0; --m)
            {
                int j = -1;
                for(const auto [v_ij, w_ij] : items[i])
                {
                    ++j;
                    if(m - w_ij < 0 || c - j < 0) continue;
                    dp[c][m] = max(dp[min(c, old_sum)][m], dp[min(c - j, old_sum)][m - w_ij] + v_ij);
                }
            }
        }
        /*
        cout <<"Results for i: " <<i + 1 <<endl;
        for(int i = 0, cr = 0; cr <= max_crystals; ++i, cr += k)
        {
            cout <<"With " <<i <<" blocks: value " << dp[cr][M] <<" & blocks value: " << i * c <<" -> " << dp[cr][M] - i * c <<endl;
        }*/
        old_sum = sum_li;
    }

    int res = 0, v;
    for(int i = 0, cr = 0, crbl = 0; cr <= max_crystals; ++i, cr += k, crbl += c)
    {
        res = max(res, v = dp[min(cr, old_sum)][M] - crbl);
    }

    return res;
}

ll solve()
{
    return c == 0 ? knapsack0_1_1dim() : knapsack0_1_2dim();
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(0));

    readInput();
    cout <<solve() <<endl;
}
