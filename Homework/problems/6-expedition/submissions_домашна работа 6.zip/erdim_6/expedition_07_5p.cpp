#include <bits/stdc++.h>
#define int long long
using namespace std;

const int MAXN = 101;
const int MAXM = 501;
const int MAXK = 101;
const int INF = 1e17;
int n, m, k, c;
int dp[MAXN][MAXM][MAXK];
struct Artef
{
    int v, w;
};
vector<Artef> a[MAXN];

int calc(int ost, int t)
{
    int prev = ost / k + (bool)(ost % k);
    int curr = (ost + t) / k + (bool)((ost + t) % k);

    return (curr - prev) * c;
}

main()
{
    cin >> n >> m >> k >> c;
    for (int i = 1; i <= n; i++)
    {
        int l, v, w;
        cin >> l;
        for (int j = 1; j <= l; j++)
        {
            cin >> v >> w;
            a[i].push_back({v, w});
        }
    }

    for (int j = 0; j <= m; j++)
        for (int ost = 0; ost < k; ost++)
            dp[0][j][ost] = -INF;
    dp[0][0][0] = 0;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 0; j <= m; j++)
        {
            for (int ost = 0; ost < k; ost++)
                dp[i][j][ost] = dp[i - 1][j][ost];
            /*cout << "FIRST\n";
            for (int ost = 0; ost < k; ost++)
                cout << i << " " << j << " " << ost << "  " << dp[i][j][ost] << endl; */

            for (int ost = 0; ost < k; ost++)
            {
                for (int t = 0; t < a[i].size(); t++)
                {
                    Artef ar = a[i][t];
                    if (j < ar.w)
                        continue;
                    dp[i][j][(ost + t) % k] = max(dp[i][j][(ost + t) % k], dp[i - 1][j - ar.w][ost] + ar.v - calc(ost, t));
                }
            }

            /*  cout << "SECOND\n";
              for (int ost = 0; ost < k; ost++)
                  cout << i << " " << j << " " << ost << "  " << dp[i][j][ost] << endl; */
        }
    }

    int ans = 0;
    for (int j = 0; j <= m; j++)
        for (int ost = 0; ost < k; ost++)
            ans = max(ans, dp[n][j][ost]);

    cout << ans << endl;

    return 0;
}