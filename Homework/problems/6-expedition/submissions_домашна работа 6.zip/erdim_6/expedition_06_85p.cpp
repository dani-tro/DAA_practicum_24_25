#include <bits/stdc++.h>
#define int long long
using namespace std;

const int MAXN = 1001;
const int MAXM = 5001;
const int INF = 1e17;
int n, m, k, c;
int dp[MAXN][MAXM];
int cr[MAXN][MAXM];
struct Artef
{
    int v, w;
};
vector<Artef> a[MAXN];

int calc_cost(int cnt, int add)
{
    int prev = cnt / k + (bool)(cnt % k);
    int curr = (cnt + add) / k + (bool)((cnt + add) % k);
    return (curr - prev) * c;
}

bool more_optimal(int cr1, int cr2)
{
    return (cr1 % k < cr2 % k && cr1 % k > 0);
}

main()
{
    cin >> n >> m >> k >> c;
    for (int i = 1; i <= n; i++)
    {
        int l, v, w;
        cin >> l;
        for (int j = 1; j <= l; j++)
        {
            cin >> v >> w;
            a[i].push_back({v, w});
        }
    }

    for (int j = 1; j <= m; j++)
        dp[0][j] = -INF;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 0; j <= m; j++)
        {
            dp[i][j] = dp[i - 1][j];
            cr[i][j] = cr[i - 1][j];
            for (int t = 0; t < a[i].size(); t++)
            {
                Artef ar = a[i][t];
                if (j < ar.w)
                    continue;
                int cost = calc_cost(cr[i - 1][j - ar.w], t);
                if (dp[i][j] < dp[i - 1][j - ar.w] + ar.v - cost)
                {
                    dp[i][j] = dp[i - 1][j - ar.w] + ar.v - cost;
                    cr[i][j] = cr[i - 1][j - ar.w] + t;
                }
                else if (dp[i][j] == dp[i - 1][j - ar.w] + ar.v - cost)
                {
                    if (more_optimal(cr[i - 1][j - ar.w] + t, cr[i][j]))
                        cr[i][j] = cr[i - 1][j - ar.w] + t;
                }
            }
        }
    }

    int ans = 0;
    for (int j = 0; j <= m; j++)
    {
        ans = max(ans, dp[n][j]);
    }
    cout << ans << endl;

    return 0;
}