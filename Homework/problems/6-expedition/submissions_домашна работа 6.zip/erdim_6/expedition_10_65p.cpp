#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1001;
const int MAXM = 5001;
const int MAXK = 101;
const int INF = 1e9;
int n, m, k, c;
int dp[2][MAXM][MAXK];
struct Artef
{
    int v, w;
};
vector<Artef> a[MAXN];

int calc(int ost, int t)
{
    int prev = ost / k + (bool)(ost % k);
    int curr = (ost + t) / k + (bool)((ost + t) % k);

    return (curr - prev) * c;
}

main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin >> n >> m >> k >> c;
    for (int i = 1; i <= n; i++)
    {
        int l, v, w;
        cin >> l;
        for (int j = 1; j <= l; j++)
        {
            cin >> v >> w;
            a[i].push_back({v, w});
        }
    }

    for (int j = 0; j <= m; j++)
        for (int ost = 0; ost < k; ost++)
            dp[0][j][ost] = -INF;
    dp[0][0][0] = 0;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 0; j <= m; j++)
        {
            for (int ost = 0; ost < k; ost++)
                dp[i % 2][j][ost] = dp[(i - 1) % 2][j][ost];

            for (int ost = 0; ost < k; ost++)
            {
                for (int t = 0; t < a[i].size(); t++)
                {
                    Artef ar = a[i][t];
                    if (j < ar.w)
                        continue;
                    dp[i % 2][j][(ost + t) % k] = max(dp[i % 2][j][(ost + t) % k], dp[(i - 1) % 2][j - ar.w][ost] + ar.v - calc(ost, t));
                }
            }
        }
    }

    int ans = 0;
    for (int j = 0; j <= m; j++)
        for (int ost = 0; ost < k; ost++)
            ans = max(ans, dp[n % 2][j][ost]);

    cout << ans << endl;

    return 0;
}