#include <bits/stdc++.h>
using namespace std;

struct Node {
    unsigned n, m, p;

    bool operator==(const Node& node) const { 
        return n == node.n && m == node.m && p == node.p;
    }

    struct Hasher {
        size_t operator() (const Node& node) const {
            return hash<unsigned>()(node.n) ^ 
                   (hash<unsigned>()(node.m) << 1) ^ 
                   (hash<unsigned>()(node.p) << 2);
        }
    };
};

unsigned l[1010];
vector<int> v[1010];
vector<unsigned> w[1010];
unordered_map<Node, int, Node::Hasher> dp;

int n, m, k, c;

int calc(unsigned n, unsigned m, unsigned p) {
    if (n == 0 || m == 0) {
        return 0;
    }

    if (dp.count({n, m, p})) {
        return dp[{n, m, p}];
    }

    int opt = calc(n - 1, m, p);
    
    for (unsigned j = 1; j <= l[n]; ++j) {
        if (m < w[n][j - 1]) {
            continue;
        }

        if (p >= j - 1) {

            opt = max(opt, v[n][j - 1] + calc(n - 1, m - w[n][j - 1], p - j + 1));
            continue;
        }

        int x = (j - 1 - p + k - 1) / k;
        opt = max(opt, v[n][j - 1] + calc(n - 1, m - w[n][j - 1], k * x + p - j + 1) - c * x);
    }

    return dp[{n, m, p}] = opt;
}

int main() {
	ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    
    unsigned v1, w1;
    cin >> n >> m >> k >> c;

    for (size_t i = 1; i <= n; ++i) {
        cin >> l[i];

        for (size_t j = 0; j < l[i]; ++j) {
            cin >> v1 >> w1;
            v[i].push_back(v1);
            w[i].push_back(w1);
        }
    }
    
    cout << calc(n, m, 0);
    return 0;
}