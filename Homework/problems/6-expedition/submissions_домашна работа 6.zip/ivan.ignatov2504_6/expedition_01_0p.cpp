#include <bits/stdc++.h>

#define llong long long

const int MAXN = 1010;
const int MAXW = 5010;
const llong INF = LLONG_MAX;

int v[MAXN], w[MAXN];
llong dp[MAXN][MAXW];

int n, w, k, c;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    int n, m, k, c;
    std::cin >> n >> m >> k >> c;
    for (int i = 1; i <= n; ++i) {
        int li;
        std::cin >> li;
        for (int j = 0; j < li; ++j) {
            std::cin >> v[i] >> w[i];
        }
    }

    for (int i = 1; i <= m; ++i) {
        dp[0][i] = -INF;
    }

    long long ans = 0;
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j <= m; ++j) {
            dp[i][j] = dp[i - 1][j];
            if (j >= w[i]) {
                dp[i][j] = std::max(dp[i][j], dp[i - 1][j - w[i]] + v[i]);
            }
            if (i == n) {
                ans = std::max(ans, dp[i][j]);
            }
        }
    }

    std::cout << ans << std::endl;
}