#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e3 + 10;
const int MAXM = 1e4 + 10;

int n, m, k, c;
vector<pair<int, int>> gr;
int dp[MAXN][MAXM];

int main()
{
    cin >> n >> m >> k >> c;

    int x = 0, y = 0;
    for (int i = 1; i <= n; i++)
    {
        int l;
        cin >> l;

        int v, w;
        cin >> v >> w;
        gr.push_back({v, w});
        if (w < 80) {
                y += w;
                x += v;
        }
    }

    for (int i = 1; i <= n; i++)
    {
        int v = gr[i - 1].first, w = gr[i - 1].second;
        for (int j = 0; j <= m; j++)
        {
            dp[i][j] = dp[i - 1][j];
        }
        for (int j = 0; j <= m; j++)
        {
            if (j >= w && dp[i][j] < dp[i-1][j-w] + v) 
                dp[i][j] = dp[i - 1][j - w] + v;
        }
    }

    int ans = 0;
    for (int j = 0; j <= m; j++)
    {
        if (ans < dp[n][j])
            ans = dp[n][j];
    }

    cout << ans << endl;
    return 0;

}
