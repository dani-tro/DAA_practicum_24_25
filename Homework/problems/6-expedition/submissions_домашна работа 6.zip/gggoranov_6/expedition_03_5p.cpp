#include <bits/stdc++.h>
using namespace std;


struct Pair{
    long val;
    long cost;

    bool operator>(const Pair& other){
        return val > other.val;
    }
    bool operator<(const Pair& other){
        return val < other.val;
    }
};

const int maxn = 1005, maxm = 5005, maxk = 105, maxc = 1e8 + 10;
long n, m, k, c;
Pair dp[maxn][maxm];
int l[maxm], v[maxn][maxm], w[maxn][maxm];


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> k >> c;
    for(int i = 1; i <= n; ++i){
        cin >> l[i];
        for(int j = 1; j <= l[i]; ++j){
            cin >> v[i][j] >> w[i][j];
        }
    }

    for(int j = 1; j <= l[1]; ++j){
        dp[1][m-w[1][j]].cost = j - 1;
        dp[1][m-w[1][j]].val = v[1][j];
        // cout << j << ": " << w[1][j] << endl;
    }
    // cout << "FIRST: " << dp[1][8].val << endl;

    for(int i = 2; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            for(int t = 1; t <= l[i]; ++t){
                if(w[i][t] > j) dp[i][j] = dp[i-1][j];
                else{
                    if(dp[i-1][j].val < dp[i-1][j-w[i][t]].val + v[i][t]){
                        dp[i][j].val = dp[i-1][j-w[i][t]].val + v[i][t];
                        dp[i][j].cost = dp[i-1][j-w[i][t]].cost + t-1;
                    } else dp[i][j] = dp[i-1][j];
                }
            }
        }
    }

    // cout << dp[2][8].val << endl;

    long ans = 0;
    for(int j = 1; j <= m; ++j){
        // cout << j << ": " << dp[n][j].val << endl;
        ans = max(ans, dp[n][j].val - long(ceil(double(dp[n][j].cost) / k) * c));
    }



    // for(int j = 1; j <= l[1]; ++j){
    //     dp[1][m-w[1][j]][k-j+1] = v[1][j] - ceil(double(j-1) / c);
    // }

    // for(int i = 2; i <= n; ++i){
    //     for(int j = 1; j <= m; ++j){
    //         for(int p = 1; p <= k; ++p){
    //             dp[i][j][p] = 0;
    //             for(int q = 1; q <= l[i]; ++q){
    //                 dp[i][j][p] = max(dp[i][j][p], dp[i][j-w[i][q]][m-q+1] + v[i][q] - int(ceil(double(q-1) / c)));
    //             }
    //         }
    //     }
    // }

    // int ans = 0;
    // for(int j = 1; j <= m; ++j){
    //     for(int p = 1; p <= k; ++p){
    //         ans = max(ans, dp[n][j][p]);
    //     }
    // }

    cout << ans << endl;

    return 0;
}