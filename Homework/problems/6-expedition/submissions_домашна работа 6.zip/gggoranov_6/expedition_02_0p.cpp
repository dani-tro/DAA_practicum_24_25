#include <bits/stdc++.h>
using namespace std;

const int maxn = 1005, maxm = 5005, maxk = 105, maxc = 1e8 + 10;
long n, m, k, c;
int dp[maxn][maxm][2], l[maxm], v[maxn][maxm], w[maxn][maxm];


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> k >> c;
    for(int i = 1; i <= n; ++i){
        cin >> l[i];
        for(int j = 1; j <= l[i]; ++j){
            cin >> v[i][j] >> w[i][j];
        }
    }

    for(int j = 1; j <= l[1]; ++j){
        dp[1][m-w[1][j]][k-j+1] = v[1][j] - ceil(double(j-1) / c);
    }

    for(int i = 2; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            for(int p = 1; p <= k; ++p){
                dp[i][j][p] = 0;
                for(int q = 1; q <= l[i]; ++q){
                    dp[i][j][p] = max(dp[i][j][p], dp[i][j-w[i][q]][m-q+1] + v[i][q] - int(ceil(double(q-1) / c)));
                }
            }
        }
    }

    int ans = 0;
    for(int j = 1; j <= m; ++j){
        for(int p = 1; p <= k; ++p){
            ans = max(ans, dp[n][j][p]);
        }
    }

    cout << ans << endl;

    return 0;
}