#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const ll INF = -1e9;
const ll MAXM = 5000;
const ll MAXK = 100;

ll dp[MAXM + 1][MAXK];
ll ndp[MAXM + 1][MAXK];
ll l, v, w;  

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll N, M, K, C;
    cin >> N >> M >> K >> C;

    for (ll m = 0; m <= M; ++m)
        for (ll r = 0; r < K; ++r)
            dp[m][r] = INF;
    dp[0][0] = 0;

    for (ll s = 0; s < N; ++s) {
        cin >> l;

        for (ll m = 0; m <= M; ++m)
            for (ll r = 0; r < K; ++r)
                ndp[m][r] = dp[m][r];

        for (ll j = 1; j <= l; ++j) {
            cin >> v >> w;
            ll addC = j - 1;

            for (ll m = 0; m + w <= M; ++m) {
                for (ll r = 0; r < K; ++r) {
                    ll cur = dp[m][r];
                    if (cur == INF) 
                        continue;

                    ll totalC = r + addC;
                    ll cand = cur + v - (totalC / K) * C;
                    ll &ref  = ndp[m + w][totalC % K];
                    if (cand > ref) ref = cand;
                }
            }
        }
        for (ll m = 0; m <= M; ++m)
            for (ll r = 0; r < K; ++r)
                dp[m][r] = ndp[m][r];
    }

    ll best = INF;
    for (ll m = 0; m <= M; ++m)
        for (ll r = 0; r < K; ++r) {
            ll val = dp[m][r];
            if (val == INF) 
                continue;
            if (r) 
                val -= C;
            best = max(best, val);
        }

    cout << best;
    return 0;
}
