#include <bits/stdc++.h>
using namespace std;

const int INF = -1e9;
const int MAXM = 5000;
const int MAXK = 100;

int dp[MAXM + 1][MAXK];
int old[MAXM + 1][MAXK];
int newR[MAXK], deltaB[MAXK];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M, K, C;
    cin >> N >> M >> K >> C;

    for (int m = 0; m <= M; ++m)
        for (int r = 0; r < K; ++r)
            dp[m][r] = INF;
    dp[0][0] = 0;

    for (int s = 0; s < N; ++s) {
        int l;  cin >> l;
        memcpy(old, dp, sizeof(dp));

        for (int j = 1; j <= l; ++j) {
            int v, w;  cin >> v >> w;
            int addC   = j - 1;
            int sResid = addC % K;
            int tBlock = addC / K;

            for (int r = 0; r < K; ++r) {
                int tot = r + sResid;
                newR[r]   = (tot >= K) ? tot - K : tot;
                deltaB[r] = tBlock + (tot >= K);
            }

            for (int m = M - w; m >= 0; --m) {
                int *src = old[m];
                int *dst = dp[m + w];

                for (int r = 0; r < K; ++r) {
                    int cur = src[r];
                    if (cur == INF) 
                        continue;

                    int nr  = newR[r];
                    int val = cur + v - deltaB[r] * C;
                    if (val > dst[nr]) dst[nr] = val;
                }
            }
        }
    }

    int best = INF;
    for (int m = 0; m <= M; ++m)
        for (int r = 0; r < K; ++r) {
            int val = dp[m][r];
            if (val == INF) 
                continue;
            if (r) val -= C;
            best = max(best, val);
        }

    cout << best;
    return 0;
}
