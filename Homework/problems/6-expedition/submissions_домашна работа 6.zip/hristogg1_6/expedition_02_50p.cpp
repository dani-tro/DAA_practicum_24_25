#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int INF = -1e9;

int main() {
    int N, M, K, C;
    cin >> N >> M >> K >> C;

    vector<int> dp(M + 1, INF);
    dp[0] = 0;

    for (int i = 0; i < N; ++i) {
        int li;
        cin >> li;
        vector<tuple<int, int, int>> items; // value, weight, energy cost
        for (int j = 0; j < li; ++j) {
            int v, w;
            cin >> v >> w;
            int crystals = j; // (j+1)-ви артефакт изисква j кристала
            int cost = ((crystals + K - 1) / K) * C;
            items.emplace_back(v - cost, w, v); // спестяваме v отделно
        }

        // копие на dp за текущата станция
        vector<int> new_dp = dp;

        for (auto [profit, w, value] : items) {
            for (int cw = M; cw >= w; --cw) {
                if (dp[cw - w] != INF) {
                    new_dp[cw] = max(new_dp[cw], dp[cw - w] + profit);
                }
            }
        }

        dp = new_dp;
    }

    // отговора е макс от dp[w]
    int result = 0;
    for (int w = 0; w <= M; ++w) {
        result = max(result, dp[w]);
    }

    cout << result << endl;
    return 0;
}
