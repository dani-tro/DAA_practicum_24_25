#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const long long UNREACHABLE = -1e18; // Use a very small number to represent unreachable states

struct State {
    long long value;
    int crystals;

    // Constructor to easily initialize
    State(long long v = UNREACHABLE, int c = 0) : value(v), crystals(c) {}
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int N, M, K;
    long long C;

    cin >> N >> M >> K >> C;

    vector<State> dp(M + 1, State()); // dp[w] = {max_value, min_crystals} for weight w
    dp[0] = State(0, 0); // Base case: 0 weight, 0 value, 0 crystals

    for (int i = 0; i < N; ++i) {
        int l_i;
        cin >> l_i;

        vector<pair<int, int>> artifacts_in_station(l_i);
        for (int j = 0; j < l_i; ++j) {
            cin >> artifacts_in_station[j].first >> artifacts_in_station[j].second; // v_ij, w_ij
        }

        // Create a temporary dp table for the current station's calculations
        // This is crucial to ensure we pick at most one artifact per station
        vector<State> next_dp = dp;

        for (int j = 0; j < l_i; ++j) { // Iterate through artifacts in current station
            long long current_v = artifacts_in_station[j].first;
            int current_w = artifacts_in_station[j].second;
            int current_crystals_cost = j; // j-th artifact (1-indexed) costs j-1 crystals (0-indexed)

            for (int w = M; w >= current_w; --w) { // Iterate through weights
                if (dp[w - current_w].value != UNREACHABLE) {
                    long long potential_value = dp[w - current_w].value + current_v;
                    int potential_crystals = dp[w - current_w].crystals + current_crystals_cost;

                    if (potential_value > next_dp[w].value) {
                        next_dp[w] = State(potential_value, potential_crystals);
                    }
                    else if (potential_value == next_dp[w].value) {
                        if (potential_crystals < next_dp[w].crystals) {
                            next_dp[w].crystals = potential_crystals;
                        }
                    }
                }
            }
        }
        dp = next_dp; // Update dp for the next station
    }

    long long max_overall_net_value = 0; // Initialize with 0 for the case of taking no artifacts

    for (int w = 0; w <= M; ++w) {
        if (dp[w].value != UNREACHABLE) {
            long long crystal_blocks = (dp[w].crystals + K - 1) / K; // Ceiling division
            long long crystal_cost = crystal_blocks * C;
            long long current_net_value = dp[w].value - crystal_cost;
            max_overall_net_value = max(max_overall_net_value, current_net_value);
        }
    }

    cout << max_overall_net_value << endl;

    return 0;
}