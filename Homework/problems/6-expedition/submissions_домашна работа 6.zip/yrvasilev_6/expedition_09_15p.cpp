#include<iostream>
#include<string>
#include<cstdio>
#include<cmath>
#include<stack>
#include<algorithm>
using namespace std;
long long a[5005][105], b[5005][105], ans=0, n, m, k, c, l, v, w;
const long long MOD=1000000007;
int main (){
    int i,j,r,t=0;
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin>>n>>m>>k>>c;
    if(c==0){
        for(i=1;i<=n;i++){
            cin>>l;
            for(j=0;j<l;j++){
                cin>>v>>w;
                for(t=w; t<=m; t++) b[t][0]=max(b[t][0],a[t-w][0]+v);
            }
            for(t=w;t<=m;t++) a[t][0]=b[t][0];
        }
        cout<<b[m][0]<<endl;
        return 0;
    }

    // for(i=1;i<=n;i++){
    //     cin>>l;
    //     //cout<<"i="<<i<<endl;
    //     for(j=0;j<l;j++){
    //         cin>>v>>w;
    //         for(t=w;t<=m;t++){// t - teglo
    //             //cout<<"t="<<t<<" w="<<w<<" v="<<v<<endl;
    //             for(r=0;r<k;r++){//r - remainder
    //                 b[t][(r+j)%k]=max ( max (b[t][(r+j)%k], a[t][(r+j)%k]), a[t-w][r]-(r+j)/k*c+v);
    //                 //cout<<"li="<<j<<" r="<<r <<" r'="<<(r+j)%k<<" b[t][r']="<<b[t][(r+j)%k]<<endl;
    //             }
    //             //cout<<endl;
    //         }
    //     }
    //     //update
    //     for(t=w;t<=m;t++){// t - teglo
    //         for(r=0;r<k;r++){//r - remainder
    //             a[t][r]=b[t][r];
    //         }
    //     }
    //     //cout<<endl;
    // }

    // for(i=1;i<k;i++)ans=max(ans,a[m][i]); ans-=c;
    // ans=max(ans,a[m][0]);
    // cout<<ans<<endl;
    // for(int i=0;i<n;i++) printf("%lld ",a[i]); cout<<endl;
    
    return 0;
}

/*
започни от последните?

4 15 3 5
1 7 7
2 3 4 8 5
3 1 4 6 3 7 4
4 3 1 4 3 10 5 12 6
*/


