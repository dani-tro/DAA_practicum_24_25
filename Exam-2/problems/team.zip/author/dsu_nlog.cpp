#include<bits/stdc++.h>
#define all(A) A.begin(), A.end()
#define de(x) cout << #x << " = " << x << endl;
using namespace std;

struct unionfind{
	bool bipartite = true;
	int n;
	vector<int> par, clr;
	vector<vector<int>> comp;
	unionfind() {}
	unionfind(int n) : n(n){
		par = clr = vector<int>(n + 1);
		comp = vector<vector<int>>(n + 1);
		for(int i = 1; i <= n; i ++){
			par[i] = i; clr[i] = 0;
			comp[i].push_back(i);
		}
	}
	int find(int x){
		return (par[x] == x ? x : par[x] = find(par[x]));
	}
	void join(int u, int v){
		int pu = find(u);
		int pv = find(v);
		if(pu == pv){
			if(clr[u] == clr[v]) bipartite = false;
			return;
		}
		if(comp[pu].size() < comp[pv].size()) swap(pu, pv);
		par[pv] = pu;
		if(clr[u] == clr[v]){
			for(auto x : comp[pv]) clr[x] ^= 1;
		}
		comp[pu].insert(comp[pu].end(), all(comp[pv]));
		comp[pv].clear();
	}
};

int n, m, q;

int main(){
	cin >> n >> m >> q;
	unionfind dsu(n);
	for(int i = 0; i < m; i ++){
		int u, v; cin >> u >> v;
		dsu.join(u, v);
	}
	if(!dsu.bipartite){ cout << "-1\n"; return 0; }
	for(int i = 0; i < q; i ++){
		int u, v; cin >> u >> v;
		dsu.join(u, v);
		if(!dsu.bipartite){ cout << i + 1 << "\n"; return 0; }
	}
	cout << "-2\n";
}
