#include<bits/stdc++.h>
using namespace std;

template<class T> using matrix = vector<vector<T>>;

const int MAXN = 1e6;

int n, m, q;
bool color[MAXN + 5], used[MAXN + 5], bipartite;
matrix<int> G;
vector<pair<int, int>> queries;

void dfs(int u, bool clr = 0){
	used[u] = 1;
	color[u] = clr;
	for(auto v : G[u]){
		if(used[v]) bipartite &= (color[u] != color[v]);
		else dfs(v, clr ^ 1);
	}
}

bool is_bipartite(){
	bipartite = true;
	for(int u = 1; u <= n; u ++){
		used[u] = color[u] = 0;
	}
	for(int u = 1; u <= n; u ++){
		if(!used[u]) dfs(u);
	}
	return bipartite;
}

void append(int x){
	for(int i = 0; i <= x; i ++){
		auto [u, v] = queries[i];
		G[u].push_back(v);
		G[v].push_back(u);
	}
}

void undo(int x){
	for(int i = 0; i <= x; i ++){
		auto [u, v] = queries[i];
		G[u].pop_back();
		G[v].pop_back();
	}
}

int main(){
	cin >> n >> m >> q;
	G.resize(n + 1);
	for(int i = 0; i < m; i ++){
		int u, v; cin >> u >> v;
		G[u].push_back(v);
		G[v].push_back(u);
	}
	if(!is_bipartite()){
		cout << "-1\n"; return 0;
	}
	queries.resize(q);
	for(auto &[u, v] : queries){
		cin >> u >> v;
	}
	int low = 0, high = queries.size() - 1, ans = -2;
	while(low <= high){
		int mid = (low + high) / 2;
		append(mid);
		if(is_bipartite()){
			low = mid + 1;
		}
		else{
			high = mid - 1;
			ans = mid + 1;
		}
		undo(mid);
	}
	cout << ans << endl;
}
