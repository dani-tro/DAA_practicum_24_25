#include<bits/stdc++.h>
#define all(A) A.begin(), A.end()
#define de(x) cout << #x << " = " << x << endl;
using namespace std;

struct unionfind{
	bool bipartite = true;
	int n;
	vector<pair<int, int>> par;
	vector<int> sz;
	unionfind() {}
	unionfind(int n) : n(n){
		par.resize(n + 1);
		sz.resize(n + 1);
		for(int i = 1; i <= n; i ++){
			par[i] = {i, 0};
			sz[i] = 1;
		}
	}
	pair<int, int> find(int x){
		if(par[x].first != x){
			int save = par[x].second;
			par[x] = find(par[x].first);
			par[x].second ^= save;
		}
		return par[x];
	}
	void join(int u, int v){
		auto [pu, x] = find(u);
		auto [pv, y] = find(v);
		if(pu == pv){
			if(x == y) bipartite = false;
			return;
		}
		if(sz[pu] < sz[pv]) swap(pu, pv);
		par[pv] = {pu, x ^ y ^ 1};
		sz[pu] += sz[pv];
	}
};

int n, m, q;

int main(){
	cin >> n >> m >> q;
	unionfind dsu(n);
	for(int i = 0; i < m; i ++){
		int u, v; cin >> u >> v;
		dsu.join(u, v);
	}
	if(!dsu.bipartite){ cout << "-1\n"; return 0; }
	for(int i = 0; i < q; i ++){
		int u, v; cin >> u >> v;
		dsu.join(u, v);
		if(!dsu.bipartite){ cout << i + 1 << "\n"; return 0; }
	}
	cout << "-2\n";
}
