g++ -o testgen testgen.cpp

./testgen 200000  400000 	 0 0 1 > test.01.in
./testgen 200000  400000 	 0 0 2 > test.02.in
./testgen 200000  400000 	 0 1 3 > test.03.in
./testgen 200000  400000 	 0 1 4 > test.04.in
./testgen 200000  400000 	 0 1 5 > test.05.in
./testgen 100000  200000  200000 1 > test.06.in
./testgen 100000  200000  200000 2 > test.07.in
./testgen 100000  200000  200000 3 > test.08.in
./testgen 100000  200000  200000 4 > test.09.in
./testgen 100000  200000  200000 5 > test.10.in
./testgen 200000  400000  400000 1 > test.11.in
./testgen 200000  400000  400000 2 > test.12.in
./testgen 200000  400000  400000 3 > test.13.in
./testgen 200000  400000  400000 4 > test.14.in
./testgen 200000  400000  400000 5 > test.15.in
