#include "testlib.h"
#include<bits/stdc++.h>
#define all(A) A.begin(), A.end()
#define SZ(A) (int)A.size() 
#define de(x) cout << #x << " = " << x << endl;
using namespace std;

const int MAXN = 1e6;

int main(int argc, char **argv){
	registerGen(argc, argv, 1);
	int n = opt<int>(1), m = opt<int>(2), q = opt<int>(3);
	vector<pair<int, int>> edges, queries;
	if(q == 0){ // no additional edges
		int bipartite = opt<int>(4);
		if(bipartite == 0){ // generate two partitions and random edges between them
			vector<int> perm(n);
			iota(all(perm), 1);
			shuffle(all(perm));
			int k = rnd.next(n / 3, n / 2);
			vector<int> A, B;
			for(int i = 0; i < n; i ++){
				if(i < k) A.push_back(perm[i]);
				else B.push_back(perm[i]);
			}
			for(int i = 0; i < m; i ++){
				if(i == m - 1) edges.push_back({A[rnd.next(0, SZ(A) - 1)], B[rnd.next(0, SZ(B) - 1)]});
				else{
					int sz = min((m - i) / 2 * 2, rnd.next(1, n / 10) * 2);
					vector<int> cycle;
					for(int i = 0; i < sz; i ++){
						if(i & 1) cycle.push_back(A[rnd.next(0, SZ(A) - 1)]);
						else cycle.push_back(B[rnd.next(0, SZ(B) - 1)]);
					}
					for(int i = 0; i < sz; i ++){
						int j = (i + 1) % sz;
						edges.push_back({cycle[i], cycle[j]});
					}
					i += sz - 1;
				}
			}
		}
		else
		{ // generate random graph
			edges.resize(m);
			for(auto &[x, y] : edges){
				x = rnd.next(1, n);
				y = rnd.next(1, n);
				while(x == y) x = rnd.next(1, n);
			}
		}
	}
	else{
		// 1) generate small (vertices <= 50) bipartite components
		// 2.1) connect components with every ~100th query
		// 2.2) other queries connect vertices from same component
		// 3) add fail edges after half of the queries have been processed
		vector<int> perm(n);
		iota(all(perm), 1);
		vector<pair<vector<int>, vector<int>>> components;
		for(int i = 0; i < n; ){
			int sz = min(n - i, rnd.next(2, 50));
			vector<int> temp;
			for(int j = 0; j < sz; j ++){
				temp.push_back(perm.at(i ++));
			}
			int k = rnd.next(1, max(1, sz / 2));
			components.push_back({vector<int>(), vector<int>()});
			for(int j = 0; j < sz; j ++){
				if(j < k) components.back().first.push_back(temp.at(j));
				else components.back().second.push_back(temp.at(j));
			}
		}
		assert(!components.empty());
		for(int i = 0; i < m; i ++){
			int j = rnd.next(0, SZ(components) - 1);
			int a = rnd.next(0, SZ(components[j].first) - 1);
			int b = rnd.next(0, SZ(components[j].second) - 1);
			edges.push_back({components.at(j).first.at(a), components.at(j).second.at(b)});
		}
		for(int i = 0; i < q; i ++){
			if(i < q / 2 + sqrt(q) || rnd.next(1, 100) > (rnd.next(0, 1) ? 5 : 10)){
				if(rnd.next(1, 100) > 1){
					int j = rnd.next(0, SZ(components) - 1);
					int a = rnd.next(0, SZ(components.at(j).first) - 1);
					int b = rnd.next(0, SZ(components.at(j).second) - 1);
					queries.push_back({components.at(j).first.at(a), components.at(j).second.at(b)});
				}
				else{
					int j = rnd.next(0, SZ(components) - 1);
					int k = rnd.next(0, SZ(components) - 1);
					while(j != k) j = rnd.next(0, SZ(components) - 1);
					int a = rnd.next(0, SZ(components.at(j).first) - 1);
					int b = rnd.next(0, SZ(components.at(k).second) - 1);
					queries.push_back({components.at(j).first.at(a), components.at(k).second.at(b)});
				}
			}
			else{
				int a = rnd.next(1, n);
				int b = rnd.next(1, n);
				queries.push_back({a, b});
			}
		}
	}
	cout << n << " " << m << " " << q << endl;
	for(auto [x, y] : edges){
		cout << x << " " << y << endl;
	}
	for(auto [x, y] : queries){
		cout << x << " " << y << endl;
	}
}
