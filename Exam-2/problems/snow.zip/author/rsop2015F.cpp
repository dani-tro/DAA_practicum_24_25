#include <bits/stdc++.h>

using namespace std;

#define MAX 100024

#define PA pair<double, int>

int n, m, a, b, par[MAX];

double c, dist[MAX];

bool used[MAX];

vector<pair<int, double> > gr[MAX];

void dijkstra(int a, int b)
{
	fill(dist, dist + n + 4, INT_MAX);
	fill(used, used + n + 4, false);
	
	dist[a] = 0;
	
	priority_queue<PA, vector<PA>, greater<PA> > pq;
	pq.push({0, a});
	while(!pq.empty())
	{
		a = pq.top().second;
		pq.pop();
		if(used[a])continue;
		used[a] = true;
		
		for(auto p : gr[a])
		{
			if(dist[p.first] > dist[a] + p.second)
			{
				dist[p.first] = dist[a] + p.second;
				par[p.first] = a;
				pq.push({dist[p.first], p.first});
			}
		}
	}
	
	return;
}

void solve()
{
	cin >> n >> m;
	
	for(int i = 0; i < m; i++)
	{
		cin >> a >> b >> c;
		gr[a].push_back({b, -log(c * (0.001))});
		gr[b].push_back({a, -log(c * (0.001))});
	}
	
	cin >> a >> b;
	dijkstra(a, b);
	int node = b;
	
	stack<int> s;
	while(node != a)
	{
		s.push(node);
		node = par[node];
	}
	cout << a;
	while(!s.empty())
	{
		cout << " " << s.top();
		s.pop();
	}
	cout << endl;
	
	return ;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	
	solve();
	
	return 0;
}
