#include <cstring>
#include <iostream>
#include <vector>
using namespace std;

const int nmax=100001;

vector<int> tree[nmax];
vector<int> NLevel;

int fathers[nmax];
int subordinates[nmax];
int n;
int Q;
int qn;


void input(){
int u,v;
cin >> n;

  for(int i=1;i<n;i++){
    cin >> u >> v;
    fathers[v]=u;
    tree[u].push_back(v);
  }
}

void fillNLevel(int r) {

int uk = 0;
int a,b,x;

NLevel.push_back(r);
while (uk<NLevel.size()){
    a=NLevel[uk];
    if (tree[a].size()>0){
        for (int i=0;i<tree[a].size();i++){
            x = tree[a][i];
            NLevel.push_back(x);
        }
    }
    uk++;
}

}
int main() {
  memset(fathers,0,sizeof(fathers));
  memset(subordinates,0,sizeof(subordinates));
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  input();
  int r;
  for (int i= 1;i<=n;i++)
    if (fathers[i]== 0){
     r=i;
     break;
  }
  fillNLevel(r);
  for (int i=NLevel.size()-1;i>0;i--)
    subordinates[fathers[NLevel[i]]]+=subordinates[NLevel[i]]+1;
  cin >> Q;
  for (int j=1;j<=Q;j++){
    cin >> qn;
    cout <<subordinates[qn]<<"\n";
  }
return 0;
}
