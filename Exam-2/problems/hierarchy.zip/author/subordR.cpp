#include <cstring>
#include <iostream>
#include <vector>
using namespace std;

const int nmax=100001;
vector<int> tree[nmax];
int fathers[nmax];
int subordinates[nmax];
int n;
int Q;
int qn;


void input(){
int u,v;
cin >> n;

  for(int i=1;i<n;i++){
    cin >> u >> v;
    fathers[v]=u;
    tree[u].push_back(v);
  }
}

int subcount(int a) {
  int s=0;

  if (tree[a].size() == 0 )
    subordinates[a] = 0;
  else{
    for (int i=0; i<tree[a].size();i++)
       s=s+subcount(tree[a][i])+1;
    subordinates[a]=s;
  }
  return s;
}


int main() {
  memset(fathers,0,sizeof(fathers));
  memset(subordinates,0,sizeof(subordinates));
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  input();

  int r;
  for (int i= 1;i<=n;i++)
    if (fathers[i]== 0){
     r=i;
     break;
  }
  subcount(r);

  cin >> Q;
  for (int j=1;j<=Q;j++){
    cin >> qn;
    cout <<subordinates[qn]<<"\n";
  }


return 0;
}
