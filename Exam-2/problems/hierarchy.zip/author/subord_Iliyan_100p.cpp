#include<iostream>
#include<assert.h>
#include<vector>
#include<stack>
#define MAXN 100000
using namespace std;
vector <int> a[MAXN];
int in[MAXN],cnt[MAXN],used[MAXN];
int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    assert(cin >> n );
    assert((1<=n)&&(n<=MAXN));
    int x,y;
    for (int i=0; i<n-1; i++) {
        assert(cin >> x >> y );
        assert((1<=x)&&(x<=n));
        assert((1<=y)&&(y<=n));
        x--; y--;
        a[x].push_back(y);
        in[y]++;
    }
    int root;
    for (int i=0; i<n; i++) {
        if (in[i]==0) {
            root=i;
            break;
        }
    }
    stack <int> rec;
    rec.push(root);
    for (;;) {
        if (rec.empty()==true) break;
        auto vr=rec.top();
        if (used[vr]==false) {
            used[vr]=true;
            for (auto to : a[vr]) {
                rec.push(to);
            }
        }
        else {
            for (auto to : a[vr]) {
                cnt[vr]+=(cnt[to]+1);
            }
            rec.pop();
        }
    }
    for (int i=0; i<n; i++) {
        assert(used[i]==true);
    }
    int q;
    assert(cin >> q );
    assert((1<=q)&&(q<=n));
    for (int i=0; i<q; i++) {
        assert(cin >> x );
        assert((1<=x)&&(x<=n));
        x--;
        cout << cnt[x] << "\n";
    }
    char temp; assert(!(cin >> temp ));
    return 0;
}
