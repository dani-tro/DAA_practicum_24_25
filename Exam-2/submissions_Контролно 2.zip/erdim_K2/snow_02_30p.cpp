#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int MAXN = 1e5 + 10;
const int INF = 1e9;
struct Edge {
    int ver, w;
    bool operator<(const Edge& other) const {
        return w > other.w;
    }
};
vector<Edge> v[MAXN];
int dist[MAXN];
int prv[MAXN];
priority_queue<Edge> pq;

void dijkstra(int k) {
    for(Edge edge : v[k]) {
        int to = edge.ver, w = edge.w;
        if(dist[to] > dist[k] * w) {
            dist[to] = dist[k] * w;
            prv[to] = k;
            pq.push({to, dist[to]});
        }
    }

    while(!pq.empty()) {
        Edge top = pq.top();
        if(dist[top.ver] != top.w) 
            pq.pop();
        else
            break;
    }


    if(!pq.empty()){
        int next = pq.top().ver;
        pq.pop();
        dijkstra(next);
    }

}

bool fl[MAXN];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n, m;
    cin>>n>>m;
    for(int i=1;i<=m;i++) {
        int p, q, w;
        cin>>p>>q>>w;
        v[p].push_back({q, 1000 - w});
        v[q].push_back({p, 1000 - w});
    }

    int from, to;
    cin>>from>>to;

    for(int i=1;i<=n;i++) dist[i] = INF;
    dist[from] = 1;

    dijkstra(from);

    //for(int i=1;i<=n;i++) cout<<dist[i]<<" ";  cout<<endl;


    vector<int> path;
    int ver = to;
    while(ver != from) {
        if(fl[ver]) break;
        fl[ver] = true;
        path.push_back(ver);
        ver = prv[ver];
    }
    path.push_back(from);

    reverse(path.begin(), path.end());

    for(int ver : path)
        cout<<ver<<" ";
    cout<<endl;

    return 0;
}