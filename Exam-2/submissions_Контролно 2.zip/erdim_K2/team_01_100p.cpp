#include <iostream>
#include <vector>
using namespace std;

const int MAXN = 2e5 + 10;

struct DSU {

    int lead[MAXN];
    bool switch_team[MAXN];
    bool bipartite;

    DSU(int n) {
        for(int i=1;i<=n;i++) {
            lead[i] = i;
            switch_team[i] = false;
        }
        bipartite = true;
    }

    int findLead(int k) {
        if(lead[k] == k) 
            return k;
        int root = findLead(lead[k]);
        if(lead[k] != root)
            switch_team[k]^= switch_team[lead[k]];
        lead[k] = root;
        return root;
    }

    void connect(int p, int q) {
        int leadP = findLead(p);
        int leadQ = findLead(q);
        bool teamP = switch_team[p] ^ (switch_team[leadP] && leadP != p);
        bool teamQ = switch_team[q] ^ (switch_team[leadQ] && leadQ != q);

        //cout<<p<<" "<<q<<"  "<<switch_team[p]<<" "<<switch_team[q]<<endl;

        if(leadP == leadQ) {
            if(teamP == teamQ)
                bipartite = false;
        }
        else {
            lead[leadP] = leadQ;
            if(teamP == teamQ) switch_team[leadP]^= 1;
        }

    }

};

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);  cout.tie(NULL);

    int n, m, t;
    cin>>n>>m>>t;
    DSU dsu(n);

    for(int i=1;i<=m;i++) {
        int p, q;
        cin>>p>>q;
        dsu.connect(p, q);
    }

    if(!dsu.bipartite) {
        cout<<-1<<endl;
        return 0;
    }

    for(int i=1;i<=t;i++) {
        int p, q;
        cin>>p>>q;
        dsu.connect(p, q);
        if(!dsu.bipartite) {
            cout<<i<<endl;
            return 0;
        }
    }

    cout<<-2<<endl;

    return 0;
}