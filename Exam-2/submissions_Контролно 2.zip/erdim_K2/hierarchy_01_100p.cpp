#include <iostream>
#include <vector>
using namespace std;

const int MAXN = 1e5 + 10;
vector<int> v[MAXN];
bool fl[MAXN];
int subtr[MAXN];

int dfs(int k){
    subtr[k] = 1;
    for(int child : v[k]) {
        subtr[k]+= dfs(child);
    }
    return subtr[k];
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    int n, t;
    cin>>n;
    for(int i=1;i<n;i++) {
        int p, q;
        cin>>p>>q;
        v[p].push_back(q);
        fl[q] = true;
    }

    int root = 1;
    for(int i=1;i<=n;i++) {
        if(fl[i] == false) {
            root = i;
            break;
        }
    }

    dfs(root);

    cin>>t;
    for(int i=1;i<=t;i++) {
        int k;
        cin>>k;
        cout<<subtr[k]-1<<"\n";
    }


    return 0;
}