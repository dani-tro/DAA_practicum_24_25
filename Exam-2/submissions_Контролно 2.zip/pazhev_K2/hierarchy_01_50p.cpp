#include <bits/stdc++.h>
using namespace std;

#define MAX 100010

size_t n;
unsigned hierarchy[MAX], counter[MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n;
    unsigned u, v, q;

    for (size_t i = 0; i < n - 1; ++i) {
        cin >> u >> v;
        hierarchy[v] = u;
        unsigned amount = 1 + counter[v];

        while (u != 0) {
            counter[u] += amount;
            u = hierarchy[u];
        }
    }

    cin >> q;
    for (unsigned i = 0; i < q; ++i) {
        cin >> u;
        cout << counter[u] << '\n';
    }

    return 0;
}