    #include <bits/stdc++.h>
    using namespace std;

    #define MAX 200010

    size_t n, m, q;
    vector<unsigned> graph[MAX];
    unsigned col[MAX], comp[MAX], h[MAX], h_col[MAX];

    unsigned find(unsigned x) {
        if (comp[x] == x) {
            return x;
        }
        
        return comp[x] = find(comp[x]);
    }

    void unify(unsigned x, unsigned y) {
        x = find(x);
        y = find(y);

        if (x == y) {
            return;
        }

        if (h[x] > h[y]) {
            swap(x, y);
        }

        comp[x] = y;

        if (h[x] == h[y]) {
            ++h[y];
        }
    }

    unsigned find_col(unsigned x) {
        if (col[x] == x) {
            return x;
        }
        
        return col[x] = find(col[x]);
    }

    void unify_col(unsigned x, unsigned y) {
        x = find_col(x);
        y = find_col(y);

        if (x == y) {
            return;
        }

        if (h_col[x] > h_col[y]) {
            swap(x, y);
        }

        col[x] = y;

        if (h_col[x] == h_col[y]) {
            ++h_col[y];
        }
    }

    bool dfs(unsigned s, unsigned c, unsigned c2, unsigned component) {
        unify_col(s, c);
        comp[s] = component;

        for (unsigned u : graph[s]) {
            if (find_col(u) == find_col(c)) {
                return false;
            }

            if (comp[u] != 0) {
                continue;
            } 

            if (c2 == 0) {
                c2 = u;
            }
            
            if (!dfs(u, c2, c, component)) {
                return false;
            }
        }

        return true;
    }

    bool is_bipartite() {
        for (size_t i = 1; i <= n; ++i) {
            col[i] = i;
            h_col[i] = 0;
        }

        for (size_t i = 1; i <= n; ++i) {
            if (comp[i] == 0) {
                h[i] = graph[i].size() > 0;

                if (!dfs(i, i, 0, i)) {
                    return false;
                }
            }
        }

        return true;
    }

    int main() {
        ios_base::sync_with_stdio(false);
        cin.tie(nullptr);
        cout.tie(nullptr);

        cin >> n >> m >> q;
        unsigned u, v;

        for (size_t i = 0; i < m; ++i) {
            cin >> u >> v;
            graph[u].push_back(v);
            graph[v].push_back(u);
        }

        bool possible = is_bipartite();

        if (!possible) {
            cout << -1;
        }

        for (size_t i = 1; i <= q; ++i) {
            cin >> u >> v;

            if (possible) {
                

                if (find(u) != find(v)) {

                } else if (find_col(u) == find_col(v)) {
                    cout << i;
                    possible = false;
                }
            }
        }

        if (possible) {
            cout << -2;
        }

        return 0;
    }