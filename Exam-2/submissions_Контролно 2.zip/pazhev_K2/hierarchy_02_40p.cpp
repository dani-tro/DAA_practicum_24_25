#include <bits/stdc++.h>
using namespace std;

#define MAX 100010

size_t n;
unsigned hierarchy[MAX], counter[MAX];
bool is_not_leaf[MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n;
    unsigned u, v, q;

    for (size_t i = 0; i < n - 1; ++i) {
        cin >> u >> v;
        hierarchy[v] = u;
        is_not_leaf[u] = true;
    }

    queue<unsigned> qu;

    for (size_t i = 1; i <= n; ++i) {
        if (!is_not_leaf[i]) {
            qu.push(i);
        }
    }

    while (!qu.empty()) {
        u = qu.front();
        qu.pop();
        v = hierarchy[u];
        counter[v] += 1 + counter[u];

        if (v != 0) {
            qu.push(v);
        }
    }

    cin >> q;
    for (unsigned i = 0; i < q; ++i) {
        cin >> u;
        cout << counter[u] << '\n';
    }

    return 0;
}