#include <bits/stdc++.h>
using namespace std;

#define MAX 200010

size_t n, m, q;
vector<unsigned> graph[MAX];
unsigned comp[MAX];

bool dfs(unsigned s, unsigned c) {
    comp[s] = c;

    for (unsigned u : graph[s]) {
        if (comp[u] == c || comp[u] == 0 && !dfs(u, 3 - c)) {
            return false;
        }
    }

    return true;
}

bool is_bipartite() {
    for (size_t i = 1; i <= n; ++i) {
        if (comp[i] == 0 && !dfs(i, 1)) {
            return false;
        }
    }

    return true;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> q;
    unsigned u, v;

    for (size_t i = 0; i < m; ++i) {
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    if (!is_bipartite()) {
        cout << -1;
    }

    for (size_t i = 0; i < q; ++i) {
        cin >> u >> v;
    }

    return 0;
}