#include <bits/stdc++.h>
using namespace std;

#define MAX 100010
#define edge pair<unsigned, unsigned>

size_t n, m;
vector<edge> graph[MAX];
unsigned p[MAX], d[MAX];
priority_queue<edge, vector<edge>, greater<edge>> pq;

void dijkstra(unsigned s) {
    for (size_t i = 1; i <= n; ++i) {
        d[i] = -1;
    }

    d[s] = 0;
    pq.push({ d[s], s });

    while (!pq.empty()) {
        s = pq.top().second;
        pq.pop();

        for (edge e : graph[s]) {
            if (d[e.first] > d[s] + e.second) {
                d[e.first] = d[s] + e.second;
                p[e.first] = s;
                pq.push({ d[e.first], e.first });
            }
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    unsigned a, b, c;

    for (size_t i = 0; i < m; ++i) {
        cin >> a >> b >> c;

        graph[a].push_back({ b, 1000 - c });
        graph[b].push_back({ a, 1000 - c });
    }

    cin >> a >> b;
    dijkstra(a);
    stack<unsigned> path;

    while (b != a) {
        path.push(b);
        b = p[b];
    }

    path.push(a);

    while (!path.empty()) {
        cout << path.top() << " ";
        path.pop();
    }

    return 0;
}