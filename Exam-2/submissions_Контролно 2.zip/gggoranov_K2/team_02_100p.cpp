#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e6;
int n, m, q, a, b, comp[maxn], d[maxn], vis[maxn];
vector<int> gr[maxn];


int find(int v){
    if(comp[v] == v) return v;
    return comp[v] = find(comp[v]);
}

void Union(int u, int v){
    u = find(u);
    v = find(v);
    if(u == v) return;
    if(d[u] > d[v]) swap(u, v);
    comp[u] = v;
    if(d[u] == d[v]) ++d[v];
}


bool has_cycle(int node){
    vis[node] = 1;
    for(auto u : gr[node]){
        if(vis[u]){
            return true;
        }
        if(has_cycle(u)) return true;
    }
    return false;
}

bool check_for_paths(int a, int b){
    for(auto u : gr[b]){
        if(u != a) Union(u, a);
    }
    for(auto u : gr[a]){
        if(u != b) Union(u, b);
    }
    return (find(a) == find(b));
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> q;
    for(int i = 1; i <= n; ++i){
        comp[i] = i;
    }
    for(int i = 1; i <= m; ++i){
        cin >> a >> b;
        gr[a].push_back(b);
        gr[b].push_back(a);
        if(check_for_paths(a, b)){
            cout << -1 << endl;
            return 0;
        }
    }

    for(int i = 1; i <= q; ++i){
        cin >> a >> b;
        gr[a].push_back(b);
        gr[b].push_back(a);
        if(check_for_paths(a, b)){
            cout << i << endl;
            return 0;
        }
    }
    cout << -2 << endl;

    return 0;
}