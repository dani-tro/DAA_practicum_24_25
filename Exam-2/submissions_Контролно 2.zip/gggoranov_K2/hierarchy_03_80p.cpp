#include <bits/stdc++.h>
using namespace std;


const int maxn = 1e5+10;
long long n, a, b, q, m, d[maxn], underlings[maxn];

vector<int> gr[maxn];


int dfs(int node){
    int res = gr[node].size();
    for(auto u : gr[node]){
        underlings[u] = dfs(u);
        res += underlings[u];
    }
    return res;
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n;
    for(int i = 1; i <= n - 1; ++i){
        cin >> a >> b;
        gr[a].push_back(b);
        ++d[b];
    }
    int root;
    for(int i = 1; i <= n; ++i){
        if(d[i] == 0) root = i;
    }

    underlings[root] = n - 1;
    dfs(root);

    cin >> q;
    for(int i = 1; i <= q; ++i){
        cin >> m;
        cout << underlings[m] << endl;
    }

    return 0;
}