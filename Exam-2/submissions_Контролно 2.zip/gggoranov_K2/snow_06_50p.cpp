#include <bits/stdc++.h>
using namespace std;

#define PAIR pair<long long, long long>


const int maxn = 1e5+10;
unsigned long long n, m, a, b, c, d[maxn];
vector<pair<int, double>> gr[maxn];
vector<int> paths[maxn];
priority_queue<PAIR, vector<PAIR>, greater<PAIR>> pq;


void dijkstra(long long node){
    for(int i = 0; i <= n; ++i){
        d[i] = ULONG_LONG_MAX / 2;
    }
    d[node] = 0;
    pq.push({d[node], node});
    while(!pq.empty()){
        node = pq.top().second;
        pq.pop();
        for(auto u : gr[node]){
            if(d[node] == 0){
                d[u.first] = u.second;
                paths[u.first].push_back(node);
                pq.push({d[u.first], u.first});
                continue;
            }
            if(d[u.first] > d[node] * u.second){
                d[u.first] = d[node] * u.second;
                pq.push({d[u.first], u.first});
                paths[u.first] = paths[node];
                paths[u.first].push_back(node);
            }
        }
    }
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    for(int i = 1; i <= m; ++i){
        cin >> a >> b >> c;
        gr[a].push_back({b, 1000 - c});
        gr[b].push_back({a, 1000 - c});
    }

    cin >> a >> b;
    dijkstra(a);
    for(auto p : paths[b]){
        cout << p << " ";
    }
    cout << b << endl;

    return 0;
}