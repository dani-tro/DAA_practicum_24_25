#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
vector<ll> edges[100005];
ll n, q, l, r, curr;
ll children[100005];

ll childrenCount(ll node) {
    if (children[node]) return children[node];
    if (edges[node].empty()) {
        children[node] = 0;
        return 0;
    }
    for (ll child: edges[node]) {
        children[node] += childrenCount(child) + 1;
    }
    return children[node];
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> n;


    for (ll i = 0; i < n - 1; ++i) {
        cin >> l >> r;
        edges[l - 1].push_back(r - 1);
    }
    cin >> q;
    for (ll i = 0; i < q; ++i) {
        cin >> curr;
        --curr;
         cout << childrenCount(curr) << '\n';
    }
}
