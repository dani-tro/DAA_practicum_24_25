#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
vector<ll> edges[200015]; // to -> weight
bool vis[200015];
ll n, m, days;
ll l, r;
ll daysNeeded = 1;
ll parent[200015];

bool hasCycle(ll source) {
    queue<ll> q;
    q.push(source);
    vis[source] = 1;
    while(!q.empty()) {
        ll curr = q.front();
        q.pop();
        vis[curr] = 1;
        // cout << "visiting: " << curr + 1 << endl;
        for (ll neighbour : edges[curr]) {
            if (vis[neighbour] && neighbour != parent[curr]) {
                // cout << "BAD" << neighbour << " " << curr << endl;
                 return true;
            }
            if (vis[neighbour]) continue;
            // cout << "parent of: " << neighbour + 1 << " is " << curr + 1 << endl;
            parent[neighbour] = curr;
            q.push(neighbour);
        }
    }
    return false;
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> n >> m >> days;

    for (ll i = 0; i < m; ++i) {
        cin >> l >> r;
        edges[l - 1].push_back(r - 1);
        edges[r - 1].push_back(l - 1);
    }
    for (ll i = 0; i < n; ++i) {
        if (vis[i]) continue;
        if (hasCycle(i)) {
            cout << -1;
            return 1;
        } 
    }
    
    for (ll i = 0; i < days; ++i) {
        cin >> l >> r;
        edges[l - 1].push_back(r - 1);
        edges[r - 1].push_back(l - 1);
        if (hasCycle(l - 1)) {
            cout << daysNeeded;
            return 1;
        }
        ++daysNeeded;
    }
    cout << -2;
}
