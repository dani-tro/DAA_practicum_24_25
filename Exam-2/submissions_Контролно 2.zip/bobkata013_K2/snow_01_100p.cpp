#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
vector<pair<ll, double>> edges[100005]; // to -> weight
ll parent[100005];
ll path[100005];
double dists[100005];
bool vis[100005];
ll n, m;
ll l, r;
ll sourceNode, endNode;
double w;
ll pathLength = 0;
ll prevP;

void dijkstra(ll source) {
    for (ll i = 0; i < n; ++i) {
        dists[i] = -1;
        vis[i] = 0;
    }

    // priority_queue<pair<double, ll>, vector<pair<double, ll>>, greater<pair<double, ll>>> pq; // reversed, cuz we compare on the first one
    priority_queue<pair<double, ll>> pq;
    dists[source] = 1;
    pq.push({dists[source], source});

    while (!pq.empty()) {
        pair<double, ll> curr = pq.top();
        pq.pop();
        if (vis[curr.second]) continue;
        vis[curr.second] = 1;

        for (pair<ll, double> neighbour : edges[curr.second]) {
            double ndist = curr.first * neighbour.second; // dists[curr.second] * neighbour.second
            if (ndist > dists[neighbour.first]) {
                dists[neighbour.first] = ndist;
                pq.push({dists[neighbour.first], neighbour.first});
                parent[neighbour.first] = curr.second;
            }
        }
    }
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> n >> m;

    for (ll i = 0; i < m; ++i) {
        cin >> l >> r >> w;
        w /= 1000;
        edges[l - 1].push_back({r - 1, w});
        edges[r - 1].push_back({l - 1, w});
    }
    cin >> sourceNode >> endNode;
    --sourceNode;
    --endNode;
    dijkstra(sourceNode);

    // for (ll i = 0; i < n; ++i) {
    //     cout << dists[i] << '\n';
    // }

    ll curr = endNode;
    path[pathLength] = endNode;
    while(curr != sourceNode) {
        ++pathLength;
        curr = parent[curr];
        path[pathLength] = curr;
    }

    for (ll i = pathLength; i>=1; --i) {
        cout << path[i] + 1 << ' ';
    }
    cout << path[0] + 1;
}
