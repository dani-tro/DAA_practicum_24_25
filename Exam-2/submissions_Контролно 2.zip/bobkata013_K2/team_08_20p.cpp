#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
vector<ll> edges[200015]; // to -> weight
bool vis[200015];
ll n, m, days;
ll l, r;
ll daysNeeded = 1;
ll parent[200015];

bool hasCycle(ll source)
{
    queue<ll> q;
    q.push(source);
    vis[source] = 1;
    while (!q.empty())
    {
        ll curr = q.front();
        q.pop();
        vis[curr] = 1;
        for (ll neighbour : edges[curr])
        {
            if (vis[neighbour] && neighbour != parent[curr])
            {
                return true;
            }
            if (vis[neighbour])
                continue;
            parent[neighbour] = curr;
            q.push(neighbour);
        }
    }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> n >> m >> days;

    if (m > 0)
    {
        for (ll i = 0; i < m; ++i)
        {
            cin >> l >> r;
            edges[l - 1].push_back(r - 1);
            edges[r - 1].push_back(l - 1);
        }
        for (ll i = 0; i < n; ++i)
        {
            if (vis[i])
                continue;
            if (hasCycle(i))
            {
                cout << -1;
                return 0;
            }
        }
    }

    for (ll j = 0; j < n; ++j) {
            vis[j] = 0;
            parent[j] = 0;
        }

    for (ll i = 0; i < days; ++i)
    {

        cin >> l >> r;

        edges[l - 1].push_back(r - 1);
        edges[r - 1].push_back(l - 1);
        if (hasCycle(l - 1))
        {
            cout << daysNeeded;
            return 0;
        }
        ++daysNeeded;
    }
    cout << -2;
}
