#include <iostream>
#include <vector>

using namespace std;

void updateAncestorsDescendentsCount(vector<int>& parents, vector<int>& children, vector<int>& descendents, int childNode) {
	int currNode = parents[childNode];
	while (currNode) {
		descendents[currNode] += descendents[childNode] + 1;
		childNode = currNode;
		currNode = parents[childNode];
	}
}

int main() {
	ios_base::sync_with_stdio(false);

	cin.tie(nullptr);

	cout.tie(nullptr);

	int n;
	cin >> n;
	vector<int> parents(n + 1, 0);
	vector<int> children(n + 1, 0);

	int currParent, currChild;
	for (int i = 0; i < n - 1; ++i) {
		cin >> currParent >> currChild;
		parents[currChild] = currParent;
		++children[currParent];
	}

	vector<int> descendents(n + 1, 0);

	for (int i = 1; i <= n; ++i) {
		if (children[i] == 0) {
			updateAncestorsDescendentsCount(parents, children, descendents, i);
		}
	}

	int q, m;
	cin >> q;
	while (q--) {
		cin >> m;
		cout << descendents[m] << '\n';
	}

	return 0;
}