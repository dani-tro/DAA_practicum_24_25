#include <iostream>
#include <vector>
#include <queue>

using namespace std;

const int maxN = 10000;
vector<pair<int, double>> graph[maxN];


int main() {
	ios_base::sync_with_stdio(false);

	cin.tie(nullptr);

	cout.tie(nullptr);

	int n, m;
	cin >> n >> m;
	int u, v;
	double w;
	for (int i = 0; i < m; ++i) {
		cin >> u >> v >> w;
		graph[u].push_back({ v, w  });
		graph[v].push_back({ u, w  });
	}

	int start, end;
	cin >> start >> end;

	vector<vector<int>> paths(n + 1);
	paths[start].push_back(start);
	vector<double> dist(n + 1, 10.0);
	priority_queue<pair<double, int>> pq;
	pq.push({ 1, start });

	int currNode = start;
	double currNodeDistance = 1;
	while (!pq.empty()) {

		if (currNode == end) {
			break;
		}

		currNode = pq.top().second;
		currNodeDistance = pq.top().first;
		pq.pop();

		for (auto& neighbor : graph[currNode]) {
			if (dist[neighbor.first] < currNodeDistance * neighbor.second) {
				dist[neighbor.first] = currNodeDistance * neighbor.second;
				pq.push({ dist[neighbor.first], neighbor.first });
				paths[neighbor.first].clear();
				for (auto& e : paths[currNode]) {
					paths[neighbor.first].push_back(e);
				}
				paths[neighbor.first].push_back(neighbor.first);
			}
		}
	}

	for (auto& el : paths[end]) {
		cout << el << " ";
	}

	return 0;
}