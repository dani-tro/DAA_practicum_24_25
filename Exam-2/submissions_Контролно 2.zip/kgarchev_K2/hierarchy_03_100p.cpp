#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int MAX_N = 1e5 + 1;

int n, root;
vector<int> tr[MAX_N];
bitset<MAX_N> isChld = 0;
int sz[MAX_N];

void readInput()
{
    cin >>n;
    int f, t;
    for(int i = 0; i < n - 1; ++i)
    {
        cin >>f >>t;
        tr[f].push_back(t);
        isChld[t] = 1;
    }

    for(int i = 1; i <= n; ++i)
    {
        if(!isChld[i])
        {
            root = i;
            break;
        }
    }
}

void dfs(int v)
{
    sz[v] = 0;
    for(int nb : tr[v])
    {
        dfs(nb);
        sz[v] += sz[nb] + 1;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    readInput();
    dfs(root);

    int q, t;
    cin >>q;
    while(q--)
    {
        cin >>t;
        cout <<sz[t] <<"\n";
    }
}
