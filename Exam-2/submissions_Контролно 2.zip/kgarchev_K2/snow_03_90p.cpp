#include<bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;

const int MAX_N = 1e5;
const int INF = 10;

int n,m, s, e;
vector<pair<int, ld>> g[MAX_N];
ld d[MAX_N];
int par[MAX_N];
//bool vis[MAX_N];

void readInput()
{
    cin >>n >>m;
    int f, t, w;
    for(int i=0; i < m; ++i)
    {
        cin >>f >>t >>w;
        --f;--t;
        g[f].emplace_back(t, (ld)3.0 - log10(w));
        g[t].emplace_back(f, (ld)3.0 - log10(w));
    }
    cin >>s >>e;
    --s;--e;
}

struct Comp
{
    inline bool operator()(const pair<ld, int> a, const pair<ld, int> b) const
    {
        return a.first < b.first;
    }
};


void dijkstra(int s, int e)
{
    fill(d, d + n, INF);
    set<pair<ld, int>, Comp> q = set<pair<ld, int>, Comp>(Comp());
    d[s] = 1;
    q.insert({d[s], s});
    par[s] = -1;
    int v;
    ld dis;
    while(!q.empty())
    {
        v = q.begin()->second;
        dis = q.begin()->first;
        q.erase(q.begin());
        //vis[v] = true;
        if(v == e) break;
        for(const auto [nb, w] : g[v])
        {
            if(dis + w < d[nb])
            {
                q.erase({d[nb], nb});
                d[nb] = dis + w;
                par[nb] = v;
                q.insert({d[nb], nb});
            }
        }
    }

    vector<int> res;
    while(e != -1)
    {
        res.push_back(e);
        e = par[e];
    }

    for(int i = res.size() - 1; i >= 0; --i)
    {
        cout <<res[i] + 1 <<" ";
    }
    cout <<endl;
}


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(nullptr);

    readInput();
    dijkstra(s, e);
}
