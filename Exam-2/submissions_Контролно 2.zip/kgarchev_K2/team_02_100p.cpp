#include<bits/stdc++.h>
using namespace std;

using ll = long long;

const int MAX_N = 2e5;

int n, m, q;
vector<int> g[MAX_N];
bool vis[MAX_N];
bool lvl[MAX_N];
int ld[MAX_N];
int rk[MAX_N];
bool sg[MAX_N];
int ld2[MAX_N];
int rk2[MAX_N];

void readInput()
{
    cin >>n >>m >>q;
    int f, t;
    for(int i = 0; i < m; ++i)
    {
        cin >>f >>t;
        --f; --t;
        g[f].push_back(t);
        g[t].push_back(f);
    }
}

void prepare()
{
    for(int i = 0; i < n; ++i)
    {
        ld[i] = i;
        rk[i] = 0;
        sg[i] = 0;
        ld2[i] = i;
        rk2[i] = 0;
    }
}

int getLeader(int v)
{
    if(ld[v] == v) return v;
    return ld[v] = getLeader(ld[v]);
}

void unite(int u, int v)
{
    u = getLeader(u);
    v = getLeader(v);
    if(rk[u] < rk[v]) swap(u, v);
    ld[v] = u;
    if(rk[v] == rk[u]) ++(rk[u]);
}

bool ans = true;
void dfs(int v, int p = -1)
{
    lvl[v] = p == -1 ? 0 : lvl[p] ^ 1;
    vis[v] = true;
    for(int nb : g[v])
    {
        unite(v, nb);
        if(vis[nb])
        {
            ans = ans && (lvl[v] ^ lvl[nb] == 1);
        }
        else
        {
            dfs(nb, v);
        }
    }
}

pair<int, bool> getLeader2(int v)
{
    if(ld2[v] == v) return {v, 0};
     auto [a, b] = getLeader2(ld2[v]);
     sg[v] = sg[v] ^ b;
     ld2[v] = a;
     return {a, sg[v]};
}

void unite2(int u, int v)
{
    auto [lu, su] = getLeader2(getLeader(u));
    auto [lv, sv] = getLeader2(getLeader(v));

    //cout <<"1): " <<"lu: " <<lu + 1 <<" sg[lu]: " <<sg[lu] <<"lv: " <<lv + 1 <<" sg[lv]: " <<sg[lv] <<" su: " <<su <<" sv: " <<sv <<" sgn: " <<sgn <<endl;
    if(lu == lv)
    {
        ans = ans && (lvl[u] ^ su ^ sv ^ lvl[v] == 1);
        return;
    }
    if(rk2[lu] < rk2[lv]) swap(lu, lv),swap(su, sv);
    ld2[lv] = lu;
    //cout <<"2): " <<"lu: " <<lu + 1 <<" sg[lu]: " <<sg[lu] <<"lv: " <<lv + 1 <<" sg[lv]: " <<sg[lv] <<" su: " <<su <<" sv: " <<sv <<" sgn: " <<sgn <<endl;
    sg[lv] = sv ^ lvl[v] ^ 1 ^ lvl[u] ^ su;
    //cout <<"lv: " <<lv + 1 <<" sg[lv]: " <<sg[lv] <<endl;
    if(rk2[lv] == rk2[lu]) ++(rk2[lu]);
    //if(sg[lv] == 0) ans = false;
}
void addEdge(int u, int v)
{
    if(u == v)
    {
        ans = false;
        return;
    }
    unite2(u, v);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(nullptr);

    readInput();
    prepare();

    fill(vis, vis + n, false);
    for(int i = 0; i < n; ++i)
    {
        if(!vis[i]) dfs(i);
    }

    if(!ans)
    {
        cout <<-1 <<endl;
        return 0;
    }

    int f, t;
    for(int day = 1; day <= q; ++day)
    {
        cin >>f >>t;
        --f; --t;
        addEdge(f, t);
        if(!ans)
        {
            cout <<day <<endl;
            return 0;
        }
    }

    cout <<-2 <<endl;
}
