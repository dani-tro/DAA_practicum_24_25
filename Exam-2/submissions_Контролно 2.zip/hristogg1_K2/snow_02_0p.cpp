#include <iostream>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

#define MAX 100500

vector<pair<int , int>> gr[MAX];

queue<int> q;
queue<int> currBest;
queue<int> resQ;

int N = 0, Q = 0, M = 0, u = 0, v = 0, w = 0, maxRoad = 0, currMax = 0, visited[MAX], node = 0, START = 0, END = 0;

//int count(int ind) {
//	if (ind > N) return 0;
//	else {
//		return count(ind*2) + count(ind*2 + 1) + 1;
//	}
//}
//
//
//void hierarchy() {
//	for (int i = 1; i < N; ++i) {
//		if (d[i] == 0) {
//			pq.push(i);
//		}
//	}
//
//	int node = 0, size = 1;
//	while (!pq.empty()) {
//		node = pq.front();
//		tpSorted[size++] = node;
//
//		pq.pop();
//
//		for (auto i : gr[node]) {
//			d[i]--;
//			if (d[i] == 0) pq.push(i);
//		}
//	}
//
//	while (!questions.empty()) {
//		temp = questions.front();
//		questions.pop();
//		
//		for(int i=1;i<= N;++i)
//			if (tpSorted[i] == temp) {
//				index = i;
//				break;
//			}
//
//		cout << count(index*2) + count(index*2+1)<< '\n';
//	}
//}


int bfs(int start, int end, int minValue) {
	q.push(start);

	while (!q.empty()) {
		node = q.front();
		q.pop();
		if (visited[node]) continue;

		visited[node] = true;
		resQ.push(node);

		if (node == end)
			return resQ.size();

		for (auto i : gr[node]) {
			if (i.second >= minValue) {
				q.push(i.first);
			}
		}
	}

	return -1;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> N>>M;
	for (int i = 0; i <M; ++i) {
		cin >> u >> v>>w;
		gr[u].push_back({ v, w });
		gr[v].push_back({ u, w });
		maxRoad = max(maxRoad, w);
	}

	cin >> START >> END;

	int l = 10, r = maxRoad, mid;
	while (l < r) {
		mid = (l + r) / 2;

		for (int i = 0; i < N; ++i)
			visited[i] = false;

		while (!q.empty()) q.pop();

		while (!resQ.empty()) resQ.pop();

		int temp = bfs(START, END, mid);

		if (temp == -1) {
			r = mid;
			continue;
		}
		
		currMax = max(mid, currMax);

		if (currMax == mid)
			currBest = resQ;
		
		l = mid + 1;
	}

	while (!currBest.empty()) {
		cout << currBest.front() << "\n";
		currBest.pop();
	}
}