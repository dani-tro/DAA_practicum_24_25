#include <iostream>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

#define MAX 100500

vector<int> gr[MAX];

int N = 0, Q = 0, d[MAX], M, u = 0, v = 0, temp = 0, tpSorted[MAX], subTreeLevels = 0, index = 0, res =0;

queue<int> pq;

queue<int> questions;

int count(int ind) {
	if (ind >= N) return 0;
	else {
		return count(ind*2) + count(ind*2 + 1) + 1;
	}
}


void hierarchy() {
	for (int i = 1; i < N; ++i) {
		if (d[i] == 0) {
			pq.push(i);
		}
	}

	int node = 0, size = 1;
	while (!pq.empty()) {
		node = pq.front();
		tpSorted[size++] = node;

		pq.pop();

		for (auto i : gr[node]) {
			d[i]--;
			if (d[i] == 0) pq.push(i);
		}
	}

	while (!questions.empty()) {
		temp = questions.front();
		questions.pop();
		
		for(int i=1;i<= N;++i)
			if (tpSorted[i] == temp) {
				index = i;
				break;
			}

		cout << count(index*2) + count(index*2+1)<< '\n';
	}
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	for (int i = 0; i < MAX; ++i)
		d[MAX] = 0;


	cin >> N;
	for (int i = 1; i <N; ++i) {
		cin >> u >> v;
		gr[u].push_back(v);
		++d[v];
	}

	cin >> Q;
	for (int i = 0; i < Q; ++i) {
		cin >> temp;
		questions.push(temp);
	}

	hierarchy();

}