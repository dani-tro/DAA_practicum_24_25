#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <map>
#include <stack>

using namespace std;

#define MAX 100500

vector<pair<int , int>> gr[MAX];

priority_queue<pair<int,int>, vector<pair<int,int>>> pq;
stack<int> currBest;
map<int, int> trace;

int N = 0, Q = 0, M = 0, u = 0, v = 0, w = 0, maxRoad = 0, currMax = 0, visited[MAX], START = 0, END = 0, before = 0;

pair<int, int> node;

int bfs(int start, int end, int minValue) {
	pq.push({ -1, start });

	while (!pq.empty()) {
		node = pq.top();
		pq.pop();
		if (visited[node.second]) continue;

		visited[node.second] = true;

		if (node.second == end)
			return 1;;

		for (auto i : gr[node.second]) {
			if (i.second >= minValue) {
				if (!visited[i.first]) {
					pq.push({ i.second, i.first });
					trace.insert({ i.first, node.second });
				}

			}
		}
	}

	return -1;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> N>>M;
	for (int i = 0; i <M; ++i) {
		cin >> u >> v>>w;
		gr[u].push_back({ v, w });
		gr[v].push_back({ u, w });
		maxRoad = max(maxRoad, w);
	}

	cin >> START >> END;

	int l = 10, r = maxRoad, mid;
	while (l < r) {
		mid = (l + r) / 2;

		for (int i = 0; i <= N; ++i)
			visited[i] = false;

		trace.clear();

		while (!pq.empty()) pq.pop();

		int temp = bfs(START, END, mid);

		if (temp == -1) {
			r = mid;
			continue;
		}
		
		currMax = max(mid, currMax);

		if (currMax == mid) {
			while (!currBest.empty())
				currBest.pop();

			int node = END;
			while (true) {
				if(trace[node] == 0) break;
				
				currBest.push(node);
				node = trace[node];
			}
		}

		
		l = mid + 1;
	}

	cout << START << ' ';
	while (!currBest.empty()) {
		cout << currBest.top() << " ";
		currBest.pop();
	}
}