#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
#include <queue>

using namespace std;
long long n, m, a, b;
const long long maxn = 1e5 + 10;

/*struct edge
{
	long long u, v, w;
	bool operator <(const edge& other) const
	{
		return w > other.w;
	}
};
vector<edge> edges;
vector<long long> tree[maxn];

long long comp[maxn];
long long h[maxn];

long long find(long long u)
{
	if (comp[u] == u)
		return u;
	return comp[u] = find(comp[u]);
}

void Union(long long u, long long v)
{
	u = find(u);
	v = find(v);
	if (u == v)
		return;
	if (h[u] > h[v])
		swap(u, v);
	comp[u] = v;
	if (h[u] == h[v])
		++h[v];
}

void kruskal()
{
	for (size_t i = 1; i <= n; i++)
	{
		comp[i] = i;
	}
	long long cnt = 0;
	long long i = 0;
	while (cnt < n - 1)
	{
		edge edge = edges[i];
		if (find(edge.u) != find(edge.v))
		{
			tree[edge.u].push_back(edge.v);
			tree[edge.v].push_back(edge.u);
			Union(edge.u, edge.v);
			++cnt;
		}
		++i;
	}
}
bool used[maxn];

bool dfs(long long curr, vector<long long>& path)
{
	if (curr == b)
	{
		return true;
	}
	used[curr] = true;
	for (long long v : tree[curr])
	{
		if (!used[v])
		{
			path.push_back(v);
			if (dfs(v, path))
				return true;
			path.pop_back();
		}
	}
	return false;
}
*/
using PA = pair<long long, long long>;
vector<PA> gr[maxn];
long long dist[maxn];
priority_queue<PA, vector<PA>, greater<PA>> pq;
long long parents[maxn];

void dijkstra()
{
	pq.push({ 1, a });
	fill(dist, dist + maxn, INT_MAX / 2);
	dist[a] = 1;
	while (!pq.empty())
	{
		long long u = pq.top().second;
		long long d = pq.top().first;
		pq.pop();
		if (dist[u] != d)
			continue;
		for (auto p : gr[u])
		{
			long long v = p.first;
			long long w = p.second;
			if (dist[v] > dist[u] * w)
			{
				dist[v] = dist[u] * w;
				pq.push({ dist[v], v });
				parents[v] = u;
			}
		}
	}
}

void printPath()
{
	vector<long long> path;
	long long u = b;
	while (u != 0)
	{
		path.push_back(u);
		u = parents[u];
	}
	for (long long i = path.size() - 1; i >= 0; i--)
	{
		cout << path[i] << " ";
	}
	cout << endl;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;
	long long x, y, r;
	for (size_t i = 0; i < m; i++)
	{
		cin >> x >> y >> r;
		gr[x].push_back({ y, 1000 - r });
		gr[y].push_back({ x, 1000 - r });
	}
	cin >> a >> b;
	dijkstra();
	printPath();
	/*for (size_t i = 0; i < m; i++)
	{
		cin >> x >> y >> r;
		edges.push_back({ x, y, r });
	}
	cin >> a >> b;

	sort(edges.begin(), edges.end());
	kruskal();
	vector<long long> path;
	path.push_back(a);
	used[a] = true;
	dfs(a, path);
	for (size_t i = 0; i < path.size(); i++)
	{
		cout << path[i] << " ";
	}
	cout << endl;
	*/

	return 0;
}