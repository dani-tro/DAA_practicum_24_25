#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
#include <queue>

using namespace std;
int n, m, a, b;
const int maxn = 1e5 + 10;

struct edge
{
	int u, v, w;
	bool operator <(const edge& other) const
	{
		return w > other.w;
	}
};
vector<edge> edges;
vector<int> tree[maxn];

int comp[maxn];
int h[maxn];

int find(int u)
{
	if (comp[u] == u)
		return u;
	return comp[u] = find(comp[u]);
}

void Union(int u, int v)
{
	u = find(u);
	v = find(v);
	if (u == v)
		return;
	if (h[u] > h[v])
		swap(u, v);
	comp[u] = v;
	if (h[u] == h[v])
		++h[v];
}

void kruskal()
{
	for (size_t i = 1; i <= n; i++)
	{
		comp[i] = i;
	}
	int cnt = 0;
	int i = 0;
	while (cnt < n - 1)
	{
		edge edge = edges[i];
		if (find(edge.u) != find(edge.v))
		{
			tree[edge.u].push_back(edge.v);
			tree[edge.v].push_back(edge.u);
			Union(edge.u, edge.v);
			++cnt;
		}
		++i;
	}
}
bool used[maxn];

bool dfs(int curr, vector<int>& path)
{
	if (curr == b)
	{
		return true;
	}
	used[curr] = true;
	for (int v : tree[curr])
	{
		if (!used[v])
		{
			path.push_back(v);
			if (dfs(v, path))
				return true;
			path.pop_back();
		}
	}
	return false;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;
	int x, y, r;
	for (size_t i = 0; i < m; i++)
	{
		cin >> x >> y >> r;
		edges.push_back({ x, y, r });
	}
	cin >> a >> b;

	sort(edges.begin(), edges.end());
	kruskal();
	vector<int> path;
	path.push_back(a);
	used[a] = true;
	dfs(a, path);
	for (size_t i = 0; i < path.size(); i++)
	{
		cout << path[i] << " ";
	}
	cout << endl;
	return 0;
}