#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
#include <queue>

using namespace std;
int n, m, q;
const int maxn = 2 * 1e5 + 10;
vector<int> gr[maxn];
bool colors[maxn];
bool used[maxn];
int depression;
vector<pair<int, int>> extraEdges;

bool dfs(int u, bool color)
{
	colors[u] = color;
	used[u] = true;
	for (int v : gr[u])
	{
		if (used[v] && colors[v] == colors[u])
			return false;
		else if (!used[v])
			if (!dfs(v, !color))
				return false;
	}
	return true;
}

bool isBipartite()
{
	fill(colors, colors + maxn, 0);
	fill(used, used + maxn, 0);
	for (size_t i = 1; i <= n; i++)
	{
		if (!used[i])
		{
			if (!dfs(i, 0))
				return false;
		}
	}
	return true;
}

void addEdges(int count)
{
	for (size_t i = 0; i < count; i++)
	{
		int u = extraEdges[i].first;
		int v = extraEdges[i].second;
		gr[u].push_back(v);
		gr[v].push_back(u);
	}
}

void removeEdges(int count)
{
	for (int i = count - 1; i >= 0; i--)
	{
		int u = extraEdges[i].first;
		int v = extraEdges[i].second;
		gr[u].pop_back();
		gr[v].pop_back();
	}
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m >> q;
	int x, y;
	for (size_t i = 0; i < m; i++)
	{
		cin >> x >> y;
		if (x == y)
		{
			cout << -1 << endl;
			return 0;
		}
		else
		{
			gr[x].push_back(y);
			gr[y].push_back(x);
		}
	}
	if (!isBipartite())
	{
		cout << -1 << endl;
		return 0;
	}
	int depressionIndex = 0;
	for (size_t i = 1; i <= q; i++)
	{
		cin >> x >> y;
		if (depression != 0)
			continue;
		if (x == y)
		{
			depression = x;
			depressionIndex = i;
		}
		else
		{
			extraEdges.push_back({ x, y });
		}
	}
	/*int first = extraEdges[0].first;
	int second = extraEdges[0].second;
	gr[first].push_back(second);
	gr[second].push_back(first);
	*/
	int left = 1;
	int right;
	if (depression == 0)
		right = q;
	else
		right = depressionIndex;

	while (left < right)
	{
		int mid = (left + right) / 2;
		addEdges(mid);
		if (isBipartite())
		{
			left = mid + 1;
		}
		else
		{
			right = mid;
		}
		removeEdges(mid);
	}
	addEdges(left);
	if (!isBipartite())
	{
		cout << left;
		return 0;
	}
	int first = extraEdges[right - 1].first;
	int second = extraEdges[right - 1].second;
	gr[first].push_back(second);
	gr[second].push_back(first);
	if(!isBipartite())
	{
		cout << right;
	}
	else
		cout << -2 << endl;
	return 0;
}