#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
#include <queue>

using namespace std;
const int maxn = 1e5 + 10;
int n, q;
vector<int> gr[maxn];
int degrees[maxn];
int topoSorted[maxn];
int slavesCount[maxn];

void topoSort()
{
	for (size_t i = 1; i <= n; i++)
	{
		for (int v : gr[i]) 
		{
			++degrees[v];
		}
	}
	queue<int> q;
	for (size_t i = 1; i <= n; i++)
	{
		if (degrees[i] == 0)
		{
			q.push(i);
			break;
		}
	}
	int i = 1;
	while (!q.empty())
	{
		int u = q.front();
		q.pop();
		topoSorted[i] = u;
		for (int v : gr[u])
		{
			--degrees[v];
			if (degrees[v] == 0)
			{
				q.push(v);
			}
		}
		++i;
	}
}

void findSlaves()
{
	for (size_t i = n; i >= 1; i--)
	{
		for (int v : gr[topoSorted[i]])
		{
			slavesCount[topoSorted[i]] += slavesCount[v] + 1;
		}
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n; 
	int x, y;
	for (size_t i = 0; i < n - 1; i++)
	{
		cin >> x >> y;
		gr[x].push_back(y);
	}
	topoSort();
	findSlaves();
	cin >> q;
	for (size_t i = 0; i < q; i++)
	{
		cin >> x;
		cout << slavesCount[x] << "\n";
	}
	return 0;
}