#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
#include <queue>

using namespace std;
int n, m, q;
const int maxn = 2 * 1e5 + 10;
vector<int> gr[maxn];
bool colors[maxn];
bool used[maxn];
vector<int> depression;
bool dfs(int u, bool color)
{
	colors[u] = color;
	used[u] = true;
	for (int v : gr[u])
	{
		if (used[v] && colors[v] == colors[u])
			return false;
		else if (!used[v])
			if (!dfs(v, !color))
				return false;
	}
	return true;
}

bool isBipartite()
{
	fill(colors, colors + maxn, 0);
	fill(used, used + maxn, 0);
	for (int u : depression)
		used[u] = true;
	for (size_t i = 1; i <= n; i++)
	{
		if (!used[i])
		{
			if (!dfs(i, 0))
				return false;
		}
	}
	return true;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m >> q;
	int x, y;
	for (size_t i = 0; i < m; i++)
	{
		cin >> x >> y;
		gr[x].push_back(y);
		gr[y].push_back(x);
	}
	if (!isBipartite())
	{
		cout << -1 << endl;
		return 0;
	}
	for (size_t i = 1; i <= q; i++)
	{
		cin >> x >> y;
		if (x == y)
		{
			depression.push_back(x);
		}
		else
		{
			gr[x].push_back(y);
			gr[y].push_back(x);
		}
		if (!isBipartite())
		{
			cout << i << endl;
			return 0;
		}
	}
	cout << -2 << endl;
	return 0;
}