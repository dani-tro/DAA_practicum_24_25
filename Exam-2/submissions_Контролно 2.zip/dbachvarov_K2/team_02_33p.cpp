#include <iostream>
#include <algorithm>
#include <queue>
#include <cmath>
#include <vector>
using namespace std;

const int maxn = 2e5 + 10;
vector<int> gr[maxn];

int n, m, q, u, v;
bool isbipar = true;
int stat[maxn];

void isBipartite(int x)
{
    for (int y : gr[x])
    {
        if (stat[x] == stat[y]) 
        {
            isbipar = false;
            return;
        }
        if (stat[y] == 0)
        {
            stat[y] = 3 - stat[x];
            isBipartite(y);
        }
    }
    
    return;
}

int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr); 
    cout.tie(nullptr);

    cin >> n >> m >> q;

    for (int i = 1; i <= m; i++)
    {
        cin >> u >> v;
        if (u == v)
        {
            cout << -1 << endl;
            return 0;
        }
        gr[u].push_back(v);
        gr[v].push_back(u);
    }

    for (int i = 1; i <= n; i++)
    {
        if (stat[i] == 0)
        {
            stat[i] = 1;
            isBipartite(i);
        }
        if (!isbipar)
        {
            cout << -1 << endl;
            return 0;
        }
    }

    for (int i = 1; i <= q; i++)
    {
        for (int k = 0; k <= n; k++)
            stat[k] = 0;

        cin >> u >> v;
        if (u == v)
        {
            cout << i << endl;
            return 0;
        }

        gr[u].push_back(v);
        gr[v].push_back(u);

        for (int j = 1; j <= n; j++)
        {
            if (stat[i] == 0)
            {
                stat[i] = 1;
                isBipartite(i);
            }
            
            if (!isbipar)
            {
                cout << i << endl;
                return 0;
            }
        }
    }

    cout << -2 << endl;

    return 0;
}