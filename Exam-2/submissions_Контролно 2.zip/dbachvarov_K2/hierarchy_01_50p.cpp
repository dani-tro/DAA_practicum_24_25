#include <iostream>
#include <algorithm>
#include <queue>
#include <cmath>
#include <vector>
using namespace std;

const int maxn = 1e5+10;

int n, u, v, q, m, cnt = 0;
vector<int> gr[maxn];

void dfs(int x)
{
    for (int y : gr[x])
    {
        cnt++;
        dfs(y);
    }
}

int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr); 
    cout.tie(nullptr);

    cin >> n;

    for (int i = 1; i < n; i++)
    {
        cin >> u >> v;
        gr[u].push_back(v);
    }

    cin >> q;

    for (int i = 1; i <= q; i++)
    {
        cin >> m;
        cnt = 0;
        dfs(m);

        cout << cnt << endl;
    }

    return 0;
}