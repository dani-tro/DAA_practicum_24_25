#include <iostream>
#include <algorithm>
#include <queue>
#include <cmath>
#include <vector>
using namespace std;

#define PA pair<int, int>

const int maxn = 1e5+10;

struct edge
{
    int a;
    int b;
    int c;

    bool operator<(const edge& other) const
    {
        return c < other.c;
    }
};

int n, m, a, b, c, x, y, result = 0;
int d[maxn], par[maxn], path[maxn];

vector<edge> edges, ans;

vector<int> gr[maxn];
bool used[maxn];

int find(int a)
{
    if (par[a] == a) return a;
    return par[a] = find(par[a]);
}

void uni(int a, int b)
{
    a = find(a);
    b = find(b);
    if (a == b) return;

    if (d[a] < d[b]) swap(a, b);
    par[b] = a;
    if (d[a] == d[b]) d[a]++;
    return;
}

void Kruskal()
{
    sort(edges.begin(), edges.end());

    for (auto e : edges)
    {
        if (find(e.a) == find(e.b)) continue;

        ans.push_back(e);
        uni(e.a, e.b);
    }
}

void dfs(int k)
{
    used[k] = true;
    for (int l : gr[k])
    {
        if (!used[l])
        {   path[l] = k;
            dfs(l); }
    }

    return;
}

int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr); 
    cout.tie(nullptr);

    cin >> n >> m;
    for (int i = 0; i <= n; i++)
    {
        d[i] = 0;
        par[i] = i;
    }

    for (int i = 1; i <= m; i++)
    {
        cin >> a >> b >> c;
        edges.push_back({a, b, -c});
    }

    cin >> x >> y;

    Kruskal();

    for (auto r : ans)
    {
        gr[r.a].push_back(r.b);
        gr[r.b].push_back(r.a);
    }

    path[x] = 0; 
    dfs(x);

    vector<int> resres;
    resres.push_back(y);
    int z = path[y];
    resres.push_back(z);

    while (z != x)
    {
        z = path[z];
        resres.push_back(z);
    }

    for (int t = resres.size() - 1; t >= 0; t--)
    {
        cout << resres[t] << " ";
    }
}