#include <iostream>
#include <algorithm>
#include <queue>
#include <cmath>
#include <vector>
using namespace std;

const int maxn = 1e5+10;

int n, u, v, q, m, cnt = 0;
int d[maxn];
bool known[maxn];
vector<int> gr[maxn];

void dfs(int x)
{
    for (int y : gr[x])
    {
        if (known[y])
        {
            cnt += d[y];
            cnt++;
        }
        else
        {
            cnt++;
            dfs(y);
        }
    }

    return;
}

int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr); 
    cout.tie(nullptr);

    cin >> n;

    for (int i = 1; i < n; i++)
    {
        cin >> u >> v;
        gr[u].push_back(v);
    }

    cin >> q;

    for (int i = 1; i <= q; i++)
    {
        cin >> m;
        cnt = 0;
        dfs(m);
        d[m] = cnt;
        known[m] = true;

        cout << cnt << "\n";
    }

    return 0;
}