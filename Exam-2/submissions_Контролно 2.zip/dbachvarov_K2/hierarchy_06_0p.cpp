#include <iostream>
#include <algorithm>
#include <queue>
#include <cmath>
#include <vector>
using namespace std;

const int maxn = 1e5+10;

int n, u, v, q, m, cnt = 0;
int d[maxn];
bool known[maxn];
vector<int> gr[maxn];

int d[maxn], par[maxn], sz[maxn];

int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr); 
    cout.tie(nullptr);

    cin >> n;

    for (int i = 0; i <= n; i++)
        sz[i] = 0;

    for (int i = 1; i < n; i++)
    {
        cin >> u >> v;
        gr[u].push_back(v);
        sz[u] += sz[v] + 1;
    }

    cin >> q;

    for (int i = 1; i <= q; i++)
    {
        cin >> m;

        cout << sz[m] << "\n";
    }

    return 0;
}