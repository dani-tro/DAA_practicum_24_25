#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> g[40000];
//bool vis[100];
int countt;
//kfjdsfhskdjfhsdjf


int main()
{
    int n;
    cin >> n;

    int m;
    cin >> m;

    int u, v;

    for (int i = 1; i <= m; i++)
    {
        cin >> u >> v;
        g[u].push_back(v);
        //g[v].push_back(u);
    }
    int a, b;
    cin >> a, b;
    cout << a << " " << b;
    
}