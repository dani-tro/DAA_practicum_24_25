#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector <long> g[400000];
//bool vis[100];
long countt;

void FindChildren(long a)
{
    for (long i = 0; i < g[a].size(); i++)
    {
        long c = g[a][i];
        countt++;
        FindChildren(c);
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    long n;
    cin >> n;

    long m = n-1;

    long u, v;

    for (long i = 1; i <= m; i++)
    {
        cin >> u >> v;
        g[u].push_back(v);
        //g[v].push_back(u);
    }

    /*for (long i = 0; i < n; i++)
    {
        sort(g[i].begin(), g[i].end());
    }*/

    long q;
    cin >> q;
    long a;
    for (long i = 0; i < q; i++)
    {
        cin >> a;
        countt = 0;
        FindChildren(a);
        cout << countt<<"\n";
    }
}