
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector <pair<int,int>> g[40000];
//bool vis[100];
int countt;

void FindChildren(int a)
{
    
}

int main()
{
    int n;
    cin >> n;

    int m;
    cin >> m;

    int u, v, s;

    for (int i = 1; i <= m; i++)
    {
        cin >> u >> v >> s;
        g[u].push_back({v,s});
        g[v].push_back({u,s});
    }
    
    for (int i = 0; i < n; i++)
    {
        sort(g[i].begin(), g[i].end());
    }

    int a, b;
    cin >> a, b;
    cout << a << " " << b;
    
}