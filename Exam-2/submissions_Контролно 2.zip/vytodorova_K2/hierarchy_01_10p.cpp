#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector <int> g[100];
bool vis[100];
int countt;

void FindChildren(int a)
{
    for (int i = 0; i < g[a].size(); i++)
    {
        int c = g[a][i];
        countt++;
        FindChildren(c);
    }
}

int main()
{
    int n;
    cin >> n;

    int m = n-1;

    int u, v;

    for (int i = 1; i <= m; i++)
    {
        cin >> u >> v;
        g[u].push_back(v);
        //g[v].push_back(u);
    }

    for (int i = 0; i < n; i++)
    {
        sort(g[i].begin(), g[i].end());
    }

    int q;
    cin >> q;
    int a;
    for (int i = 0; i < q; i++)
    {
        cin >> a;
        countt = 0;
        FindChildren(a);
        cout << countt<<"\n";
    }
}