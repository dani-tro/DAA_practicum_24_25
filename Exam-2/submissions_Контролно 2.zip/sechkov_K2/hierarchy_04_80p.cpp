#include <iostream>
#include <vector>
using namespace std;

const int maxN = 1e5 + 10;

vector<int> g[maxN];
int in[maxN];
int sz[maxN];

void dfs(int s) {
	if (g[s].size() == 0) {
		sz[s] = 0;
		return;
	}

	for (auto u : g[s]) {
		dfs(u);
		sz[s] += sz[u] + 1;
	}
}

int main() {

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n;

	cin >> n;

	for (int i = 1; i <= n; i++) {
		in[i] = 0;
	}

	for (int i = 1; i < n; i++) {
		int u, v;
		cin >> u >> v;
		g[u].push_back(v);
		in[v]++;
	}

	int s = 0;

	for (int i = 1; i <= n; i++) {
		if (in[i] == 0) {
			s = i;
			break;
		}
	}

	dfs(s);

	int q;
	cin >> q;

	vector<int> ans;

	for (int i = 0; i < q; i++) {
		int u;
		cin >> u;
		ans.push_back(sz[u]);
	}

	for (auto i : ans) {
		cout << i << endl;
	}

	return 0;
}