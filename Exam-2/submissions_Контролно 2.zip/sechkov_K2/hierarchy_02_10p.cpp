#include <iostream>
#include <vector>
using namespace std;

const int maxN = 1e5 + 10;

int par[maxN];
int sz[maxN];

int  find(int u) {
	if (par[u] == u) return u;
	return par[u] = find(par[u]);
}

/***
void connect(int u, int v) {
	int ru = find(u);
	v = find(v);

	if (u == v) return;

	if (u > v) {
		par[v] = par[u];
		sz[u] += sz[v];
	}
	else {
		par[u] = par[v];
		sz[v] += sz[u];
	}
}
***/

void connect(int u, int v) {
	sz[u] += sz[v];
}

int main() {

	int n;

	cin >> n;

	for (int i = 1; i <= n; i++) {
		par[i] = i;
		sz[i] = 1;
	}

	for (int i = 1; i < n; i++) {
		int u, v;
		cin >> u >> v;
		connect(u, v);
	}

	int q;
	cin >> q;

	vector<int> ans;

	for (int i = 0; i < q; i++) {
		int u;
		cin >> u;
		ans.push_back(sz[u] - 1);
	}

	for (int i = 0; i < q; i++) {
		cout << ans[i] << endl;
	}

	return 0;
}