#include <bits/stdc++.h>
using namespace std;

const int maxN = 1e5 + 10;

vector<pair<int, int>> g[maxN];
vector<int> path;
bool vis[maxN];

bool cmp(pair<int, int>& a, pair<int, int>& b) {
	return a.second > b.second;
}

bool dfs(int s, int t) {
	if (s == t) {
		path.push_back(s);
		return true;
	}

	vis[s] = true;

	for (auto u : g[s]) {
		if (dfs(u.first, t)) {
			path.push_back(s);
		}
	}

	vis[s] = false;

	return false;
}

int main() {

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n, m;

	cin >> n >> m;

	for (int i = 0; i < m; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		g[u].push_back({v, w});
		g[v].push_back({u, w});

	}

	for (int i = 1; i <= n; i++) {
		sort(g[i].begin(), g[i].begin() + g[i].size());
	}

	int s, t;
	cin >> s >> t;

	for (int i = 1; i <= n; i++) {
		vis[i] = false;
	}

	dfs(s, t);

	for (int i = path.size() - 1; i > 0; i--) {
		cout << path[i] << " ";
	}

	cout << t;

	return 0;
}