#include <iostream>
#include <vector>
#include <queue>
using namespace std;

const int maxN = 1e5 + 10;

vector<pair<int, int>> g[maxN];
vector<int> path;
int dist[maxN];

void dijkstra(int s) {
	priority_queue<pair<int, int>> q;
	q.push({0, s});

	while (!q.empty()) {
		int u = q.top().second;
		if (dist[u] != q.top().first) {
			q.pop();
			continue;
		}
		q.pop();

		for (auto v : g[u]) {
			if (dist[v.first] < v.second + dist[u]) {
				dist[v.first] = v.second + dist[u];
				q.push({dist[v.first], v.first});
			}
		}
	}
}

bool dfs(int s, int t) {
	if (s == t) {
		return true;
	}

	for (auto u : g[t]) {
		if (dist[u.first] + u.second == dist[t]) {
			if (dfs(s, u.first)) {
				path.push_back(u.first);
			}
		}
	}

	return false;
}

int main() {

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n, m;

	cin >> n >> m;

	for (int i = 1; i <= n; i++) {
		dist[i] == -1;
	}

	for (int i = 0; i < m; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		g[u].push_back({v, w});
		g[v].push_back({u, w});

	}

	int s, t;
	cin >> s >> t;

	dist[s] = 0;

	dijkstra(s);

	path.push_back(s);

	dfs(s, t);

	for (auto i : path) {
		cout << i << " ";
	}

	cout << t;

	return 0;
}