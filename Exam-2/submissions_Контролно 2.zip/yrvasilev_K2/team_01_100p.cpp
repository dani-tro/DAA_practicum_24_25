#include<bits/stdc++.h>
#define MAX 200005
using namespace std;
int m, n, ans, counter=0, l, r, v1, v2, q, fl[MAX], day, color[MAX];
vector <pair <int,int>> v[MAX];
bool ok;
void dfs(int u, int col){
    int to;
    color[u]=col;
    fl[u]=day;
    //cout<<"day="<<day<<" u="<<u<<" col"<<color[u]<<endl;
    for(pair<int, int> p : v[u]){
        if(p.second>day)break;
        to=p.first;
        if(fl[to]!=day) dfs(to,-col);
        else if (color[to]==color[u]) ok=false;
    }
    //cout<<"u="<<u<<" "<<ans[u]<<" ct="<<counter<<endl;
}
bool bipartite(){
    ok=true;
    for(int i=1;i<=n;i++){
        if(fl[i]!=day){
            dfs(i,1);
        }
        if(ok==false) return false;
    }
    return ok;
}
void binary(){
    ans=-1;
    l=0;
    r=q;
    fill(fl+1,fl+MAX,-1);
    while(l<=r){
        day=(l+r)/2;
        //cout<<"l="<<l<<" r="<<r<<" day="<<day<<" "<<ans<<endl;
        if(bipartite()) {
            //cout<<"it is\n";
            ans=day;
            l=day+1;
        }
        else r=day-1;
    }
    if(ans==-1){cout<<-1<<endl; return;}
    if(ans==q) {cout<<-2<<endl; return;}
    cout<<ans+1<<endl;
}
int main(){
    int i,j;
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    //a[n]=1e15;
    cin>>n>>m>>q;
    for(i=1;i<=m;i++) {
        cin>>v1>>v2;
        v[v1].push_back({v2,0});
        v[v2].push_back({v1,0});
    }
    for(i=1;i<=q;i++){
        cin>>v1>>v2;
        v[v1].push_back({v2,i});
        v[v2].push_back({v1,i});
    }
    binary();
    return 0;
}

/*
3 3 0
1 2
1 3
2 3

3 0 3
1 2
1 3
2 3

*/