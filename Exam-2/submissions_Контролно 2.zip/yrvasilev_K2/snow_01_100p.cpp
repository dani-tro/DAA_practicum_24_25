#include<bits/stdc++.h>
#define MAX 100005
using namespace std;
int m, n, par[MAX], counter=0, r, v1, v2, A, B,w, u ;
bool fl[MAX];
vector <int> ans;
vector< pair<int,int> > v[MAX];
pair<int,int> t;
pair <double, pair<int,int>> p;
priority_queue <pair <double, pair<int,int>> > q;
double dist, d;
int main(){
    int i,j, to;
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    //a[n]=1e15;
    cin>>n>>m;
    for(i=1;i<=m;i++) {
        cin>>v1>>v2>>w;
        v[v1].push_back({v2,w});
        v[v2].push_back({v1,w});
    }
    cin>>A>>B;
    q.push({1.0,{B,-1}});
    while(!q.empty()){
        p=q.top(); q.pop();
        u=p.second.first;
        if(fl[u]) continue;
        fl[u]=true;
        par[u]=p.second.second;
        d=p.first;
        //cout<<"u="<<u<<" par="<<par[u]<<" d="<<d<< endl;
        for(pair<int,int> t : v[u]){
            to=t.first;
            if(fl[to]) continue;
            //dist=d+ log2(1.0*t.second);
            dist=d*t.second/1000;
            q.push({dist,{to,u}});
        }
    }
    int cr=A;
    while(cr!=-1) {
        cout<<cr<<" ";
        cr=par[cr];
    }
    cout<<endl;
    return 0;
}

/*
6 9
1 2 200
1 3 100
1 6 250
2 3 700
3 6 200
3 4 100
4 6 900
4 5 800
5 6 600
1 4

*/