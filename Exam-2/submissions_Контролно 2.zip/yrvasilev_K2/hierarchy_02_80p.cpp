#include<bits/stdc++.h>
#define MAX 1000005
using namespace std;
long long m, n, ans[MAX], counter=0, r, v1, v2, q;
bool fl[MAX], root[MAX];
vector<int> v[MAX];
void dfs(long long u){
    fl[u]=true;
    ans[u]=++counter;
    for(int to : v[u]){
        if(!fl[to]) dfs(to);
    }
    //cout<<"u="<<u<<" "<<ans[u]<<" ct="<<counter<<endl;
    ans[u]=counter-ans[u];
}
int main(){
    int i,j;
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    //a[n]=1e15;
    cin>>n;
    for(i=1;i<n;i++) {
        cin>>v1>>v2;
        root[v2]=true;
        v[v1].push_back(v2);
    }
    for(i=1;i<=n;i++){
        if(!root[i]){r=i; break; }
    }
    //cout<<"root="<<r<<endl;
    dfs(r);
    cin>>q;

    //sort(a,a+br);
    // for(i=0;i<br;i++){
    //     cout<<-a[i].first<<" "<<a[i].second<<endl;
    // }
    for(i=0;i<q;i++){
        cin>>v1;
        cout<<ans[v1]<<endl;
    }
    //cout<<ans<<endl;
    return 0;
}

/*
5 3
9 9
4 7
0 2

8 3
1 6
10 15
7 10

5 3
1 6
10 15
7 10
*/