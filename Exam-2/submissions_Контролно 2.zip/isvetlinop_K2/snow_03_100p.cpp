#include <bits/stdc++.h>

const int MAXN = 1e5 + 10;

std::vector<std::pair<int, double> > adj[MAXN];

double prob[MAXN];
int par[MAXN];

int main()
{
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);

    int n, m;
    std::cin >> n >> m;
    for(int i = 0; i < m; ++ i)
    {
        int u, v, p;
        std::cin >> u >> v >> p;
        adj[u].push_back({v, p / 1000.0});
        adj[v].push_back({u, p / 1000.0});
    }
    int a, b;
    std::cin >> a >> b;
    prob[a] = 1;

    std::set<std::pair<double, int> > q;
    q.insert({-1, a});
    while(!q.empty())
    {
        int v = q.begin()->second;
        double p = -(q.begin()->first);
        q.erase(q.begin());

        if(p < prob[v])
        {
            continue;
        }

        for(auto u : adj[v])
        {
            double new_prob = prob[v] * u.second;
            if(prob[u.first] < new_prob)
            {
                prob[u.first] = new_prob;
                q.insert({-new_prob, u.first});
                par[u.first] = v;
            }
        }
    }

    /*for(int i = 1; i <= n; ++ i)
    {
        std::cout << par[i] << ' ';
    }
    std::cout << '\n';*/

    std::vector<int> ans;
    ans.push_back(b);
    int sz = 1;
    while(ans[sz - 1] != a)
    {
        ans.push_back(par[ans[sz - 1]]);
        ++ sz;
    }

    while(sz)
    {
        std::cout << ans[--sz] << ' ';
    }
    std::cout << '\n';

    return 0;
}
