#include <bits/stdc++.h>

const int MAXN = 1e5 + 10;

std::vector<int> children[MAXN];

int children_cnt[MAXN];

int count_children(int v)
{
    if(children_cnt[v] != -1)
    {
        return children_cnt[v];
    }

    children_cnt[v] = 0;
    for(auto u : children[v])
    {
        children_cnt[v] += count_children(u) + 1;
    }

    return children_cnt[v];
}

int main()
{
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);

    memset(children_cnt, -1, sizeof(children_cnt));

    int n;
    std::cin >> n;

    for(int i = 1; i < n; ++ i)
    {
        int u, v;
        std::cin >> u >> v;
        children[u].push_back(v);
    }

    int m;
    std::cin >> m;
    while(m --)
    {
        int v;
        std::cin >> v;
        std::cout << count_children(v) << '\n';
    }


    return 0;
}
