#include <bits/stdc++.h>

const int MAXN = 2e5 + 10;

std::vector<int> adj[MAXN];

int col[MAXN], comp_size[MAXN];
int p[MAXN], col_p[2 * MAXN];
int cols;
bool used[MAXN];


bool bfs(int x)
{
    ++ cols;
    col_p[cols * 2] = cols * 2;
    col_p[cols * 2 + 1] = cols * 2 + 1;
    int sz = 0;
    std::queue<int> q;
    q.push(x);
    col[x]=cols*2;
    while(!q.empty())
    {
        ++ sz;
        int v = q.front();
        q.pop();
        used[v] = true;
        p[v] = x;
        for(int u : adj[v])
        {
            if(col[u] == 0)
            {
                col[u]=col[v] ^ 1;
            }
            if(col[u] == col[v])
            {
                return false;
            }
            if(!used[u])
            {
                q.push(u);
            }
        }
    }
    comp_size[x] = sz;
    return true;
}

int find(int x)
{
    if(p[x] == x)
    {
        return p[x];
    }
    p[x] = find(p[x]);
    return p[x];
}

int find_col(int x)
{
    if(col_p[x] == x)
    {
        return col_p[x];
    }
    col_p[x] = find_col(p[x]);
    return col_p[x];
}

bool uni(int x, int y)
{
    int px = find(x), py = find(y);
    if(px == py)
    {
        if(find_col(col[x]) == find_col(col[y]))
        {
            return false;
        }
        return true;
    }
    std::cout << x << ' ' << y << '\t' << px << ' ' << py << '\t' << col[x] << ' ' << col[y] << '\n';
    if(comp_size[px] > comp_size[py])
    {
        p[py] = px;
        col_p[find_col(col[y])] = find_col(col[x]) ^ 1;
        col_p[find_col(col[y]) ^ 1] = find_col(col[px]);
        comp_size[px] += comp_size[py];
    }
    else
    {
        p[px] = py;
        col_p[find_col(col[x])] = find_col(col[y]) ^ 1;
        col_p[find_col(col[x]) ^ 1] = find_col(col[py]);
        comp_size[py] += comp_size[px];
    }
    return true;
}

int main()
{

    /*std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);
*/
    int n, m, q;
    std::cin >> n >> m >> q;
    for(int i = 0; i < m; ++ i)
    {
        int u, v;
        std::cin >> u >> v;
        if(u == v)
        {
            std::cout << "-1\n";
            return 0;
        }
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    for(int i = 1; i <= n; ++ i)
    {
        if(!used[i])
        {
            if(!bfs(i))
            {
                std::cout << -1 << '\n';
                return 0;
            }
        }
    }

    for(int i = 1; i <= q; ++ i)
    {
        int u, v;
        std::cin >> u >> v;
        if(u == v)
        {
            std::cout << i << '\n';
            return 0;
        }
        if(!uni(u, v))
        {
            std::cout << i << '\n';
            return 0;
        }
    }

    std::cout << "-2\n";

    return 0;
}
