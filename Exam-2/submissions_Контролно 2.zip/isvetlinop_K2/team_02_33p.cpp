#include <bits/stdc++.h>

const int MAXN = 2e5 + 10;

std::vector<int> adj[MAXN];

int col[MAXN], comp_size[MAXN];
int p[MAXN], col_p[MAXN];
int cols;
bool used[MAXN];


bool bfs(int x)
{
    ++ cols;
    std::queue<int> q;
    q.push(x);
    col[x]=cols*2;
    while(!q.empty())
    {
        int v = q.front();
        q.pop();
        used[v] = true;
        p[v] = x;
        for(int u : adj[v])
        {
            if(col[u] == 0)
            {
                col[u]=col[v] ^ 1;
            }
            if(col[u] == col[v])
            {
                return false;
            }
            if(!used[u])
            {
                q.push(u);
            }
        }
    }

    return true;
}

int main()
{
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);

    int n, m, q;
    std::cin >> n >> m >> q;
    for(int i = 0; i < m; ++ i)
    {
        int u, v;
        std::cin >> u >> v;
        if(u == v)
        {
            std::cout << "-1\n";
            return 0;
        }
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    for(int i = 1; i <= n; ++ i)
    {
        if(!used[i])
        {
            if(!bfs(i))
            {
                std::cout << -1 << '\n';
                return 0;
            }
        }
    }

    std::cout << "-2\n";

    return 0;
}
