#include <vector>
#include <algorithm>
#include <stack>
#include <utility>
#include <queue>
#include <iostream>

const int MAXN = 2e5 + 100;
std::vector<int> graph[MAXN];
std::vector<std::pair<int, int>> newEdges;
int visited[MAXN];
int n, m, q;

bool isBipartite(int u) {
    for(int v : graph[u]) {
        if(visited[v] == 0) {
            visited[v] = visited[u] == 1 ? 2 : 1;
            if(!isBipartite(v)) return false;
        } else {
            if(visited[u] == visited[v]) return false;
        }
    }
    return true;
}

bool check(int days) {
    for(int i = 0; i < days; ++i) {
        if(visited[newEdges[i].first] == visited[newEdges[i].second]) return false;
    }
    return true;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m >> q;

    for(int i = 0; i < m; ++i) {
        int ui, vi;
        std::cin >> ui >> vi;
        graph[ui].push_back(vi);
        graph[vi].push_back(ui);
    }

    for(int i = 0; i < q; ++i) {
        int uj, vj;
        std::cin >> uj >> vj;
        newEdges.push_back({uj, vj});
    }

    for(int i = 1; i <= n; ++i) {
        if(visited[i] == 0 && !isBipartite(i)) {
            std::cout << -1 << std::endl;
            return 0;
        }
    }

    if(q == 0) {
        std::cout << -2 << std::endl;
        return 0;
    }

    // int start = 0, end = q;

    // while(start <= end) {
    //     int mid = (start + end) / 2;

    //     if(!check(mid)) {
    //         start = mid + 1;
    //     } else {
    //         end = mid - 1;
    //     }
    // }

    // if(end == q + 1) {
    //     std::cout << -2 << std::endl;
    // } else {
    //     std::cout << end << std::endl;
    // }

    for(int i = 0; i < q; ++i) {
        std::pair<int, int> edge = newEdges[i];
        graph[edge.first].push_back(edge.second);
        graph[edge.second].push_back(edge.first);

        std::fill(visited, visited + n + 1, 0);

        for(int j = 1; j <= n; ++j) {
            if(visited[j] == 0 && !isBipartite(j)) {
                std::cout << i + 1 << std::endl;
                return 0;
            }
        }
    }
    std::cout << -2 << std::endl;
}