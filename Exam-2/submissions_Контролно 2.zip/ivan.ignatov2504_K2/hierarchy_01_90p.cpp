#include <vector>
#include <algorithm>
#include <stack>
#include <utility>
#include <queue>
#include <iostream>

const int MAXN = 1e5 + 100;

std::vector<int> graph[MAXN];
int results[MAXN];
bool visited[MAXN];
int currCounter;
int inDeg[MAXN];

int dfs(int u) {
    int counter = 0;
    for(int v : graph[u]) {
        counter += dfs(v) + 1; 
    }
    results[u] = counter;
    return counter;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    
    int n;
    std::cin >> n;

    for(int i = 0; i < n - 1; ++i) {
        int u, v;
        std::cin >> u >> v;
        graph[u].push_back(v);
        ++inDeg[v];
    }

    int boss = 1;

    for(int i = 1; i <= n; ++i) {
        if(inDeg[i] == 0) {
            boss = i;
            break;
        }
    }

    dfs(boss);

    int q;
    std::cin >> q;

    for(int i = 0; i < q; ++i) {
        int m;
        std::cin >> m;
        std::cout << results[m] << std::endl;
    }
}