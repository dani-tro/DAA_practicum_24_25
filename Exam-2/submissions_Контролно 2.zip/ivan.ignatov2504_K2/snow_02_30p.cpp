#include <vector>
#include <algorithm>
#include <stack>
#include <utility>
#include <queue>
#include <iostream>

struct Edge {
    int a, b;
    long long w;

    Edge() = default;
    Edge(int a, int b, long long w) : a(a), b(b), w(w) {}

    friend bool operator<(const Edge& first, const Edge& second) {
        return first.w > second.w;
    }
};

const int MAXN = 1e5 + 100;
int par[MAXN], sz[MAXN];
int n, m;
std::vector<Edge> edges;
std::vector<std::pair<int, long long>> graph[MAXN];
std::stack<int> path;
bool visited[MAXN];

int find(int x) {
    if (par[x] == x) return x;
    return par[x] = find(par[x]);
}

void unite(int a, int b) {
    int ra = find(a);
    int rb = find(b);

    if(ra == rb) return;

    if(sz[ra] > sz[rb]) {
        par[rb] = ra;
        sz[ra] += sz[rb];
    } else {
        par[ra] = rb;
        sz[rb] += sz[ra];
    }
}

void kruskal() {
    std::sort(edges.begin(), edges.end());
    for(int i = 1; i <= n; ++i) {
        par[i] = i;
        sz[i] = 1;
    }

    for(Edge& edge : edges) {
        if(find(edge.a) == find(edge.b)) continue;

        unite(edge.a, edge.b);

        graph[edge.a].push_back({edge.b, edge.w});
        graph[edge.b].push_back({edge.a, edge.w});
    }
}

bool dfs(int u, int v) {
    if(u == v) return true;

    for(std::pair<int, long long>& edge : graph[u]) {
        if(visited[edge.first]) continue;
        visited[edge.first] = true;
        path.push(edge.first);
        if(!dfs(edge.first, v)) {
            path.pop();
        } else {
            return true;
        }
    }
    return false;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m;

    for(int i = 0; i < m; ++i) {
        int u, v;
        long long w;
        std::cin >> u >> v >> w;
        edges.push_back({u, v, w});
        edges.push_back({v, u, w});
    }

    int a, b;
    std::cin >> a >> b;

    kruskal();

    path.push(a);
    dfs(a, b);

    std::vector<int> res;

    while(!path.empty()) {
        res.push_back(path.top());
        // std::cout << path.top() << ' ';
        path.pop();
    }

    // res.push_back(a);
    std::reverse(res.begin(), res.end());

    for(int i = 0; i < res.size(); ++i) {
        std::cout << res[i] << ' ';
    }
    std::cout << std::endl;
}