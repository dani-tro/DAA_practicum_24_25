#include <vector>
#include <algorithm>
#include <stack>
#include <utility>
#include <queue>
#include <iostream>

const int MAXN = 2e5 + 100;
std::vector<int> graph[MAXN];
int visited[MAXN];

bool isBipartite(int u) {
    for(int v : graph[u]) {
        if(visited[v] == 0) {
            visited[v] = visited[u] == 1 ? 2 : 1;
            if(!isBipartite(v)) return false;
        } else {
            if(visited[u] == visited[v]) return false;
        }
    }
    return true;
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    int n, m, q;
    std::cin >> n >> m >> q;

    for(int i = 0; i < m; ++i) {
        int ui, vi;
        std::cin >> ui >> vi;
        graph[ui].push_back(vi);
        graph[vi].push_back(ui);
    }

    for(int i = 0; i < q; ++i) {
        int uj, vj;
        std::cin >> uj >> vj;
    }

    for(int i = 1; i <= n; ++i) {
        if(visited[i] == 0 && !isBipartite(i)) {
            std::cout << -1 << std::endl;
            return 0;
        }
    }

    std::cout << -2 << std::endl;
}