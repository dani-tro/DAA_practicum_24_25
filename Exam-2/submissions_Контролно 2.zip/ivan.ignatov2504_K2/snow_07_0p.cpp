#include <vector>
#include <algorithm>
#include <stack>
#include <utility>
#include <queue>
#include <iostream>

const int MAXN = 1e5 + 100;

std::vector<std::pair<int, long long>> graph[MAXN];
long long dist[MAXN];
int par[MAXN];
int n, m;

void dijkstra(int start) {
    std::priority_queue<std::pair<long long, int>> queue;
    queue.push({-1, start});
    // std::fill(dist, dist + n, LLONG_MAX);
    for(int i = 1; i <= n; ++i) {
        dist[i] = 1e4;
    }
    dist[start] = 1;
    par[start] = -1;

    while(!queue.empty()) {
        std::pair<long long, int> curr = queue.top();
        int u = curr.second;
        queue.pop();
        if(dist[u] != -curr.first) continue;

        for(std::pair<int, long long> edge : graph[u]) {
            int v = edge.first;
            long long w = edge.second;
            long long test1 = dist[u];
            long long test2 = dist[v];
            if(dist[v] > dist[u] * w) {
                dist[v] = dist[u] * w;
                par[v] = u;
                queue.push({-dist[v], v});
            }
        }
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    
    std::cin >> n >> m;

    for(int i = 0; i < m; ++i) {
        int u, v;
        long long w;
        std::cin >> u >> v >> w;
        graph[u].push_back({v, 1000 - w});
        graph[v].push_back({u, 1000 - w});
    }

    int a, b;
    std::cin >> a >> b;

    dijkstra(a);

    int curr = b;
    std::vector<int> res;

    while(curr != -1) {
        res.push_back(curr);
        curr = par[curr];
    }

    std::reverse(res.begin(), res.end());

    for(int i : res) {
        std::cout << i << ' ';
    }
}