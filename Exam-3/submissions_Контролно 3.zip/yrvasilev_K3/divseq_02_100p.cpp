#include<bits/stdc++.h>
using namespace std;
int a[1005][1005],n,m, t, k;
int main(){
    int i,j;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    a[0][0]=1;
    cin>>n>>k;
    for(i=1;i<=n;i++){
        cin>>t;
        for(j=0;j<k;j++){
            if(a[i-1][j]!=0) a[i][(j+t)%k]=max(a[i-1][(j+t)%k],a[i-1][j]+1);
            else a[i][(j+t)%k]=a[i-1][(j+t)%k];
        }
        //for(j=0;j<k;j++) cout<<a[i][j]<<" "; cout<<endl;
    }


    cout<<a[n][0]-1<<endl;
    return 0;
}
