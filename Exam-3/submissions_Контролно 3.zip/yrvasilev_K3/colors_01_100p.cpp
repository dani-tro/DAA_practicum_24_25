#include<bits/stdc++.h>
#define MOD 1000000007
using namespace std;
long long n,m, t, k, ans=0, cr, a[3005][3005],c, sum;
int main(){
    int i,j;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    cin>>n>>k;
    sum=1;
    for(i=1;i<=n;i++){
        cin>>c;
        if(c!=0){
            a[i][c]=(MOD+sum-a[i-1][c])%MOD;
            /*for(j=1;j<=k;j++){
                cout<<a[i][j]<<" ";
            } cout<<endl;
            cout<<sum<<endl;
            */
            sum=a[i][c];
            continue;
        }
        cr=0;
        for(j=1;j<=k;j++){
            a[i][j]=(MOD+sum-a[i-1][j])%MOD;
            cr=(cr+a[i][j])%MOD;
            //cout<<a[i][j]<<" ";
        }
        //cout<<endl;
        //cout<<sum<<endl;
        sum=cr;
    }

    cout<<sum<<endl;
    return 0;
}
/*
3 5
4 0 4

4 3
2 0 1 0

*/
