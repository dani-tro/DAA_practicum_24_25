#include<bits/stdc++.h>
using namespace std;
int n,m, t, k, ans=0, cr;
bool a[3005][3005];
struct tel{
    int ul,ur,dl,dr;
};
tel b[3005][3005];
char c;
int main(){
    int i,j;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    cin>>n>>m; cin.ignore();
    for(i=1;i<=n;i++){
        for(j=1;j<=m;j++){
            cin>>c; a[i][j]=c-'0';
            if(a[i][j]) b[i][j].ul=b[i-1][j-1].ul+1;
            else b[i][j].ul=0;
            if(a[i][j]) b[i][j].ur=b[i-1][j+1].ur+1;
            else b[i][j].ur=0;
        }
        cin.ignore();
    }

    for(i=n;i>=1;i--){
        for(j=m;j>=1;j--){
            if(a[i][j]) b[i][j].dl=b[i+1][j-1].dl+1;
            else b[i][j].dl=0;
            if(a[i][j]) b[i][j].dr=b[i+1][j+1].dr+1;
            else b[i][j].dr=0;
            cr=min(min(b[i][j].ul, b[i][j].ur), min(b[i][j].dl, b[i][j].dr));
            ans=max(ans,2*cr-1);
        }
    }


    cout<<ans<<endl;
    return 0;
}
/*
10 8
10111111
11111111
10111111
11111110
01111110
11111110
11111111
10110111
11111111
11111111
*/
