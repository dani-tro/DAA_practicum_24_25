#include <iostream>
using namespace std;

const int MAXN = 3001;
bool a[MAXN][MAXN];
int leftt[MAXN][MAXN];
int rightt[MAXN][MAXN];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);  cout.tie(NULL);
    int n, m;
    cin>>n>>m;
    char ch;
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++) {
            cin>>ch;
            a[i][j] = ch - '0';
            if(a[i][j]) leftt[i][j] = leftt[i-1][j-1] + 1;
            else leftt[i][j] = 0;
        }
    }

    for(int i=1;i<=n;i++) {
        for(int j=m;j>=1;j--) {
            if(a[i][j]) rightt[i][j] = rightt[i-1][j+1] + 1;
            else rightt[i][j] = 0;
        }
    }

    int start = min(n, m);
    if(start%2 == 0) start--;

    for(int size = start; size >= 3; size-= 2) {
        for(int i=size;i<=n;i++) {
            for(int j=size;j<=m;j++) {
                if(leftt[i][j] >= size && rightt[i][j-size+1]>=size) {
                    cout<<size<<"\n";
                    return 0;
                }
            }
        } 
    }
    cout<<1<<"\n";



    return 0;
}