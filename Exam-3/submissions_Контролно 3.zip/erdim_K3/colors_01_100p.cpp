#include <iostream>
using namespace std;

const int MOD = 1e9 + 7;
const int MAXN = 3001;
int a[MAXN];

long long dp[MAXN][MAXN];
long long sum[MAXN];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);  cout.tie(NULL);
    int n, k;
    cin>>n>>k;
    for(int i=1;i<=n;i++) cin>>a[i];

    sum[0] = 1;

    for(int i=1;i<=n;i++) {
        for(int j=1;j<=k;j++) {
            if(a[i] != 0 && a[i] != j)  dp[i][j] = 0;
            else {
                dp[i][j] = (sum[i-1] - dp[i-1][j] + MOD) % MOD;
                sum[i] = (sum[i] + dp[i][j]) % MOD;
            }
        }
    }

    int ans = 0;
    for(int j=1;j<=k;j++)
        ans = (ans + dp[n][j]) % MOD;
    
    cout<<ans<<endl;

    return 0;
}