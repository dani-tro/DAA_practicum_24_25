#include <iostream>
using namespace std;

const int MAXN = 1001;
const int INF = 1e9;
int a[MAXN];
int dp[MAXN][MAXN];

int main()
{
    int n, k;
    cin>>n>>k;
    for(int i=1;i<=n;i++) cin>>a[i];

    for(int j=1;j<k;j++) dp[0][j] = - INF;

    for(int i=1;i<=n;i++) {
        for(int j=0;j<k;j++) {
            int ost = ((j - a[i]) % k + k) % k;
            dp[i][j] = max(dp[i-1][j], dp[i-1][ost] + 1);
        }
    }

    cout<<dp[n][0]<<endl;



    return 0;
}
