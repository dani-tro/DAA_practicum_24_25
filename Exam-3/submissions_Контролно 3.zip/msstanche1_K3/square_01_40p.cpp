#include <iostream>
#include <climits>
#include <vector>

using namespace std;
const int maxn = 3000;
bool table[maxn][maxn];
int dp[maxn][maxn];
int diag[maxn][maxn];
int revdiag[maxn][maxn];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int n, m;
	cin >> n >> m;
	string row;
	for (size_t i = 1; i <= n; i++)
	{
		cin >> row;
		for (size_t j = 1; j <= m; j++)
		{
			table[i][j] = row[j - 1] - '0';
		}
	}
	int maxsq = min(n, m);
	dp[1][1] = table[1][1]; 
	for (size_t j = 1; j <= m; j++)
	{
		diag[1][j] = table[1][j];
	}
	for (size_t i = 1; i <= n; i++)
	{
		diag[i][1] = table[i][1];
	}
	for (size_t i = 2; i <= n; i++)
	{
		for (size_t j = 2; j <= m; j++)
		{
			if (table[i][j] != 0)
			{
				diag[i][j] = 1 + diag[i - 1][j - 1];
			}
		}
	}

	for (size_t i = 1; i <= n; i++)
	{
		revdiag[i][m] = table[i][m];
	}
	for (size_t j = 1; j <= m; j++)
	{
		revdiag[1][j] = table[1][j];
	}
	for (size_t i = 2; i <= n; i++)
	{
		for (size_t j = 1; j <= m - 1; j++)
		{
			if (table[i][j] != 0)
				revdiag[i][j] = 1 + revdiag[i - 1][j + 1];
		}
	}

	for (size_t j = 1; j <= m; j++)
	{
		dp[1][j] = table[1][j];
	}
	for (size_t i = 1; i <= n; i++)
	{
		dp[i][1] = table[i][1];
	}

	for (size_t i = 2; i <= n; i++)
	{
		for (size_t j = 2; j <= m; j++)
		{
			if (table[i][j] == 0 || dp[i - 1][j] != 0 || dp[i][j - 1] != 0)
				continue;

			int maxside = diag[i][j];
			int horsum = 0;
			for (size_t p = j - maxside + 1; p <= j; p++)
			{
				horsum += table[i][p];
			}
			int versum = 0;
			for (size_t p = i - maxside + 1; p <= i; p++)
			{
				versum += table[p][j];
			}

			for (int k = maxside - 1; k >= 0; k--)
			{
				if (revdiag[i][j - k] >= k && horsum % 2 == 1 && versum % 2 == 1) 
				{
					dp[i][j] = k + 1;
					break;
				}
				else
				{
					horsum -= table[i][j - k];
					versum -= table[i - k][j];
				}
			}
		}
	}
	int maxside = 0;
	for (size_t i = 1; i <= n; i++)
	{
		for (size_t j = 1; j <= m; j++)
		{
			maxside = max(maxside, dp[i][j]);
		}
	}
	cout << maxside << endl;
	/*
	10 8
	10111111
	11111111
	10111111
	11111110
	01111110
	11111110
	11111111
	10110111
	11111111
	11111111
	*/
	return 0;
}