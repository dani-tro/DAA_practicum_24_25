#include <iostream>
#include <climits>
#include <vector>

using namespace std;
const int maxn = 3005;
const int MOD = 1e9 + 7;
int colors[maxn];
int dp[maxn][maxn];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int  n, k;
	cin >> n >> k;
	for (size_t i = 1; i <= n; i++)
	{
		cin >> colors[i];
	}
	if (colors[1] == 0)
	{
		for (size_t j = 1; j <= k; j++)
		{
			dp[1][j] = 1;
		}
	}
	else
	{
		dp[1][colors[1]] = 1;
	}
	for (size_t i = 2; i <= n; i++)
	{
		for (size_t j = 1; j <= k; j++)
		{
			if (colors[i] != 0 && colors[i] != j)
				continue;
			if (colors[i - 1] == j)
				continue;
			for (size_t p = 1; p <= k; p++)
			{
				if (p != j)
				{
					dp[i][j] = (dp[i][j] + dp[i - 1][p]) % MOD;
				}
			}
		}
	}
	int sum = 0;
	for (size_t j = 1; j <= k; j++)
	{
		sum = (sum + dp[n][j]) % MOD;
	}
	cout << sum << endl;
	return 0;
}