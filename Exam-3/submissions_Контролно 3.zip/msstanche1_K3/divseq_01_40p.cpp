#include <iostream>
#include <climits>
#include <vector>

using namespace std;
const int maxn = 1000;
int a[maxn];
int dp[maxn][maxn];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	int n, k;
	cin >> n >> k;
	for (size_t i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	dp[1][a[1] % k] = 1;
	for (int i = 2; i <= n; i++)
	{
		for (int j = 0; j < k; j++)
		{
			if (a[i] % k == j)
			{
				dp[i][j] = 1 + dp[i - 1][0];
			}
			else
			{
				int m = a[i] % k;
				if (dp[i - 1][((j - m) + k) % k] == 0)
				{
					dp[i][j] = 0;
				}
				else
				{
					dp[i][j] = 1 + dp[i - 1][((j - m) + k) % k];
				}
			}
		}
	}
	int maxlen = 0;
	for (size_t i = 1; i <= n; i++)
	{
		maxlen = max(dp[i][0], maxlen);
	}
	cout << maxlen << endl;
	return 0;
}