#include <iostream>
#include <climits>
#include <vector>

using namespace std;
const long long maxn = 1000;
long long a[maxn];
long long dp[maxn][maxn];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	long long n, k;
	cin >> n >> k;
	for (long long i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	for (size_t j = 0; j < k; j++)
	{
		if (a[1] % k != j)
		{
			dp[1][j] = INT_MIN / 4;
		}
		else
		{
			dp[1][j] = 1;
		}
	}
	for (long long i = 2; i <= n; i++)
	{
		for (long long j = 0; j < k; j++)
		{
			dp[i][j] = max(1 + dp[i - 1][((j - a[i] % k) + k) % k], dp[i - 1][j]);
			/*long long m = a[i] % k;
			if (m == j)
			{
				dp[i][j] = 1 + dp[i - 1][0];
			}
			else
			{
				dp[i][j] = 1 + dp[i - 1][((j - m) + k) % k];
			}*/
		}
	}
	long long maxlen = 0;
	for (long long i = 1; i <= n; i++)
	{
		maxlen = max(dp[i][0], maxlen);
	}
	cout << maxlen << endl;
	return 0;
}