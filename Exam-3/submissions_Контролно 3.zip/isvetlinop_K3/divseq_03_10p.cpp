#include <bits/stdc++.h>

const int MAXN = 1024;

long long nums[MAXN];
long long dp[MAXN][MAXN];

int main()
{
    //memset(dp, -1, sizeof(dp));
    for(int i = 0; i < MAXN; ++ i)
    {
        for(int j = 0; j < MAXN; ++ j)
        {
            dp[i][j] = -1;
        }
    }
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);

    long long n, k;
    std::cin >> n >> k;
    for(int i = 1; i <= n; ++ i)
    {
        std::cin >> nums[i];
    }

    dp[0][0] = 0;

    for(int i = 1; i <= n; ++ i)
    {
        for(long long j = 0; j < k; ++ j)
        {
            long long prev = (k + j - nums[i]) % k;
            if(dp[i - 1][prev] == -1)
            {
                dp[i][j] = dp[i - 1][j];
                //std::cout << dp[i][j] << ' ';
                continue;
            }
            dp[i][j] = std::max(dp[i - 1][j], dp[i - 1][prev] + 1);
            //std::cout << dp[i][j] << ' ';
        }
        //std::cout << '\n';
    }

    std::cout << dp[n][0] << '\n';

    return 0;
}
