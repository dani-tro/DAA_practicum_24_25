#include <iostream>

const int MAXN = 3010;

bool matrix[MAXN][MAXN];
int maxdiag[4][MAXN][MAXN];

void calcdiag(int sti, int endi, int di, int stj, int endj, int dj, int mat)
{
    for(int i = sti; i != endi; i += di)
    {
        for(int j = stj; j != endj; j += dj)
        {
            if(i == sti || j == stj)
            {
                maxdiag[mat][i][j] = matrix[i][j];
                continue;
            }
            maxdiag[mat][i][j] = matrix[i][j] ? maxdiag[mat][i - di][j - dj] + 1 : 0;
        }
    }
}

int main()
{
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);
    int n, m;
    std::cin >> n >> m;

    for(int i = 0; i < n; ++ i)
    {
        for(int j = 0; j < m; ++ j)
        {
            char ch;
            std::cin >> ch;
            matrix[i][j] = (ch == '1');
        }
    }

    calcdiag(0    , n , 1 , 0    , m , 1 , 0);
    calcdiag(0    , n , 1 , m - 1, -1, -1, 1);
    calcdiag(n - 1, -1, -1, 0    , m , 1 , 2);
    calcdiag(n - 1, -1, -1, m - 1, -1, -1, 3);

    /*for(int k = 0; k < 4; ++ k)
    {
        for(int i = 0; i < n; ++ i)
        {
            for(int j = 0; j < m; ++ j)
            {
                std::cout << maxdiag[k][i][j] << ' ';
            }
            std::cout << '\n';
        }
        std::cout << '\n';
    }*/

    int ans = 0;
    for(int i = 0; i < n; ++ i)
    {
        for(int j = 0; j < m; ++ j)
        {
            ans = std::max(ans,
                           std::min(maxdiag[0][i][j],
                                    std::min(maxdiag[1][i][j],
                                             std::min(maxdiag[2][i][j], maxdiag[3][i][j]))) * 2 - 1);
        }
    }

    std::cout << ans << '\n';

    return 0;
}
