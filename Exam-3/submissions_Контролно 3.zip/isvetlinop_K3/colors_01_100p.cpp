#include <iostream>

const int MAXN = 3010;
const int mod = 1e9 + 7;

int cols[MAXN];
int dp[MAXN][MAXN];

int main()
{
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    std::ios_base::sync_with_stdio(false);

    int n, k;
    std::cin >> n >> k;
    for(int i = 0; i < n; ++ i)
    {
        std::cin >> cols[i];
    }

    if(cols[0] == 0)
    {
        for(int i = 1; i <= k; ++ i)
        {
            dp[0][i] = 1;
        }
    }else
    {
        dp[0][cols[0]] = 1;
    }

    for(int i = 1; i < n; ++ i)
    {
        int sum = 0;
        for(int j = 1; j <= k; ++ j)
        {
            sum += dp[i - 1][j];
            sum %= mod;
        }
        if(cols[i] == 0)
        {
            for(int j = 1; j <= k; ++ j)
            {
                dp[i][j] = (mod + sum - dp[i - 1][j]) % mod;
            }
            continue;
        }
        dp[i][cols[i]] = (mod + sum - dp[i - 1][cols[i]]) % mod;
    }

    int sum = 0;
    for(int j = 1; j <= k; ++ j)
    {
        sum += dp[n - 1][j];
        sum %= mod;
    }

    std::cout << sum << '\n';

    return 0;
}
