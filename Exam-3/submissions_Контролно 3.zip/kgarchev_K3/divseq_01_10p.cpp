#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 1000;
const int MAX_K = MAX_N;


int n, k;
int a[MAX_N];
int dp[2][MAX_K];


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >>n >>k;
    for(int i = 0; i < k; ++i)
    {
        for(int j = 0; j < n; ++j)
        {
            dp[i][j] = -1;
        }
    }
    dp[0][0] = dp[1][0] = 0;
    int a;
    for(int i = 0; i < n; ++i)
    {
        cin >>a;
        a %= k;

        for(int j = 0; j < k; ++j)
        {
            dp[i & 1][j] = dp[(i - 1) & 1][(j - a + k) % k] == -1 ? dp[(i - 1) & 1][j] : max(dp[(i - 1) & 1][j], dp[(i - 1) & 1][(j - a + k) % k] + 1);
        }
    }

    cout <<dp[(n - 1) & 1][0] <<endl;
}
