#include<bits/stdc++.h>
using namespace std;


const int MAX_K = 3000;
const int MOD = 1e9 + 7;

short n, k;
int dp[2][MAX_K + 1]; // ...[0] is thew sum od the rest

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >>n >>k;
    for(int i = 0; i <= k; ++i)
    {
        dp[1][i] = 0;
    }
    dp[1][0] = 1;

    short col;
    for(int i = 0; i < n; ++i)
    {
        cin >>col;

        dp[i & 1][0] = 0;
        if(col == 0)
        {
            for(int j = 1; j <= k; ++j)
            {
                dp[i & 1][j] = (dp[(i - 1) & 1][0] + MOD - dp[(i - 1) & 1][j]) % MOD;
                dp[i & 1][0] = (dp[i & 1][0] + dp[i & 1][j]) % MOD;
            }
        }
        else
        {
            for(int j = col; j <= col; ++j)
            {
                dp[i & 1][0] = dp[i & 1][j] = (dp[(i - 1) & 1][0] + MOD - dp[(i - 1) & 1][j]) % MOD;
            }
            for(int j = 1; j <= k; ++j)
            {
                dp[i & 1][j] = j == col ? dp[i & 1][col] : 0;
            }
        }
    }

    cout <<dp[(n - 1) & 1][0] <<endl;
}
