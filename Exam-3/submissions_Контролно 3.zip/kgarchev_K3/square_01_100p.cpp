#include<bits/stdc++.h>
using namespace std;

const int MAX_N = 3000;


short n, m;
string table[MAX_N];

short dp1[MAX_N][MAX_N];
short dp2[MAX_N][MAX_N];
short dp3[MAX_N][MAX_N];


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >>n >>m;
    for(int i = 0; i < n; ++i)
    {
        cin >>table[i];

        for(int j = 0; j < m; ++j)
        {
            table[i][j] = table[i][j] == '1';
        }
    }


    for(int i = 0; i < n; ++i)
    {
        for(int j = m - 1; j >= 0; --j)
        {
            if(i == 0 || j == m - 1)
            {
                dp2[i][j] = table[i][j];
            }
            else
            {
                dp2[i][j] = table[i][j] ? dp2[i - 1][j + 1] + 1 : 0;
            }
        }
    }


    for(int i = n - 1; i >= 0; --i)
    {
        for(int j = 0; j < m; ++j)
        {
            if(i == n - 1 || j == 0)
            {
                dp1[i][j] = table[i][j];
            }
            else
            {
                dp1[i][j] = table[i][j] ? dp1[i + 1][j - 1] + 1 : 0;
            }
        }
    }


    for(int i = 0; i < n; ++i)
    {
        for(int j = 0; j < m; ++j)
        {
            dp2[i][j] = min(dp1[i][j], dp2[i][j]);
        }
    }

    for(int i = 0; i < n; ++i)
    {
        for(int j = 0; j < m; ++j)
        {
            if(i == 0 || j == 0)
            {
                dp1[i][j] = table[i][j];
            }
            else
            {
                dp1[i][j] = table[i][j] ? dp1[i - 1][j - 1] + 1 : 0;
            }
        }
    }

    for(int i = n - 1; i >= 0; --i)
    {
        for(int j = m - 1; j >= 0; --j)
        {
            if(i == 0 || j == 0)
            {
                dp3[i][j] = table[i][j];
            }
            else
            {
                dp3[i][j] = table[i][j] ? dp3[i + 1][j + 1] + 1 : 0;
            }
        }
    }

    for(int i = 0; i < n; ++i)
    {
        for(int j = 0; j < m; ++j)
        {
            dp1[i][j] = min(dp1[i][j], dp3[i][j]);
        }
    }

    short res = 0, val;
    for(int i = 0; i < n; ++i)
    {
        for(int j = 0; j < m; ++j)
        {
            val = min(2 * dp1[i][j] - 1, 2 * dp2[i][j] - 1);
            val = ((val & 1) == 0) ? val - 1 : val;
            res = max(res, val);
        }
    }

    cout <<res <<endl;
}
