#include <iostream>

using namespace std;

int N, K, input[1010], dp[1010];
size_t sum = 1;

int main() {


	cin >> N >> K;
	for (int i = 0; i < N; ++i) {
		cin >> input[i];
	}

	for (int i = 0; i < N; ++i) {
		if (input[i] > 0) {
			dp[i] = 1;
		}
		else if (i == 0) {
			if (input[1] > 0) {
				dp[0] = K - 1;
				for (int j = 1; j <= K; ++j) {
					if (j != input[i]) {
						input[i] = j;
						break;
					}
				}
			}

			else {
				dp[0] = K;
				input[1] = 1;
			}
		}

		else if (i == N - 1) {
			if (input[N-2] > 0) {
				dp[N-1] = K - 1;
				for (int j = 1; j <= K; ++j) {
					if (j != input[i]) {
						input[i] = j;
						break;
					}
				}
			}

			else {
				dp[N-1] = K;
				input[N-1] = 1;
			}
		}

		else {
			if (input[i - 1] == input[i + 1]) {
				dp[i] = K - 1;
				if (input[i - 1] < K - 1) {
					input[i] = K - 1;
				}
				else
					input[i] = 1;
			}
				
			else {
				dp[i] = K - 2;
				for (int j = 1; j <= K; ++j) {
					if (j != input[i - 1] && j != input[i + 1]) {
						input[i] = j;
						break;
					}
				}
			}
		}

		sum *= dp[i];
	}

	cout << sum % (1000000007);
}