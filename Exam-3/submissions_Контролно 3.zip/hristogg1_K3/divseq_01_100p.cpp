#include <iostream>
#include <vector>

using namespace std;

int N, K, input[1010], temp, res = 0;
vector<int> dp(1010, INT16_MIN);

int main() {


	cin >> N >> K;
	for (int i = 0; i < N; ++i) {
		cin >> input[i];
		input[i] %= K;
	}

	

	dp[0] = 0;
	for (int i = 1; i < K; ++i) {
		dp[i] = INT16_MIN;
	}

	for (int i = 0; i < N; ++i) {
		vector<int> newdp = dp;

		temp = input[i];
		for (int r = 0; r < K; ++r) {
			if (dp[r] >= 0) {
				int newRemainder = ((r + temp) % K);
				newdp[newRemainder] = max(dp[newRemainder], dp[r] + 1);
			}
		}

		dp.swap(newdp);
	}

	//cout << dp[0];

	/*dp[0] = 0;
	for (int i = 0; i < N; ++i) {
		newdp = dp;
		temp = input[i];
		for (int r = 0; r < K; ++r) {
			if (dp[r] >= 0) {
				int index = ((r + temp) % K);
				dp[index] = max(dp[index], dp[r] + 1);
			}
		}
		dp.swap(newdp);
	}*/

	cout << dp[0] << endl;
}