#include <bits/stdc++.h>
using namespace std;


const int maxn = 3005;
const long long MOD = 1e9+7;

long long n, k, a[maxn], dp[maxn][maxn];


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> k;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
    }

    int beg;
    for(int i = 1; i <= n; ++i){
        if(a[i] == 0){
            beg = i;
            break;
        }
    }
    for(int j = 1; j <= k; ++j){
        if(a[beg-1] != j && a[beg+1] != j) dp[beg][j] = 1;
    }

    for(int i = beg+1; i <= n; ++i){
        if(a[i] != 0){
            for(int j = 1; j <= k; ++j){
                dp[i][a[i]] += dp[i-1][j];
            }
        }
        else{
            for(int j = 1; j <= k; ++j){

                for(int t = 1; t <= k; ++t){
                    if(j != t && a[i+1] != t){
                        dp[i][j] += dp[i-1][t] % MOD;
                    }
                }

                dp[i][j] = dp[i][j] % MOD;
            }
        }
    }

    // for(int i = 1; i <= n; ++i){
    //     for(int j = 1; j <= k; ++j){
    //         cout << dp[i][j] << "   ";
    //     }
    //     cout << endl;
    // }

    long long ans = 0;
    for(int j = 1; j <= k; ++j){
        ans += dp[n][j] % MOD;
    }

    cout << ans % MOD << endl;

    return 0;
}