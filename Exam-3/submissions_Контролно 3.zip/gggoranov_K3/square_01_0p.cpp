#include <bits/stdc++.h>
using namespace std;

const int maxn = 3005;
int n, m, M[maxn][maxn], prim[maxn][maxn], dp[maxn][maxn];


int check(int i, int j){
    n = dp[i][j];
    int maxd = 0;
    for(int k = 0; k < n; ++k){
        diff = k;
        bool b = true;
        for(int p = 1; p <= diff; ++p){
            if(M[i-p][j+p] != 1){
                b = false;
                break;
            }
        }
        if(b) maxd = max(maxd, diff)
    }
    return maxd;
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            cin >> M[i][j];
        }
    }

    for(int i = 1; i <= n; ++i){
        prim[i][1] = M[i][1];
    }

    for(int j = 1; j <= m; ++j){
        prim[1][j] = M[1][j];
    }

    for(int i = 2; i <= n; ++i){
        for(int j = 2; j <= m; ++j){
            if(M[i][j] == 0) prim[i][j] = 0;
            else prim[i][j] = prim[i-1][j-1] + 1;
        }
    }

    int maxs = 0;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            dp[i][j] = check(i, j);
            maxs = max(maxs, dp[i][j]);
        }
    }

    cout << maxs << endl;

    return 0;
}