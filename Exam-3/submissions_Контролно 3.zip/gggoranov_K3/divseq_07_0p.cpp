#include <bits/stdc++.h>
using namespace std;

const int maxn = 1005;
long long n, k, a[maxn], dp[maxn][maxn], valid[maxn][maxn];


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> k;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
    }

    dp[1][a[1] % k] = 1;
    valid[1][a[1] % k] = 1;
    for(int i = 2; i <= n; ++i){
        if(dp[i-1][0] == 0){
            dp[i][a[2] % k] = 1;
            valid[i][a[2] % k] = 1;
        }
        for(int j = 0; j < k; ++j){
            
            if(a[i] > j){
                if(valid[i-1][k + ((j - a[i]) % k)]){
                    dp[i][j] = max(dp[i-1][k + ((j - a[i]) % k)] + 1, dp[i-1][j]);
                    valid[i][j] = 1;
                } else {
                    dp[i][j] = dp[i-1][j];
                    valid[i][j] = 1;
                }
            }
            else if(a[i] == j){
                if(valid[i-1][0]){
                    dp[i][j] = max(dp[i-1][0] + 1, dp[i-1][j]);
                    valid[i][j] = 1;
                }
            }
            else {
                if(valid[i-1][j - a[i]]){
                    dp[i][j] = max(dp[i-1][j - a[i]] + 1, dp[i-1][j]);
                    valid[i][j] = 1;
                } else {
                    dp[i][j] = dp[i-1][j];
                    valid[i][j] = 1;
                }
            }
        }
    }

    // for(int i = 1; i <= n; ++i){
    //     for(int j = 0; j < k; ++j){
    //         cout << dp[i][j] << "   ";
    //     }
    //     cout << endl;
    // }

    cout << dp[n][0] << endl;

    return 0;
}