#include <bits/stdc++.h>
using namespace std;

const int maxn = 1005;
long long n, k, a[maxn], dp[maxn][maxn];


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> k;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
    }

    dp[1][a[1] % k] = 1;
    for(int i = 2; i <= n; ++i){
        for(int j = 0; j < k; ++j){
            dp[i][j] = max(dp[i-1][k - ((j + a[i]) % k)] + 1, dp[i-1][j]);
        }
    }

    cout << dp[n][0] << endl;

    return 0;
}