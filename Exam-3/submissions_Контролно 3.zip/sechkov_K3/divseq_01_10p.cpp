#include <iostream>
using namespace std;

const int maxN = 1010;
const int maxK = 1010;

int dp[maxN][maxK];
int a[maxN];

int main() {

	int n, k;
	cin >> n >> k;

	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}

	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= k; j++) {
			if (j < a[i]) continue;
			dp[i][j] = max(dp[i - 1][j], dp[i][j - a[i]] + 1);
		}
	}

	int m = 0;

	for (int i = 0; i <= k; i++) {
		m = max(m, dp[n][i]);
	}

	cout << m;

	return 0;
}