#include <iostream>
#include <vector>
using namespace std;

const int maxN = 3010;
const int maxK = 3010;
const int modulo = 1e9 + 7;

int dp[maxN][maxK];

int main() {

	int n, k;
	cin >> n >> k;

	vector<int> a;
	a.push_back(0);

	for (int i = 1; i <= n; i++) {
		int x;
		cin >> x;
		a.push_back(x);
	}

	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= k; j++) {
			dp[i][j] = dp[i - 1][0] - dp[i - 1][j];
			dp[i][0] += dp[i][j];
		}
	}

	cout << dp[n][0];

	return 0;
}