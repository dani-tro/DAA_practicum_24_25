#include <iostream>
#include <vector>
using namespace std;

const int maxN = 1010;
const int maxK = 1010;

int dp[maxN][maxK];

int main() {

	int n, k;
	cin >> n >> k;

	vector<int> a;
	a.push_back(0);

	for (int i = 1; i <= n; i++) {
		int x;
		cin >> x;
		a.push_back(x);
	}

	dp[0][0] = 0;

	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < k; j++) {
			if (j < a[i]) {
				int x = a[i] - j;
				x %= k;
				if (dp[i - 1][k - x] != 0) {
					dp[i][j] = max(dp[i - 1][j], dp[i - 1][k - x] + 1);
				}
				else {
					dp[i][j] = dp[i - 1][j];
				}
			}
			else {
				if (dp[i - 1][j - a[i]] != 0 || j - a[i] == 0) {
					dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - a[i]] + 1);
				}
				else {
					dp[i][j] = dp[i - 1][j];
				}
			}
		}
	}

	cout << dp[n][0];

	return 0;
}