#include <iostream>
#define llong long long

const int MAXN = 1010;
const int MAXK = 1010;
llong dp[MAXN][MAXK], a[MAXN];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    llong n, k;
    std::cin >> n >> k;

    for (int i = 1; i <= n; ++i)
    {
        std::cin >> a[i];
    }

    dp[1][a[1] % k] = 1;

    for (llong i = 2; i <= n; ++i)
    {
        dp[i][a[i] % k] = 1;
        for (llong j = 0; j < k; ++j)
        {
            dp[i][j] = std::max(dp[i - 1][j], dp[i][j]);
            if (j - a[i] >= 0 && dp[i - 1][j - a[i]] > 0)
            {
                dp[i][j] = std::max(dp[i][j], dp[i - 1][j - a[i]] + 1);
            }
            else if(j - a[i] < 0 && dp[i - 1][k + (j - a[i]) % k] > 0)
            {
                dp[i][j] = std::max(dp[i][j], dp[i - 1][k + (j - a[i]) % k] + 1);
            }
        }
    }

    std::cout << dp[n][0] << std::endl;
}