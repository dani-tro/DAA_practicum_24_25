#include <iostream>
#include <string>

const int MAXSIZE = 3000;
int dp[MAXSIZE][MAXSIZE][4];
bool matrix[MAXSIZE][MAXSIZE];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    int n, m;
    std::cin >> n >> m;

    for (int i = 1; i <= n; ++i)
    {
        std::string num;
        std::cin >> num;
        int currIndex = m;
        for(int j = 1; j <= m; ++j) {
            if(num[j - 1] == '1') {
                matrix[i][j] = 1;
            }
        }
        // std::cin >> matrix[i][j];
    }

    // for(int i = 1; i <= n; ++i) {
    //     for(int j = 1; j <= m; ++j) {
    //         std::cout << matrix[i][j] << ' ';
    //     }
    //     std::cout << std::endl;
    // }

    for (int i = 1; i <= n; ++i)
    {
        dp[i][1][0] = matrix[i][1];
        dp[i][m][1] = matrix[i][m];
        dp[i][m][2] = matrix[i][m];
        dp[i][1][3] = matrix[i][1];
    }
    for (int i = 1; i <= m; ++i)
    {
        dp[1][i][0] = matrix[1][i];
        dp[1][i][1] = matrix[1][i];
        dp[n][i][2] = matrix[n][i];
        dp[n][i][3] = matrix[n][i];
    }

    for (int i = 2; i <= n; ++i)
    {
        for (int j = 2; j <= m; ++j)
        {
            dp[i][j][0] = dp[i - 1][j - 1][0] + matrix[i][j];
            dp[i][m - j + 1][1] = dp[i - 1][m - j + 2][1] + matrix[i][m - j + 1];
            dp[n - i + 1][m - j + 1][2] = dp[n - i + 2][m - j + 2][2] + matrix[n - i + 1][m - j + 1];
            dp[n - i + 1][j][3] = dp[n - i + 2][j - 1][3] + matrix[n - i + 1][j];
        }
    }
    int res = 0;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= n; ++j)
        {
            // int curr = std::min(dp[i][j][0], std::min(dp[i][j][1], std::min(dp[i][j][2], dp[i][j][3]))) * 2 - 1;
            res = std::max(res, std::min(dp[i][j][0], std::min(dp[i][j][1], std::min(dp[i][j][2], dp[i][j][3]))) * 2 - 1);
        }
    }
    std::cout << res << std::endl;

    // std::cout << std::endl;

    // std::cout << 0 << std::endl;
    // for(int i = 1; i <= n; ++i) {
    //     for(int j = 1; j <= m; ++j) {
    //         std::cout << dp[i][j][0] << " ";
    //     }
    //     std::cout << std::endl;
    // }
    // std::cout << std::endl;

    // std::cout << 1 << std::endl;
    // for(int i = 1; i <= n; ++i) {
    //     for(int j = 1; j <= m; ++j) {
    //         std::cout << dp[i][j][1] << " ";
    //     }
    //     std::cout << std::endl;
    // }
    // std::cout << std::endl;

    // std::cout << 2 << std::endl;
    // for(int i = 1; i <= n; ++i) {
    //     for(int j = 1; j <= m; ++j) {
    //         std::cout << dp[i][j][2] << " ";
    //     }
    //     std::cout << std::endl;
    // }
    // std::cout << std::endl;

    // std::cout << 3 << std::endl;
    // for(int i = 1; i <= n; ++i) {
    //     for(int j = 1; j <= m; ++j) {
    //         std::cout << dp[i][j][3] << " ";
    //     }
    //     std::cout << std::endl;
    // }
    // std::cout << std::endl;
}

/*
10 8
1 0 1 1 1 1 1 1
1 1 1 1 1 1 1 1
1 0 1 1 1 1 1 1
1 1 1 1 1 1 1 0
0 1 1 1 1 1 1 0
1 1 1 1 1 1 1 0
1 1 1 1 1 1 1 1
1 0 1 1 0 1 1 1
1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1
*/