// #include <bits/stdc++.h>
#include <iostream>
#define llong long long

const int MAXN = 3010;
const int MAXK = 3010;
const int MOD = 1e9 + 7;

llong dp[MAXN][MAXK];
int n, k;

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> k;

    for (int i = 1; i <= n; ++i)
    {
        int color;
        std::cin >> color;
        if (color > 0)
        {
            for (int j = 1; j <= k; ++j)
            {
                if (j == color)
                    continue;
                dp[i][j] = -1;
            }
        }
    }

    for (int i = 1; i <= k; ++i)
    {
        if (dp[1][i] != -1)
            dp[1][i] = 1;
    }

    for (int i = 2; i <= n; ++i)
    {
        for (int j = 1; j <= k; ++j)
        {
            if (dp[i][j] == -1)
                continue;
            for (int l = 1; l <= k; ++l)
            {
                if (dp[i - 1][l] == -1 || j == l)
                    continue;
                dp[i][j] = (dp[i][j] + dp[i - 1][l]) % MOD;
            }
        }
    }

    llong ans = 0;
    for (int i = 1; i <= k; ++i)
    {
        if (dp[n][i] != -1)
        {
            ans = (ans + dp[n][i]) % MOD;
        }
    }

    std::cout << ans << std::endl;
}
