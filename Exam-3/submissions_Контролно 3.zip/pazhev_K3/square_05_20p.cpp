// #include <bits/stdc++.h>
// using namespace std;

// #define MAX 3010

// bool table[MAX][MAX];
// unsigned dp[MAX][MAX];

// int main() {
//     ios_base::sync_with_stdio(false);
//     cin.tie(nullptr);
//     cout.tie(nullptr);

//     size_t n, m;
//     cin >> n >> m;

//     char c;

//     for (size_t i = 0; i < n; ++i) {
//         for (size_t j = 0; j < m; ++j) {
//             cin >> c;
//             table[i][j] = c - '0';
//         }
//     }

//     unsigned opt = 0;

//     for (unsigned i = 0; i < n; ++i) {
//         for (unsigned j = 0; j < m; ++j) {
//             dp[i][j] = table[i][j];

//             if (i == 0 || j == 0) {
//                 continue;
//             }

//             unsigned s = min({ dp[i - 1][j - 1], i - 1, j - 1 });

//             if (s == 0) {
//                 continue;
//             }

//             if (s % 2 == 0) {
//                 --s;
//             }

//             if (table[i - 1 - s][j] && table[i][j - 1 - s] && table[i - 1 - s][j - 1 - s]) {
//                 dp[i][j] = s + 2;
//             }

//             opt = max(opt, dp[i][j]);
//         }
//     }

//     cout << opt;
//     return 0;
// }
#include <bits/stdc++.h>
using namespace std;

#define MAX 3010

bool table[MAX][MAX];
bool dp[MAX][MAX][2];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    size_t n, m;
    cin >> n >> m;

    char c;

    for (size_t i = 0; i < n; ++i) {
        for (size_t j = 0; j < m; ++j) {
            cin >> c;
            table[i][j] = c - '0';
        }
    }

    unsigned opt = 0;
    bool f = 0;

    for (unsigned i = 0; i < n; ++i) {
        for (unsigned j = 0; j < m; ++j) {
            dp[i][j][f] = table[i][j];
            if (table[i][j]) {
                opt = 1;
            }
        }
    }

    f = !f;

    for (unsigned s = 1; s <= min(n, m); s += 2) {
        for (unsigned i = s / 2; i + s / 2 < n; ++i) {
            for (unsigned j = s / 2; j + s / 2 < m; ++j) {
                if (!dp[i][j][!f]) {
                    continue;
                }

                if (table[i + s / 2][j - s / 2] && table[i + s / 2][j + s / 2] && table[i - s / 2 ][j + s / 2] && table[i - s / 2][j - s / 2]) {
                    dp[i][j][f] = true;
                    opt = max(opt, s);
                }

            }
        }

        f = !f;
    }

    cout << opt;
    return 0;
}