#include <bits/stdc++.h>
using namespace std;

#define MAX 1010

unsigned dp[MAX][MAX], nums[MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    size_t n;
    unsigned k;

    cin >> n >> k;
    for (size_t i = 1; i <= n; ++i) {
        cin >> nums[i];
    }

    for (size_t i = 1; i <= n; ++i) {
        for (size_t j = 0; j < k; ++j) {
            if (nums[i] % k == j) {
                dp[i][j] = 1;
            }

            dp[i][j] = max(dp[i][j], dp[i - 1][j]);

            if (dp[i - 1][(k + j - nums[i] % k) % k] > 0) {
                dp[i][j] = max(dp[i][j], 1 + dp[i - 1][(k + j - nums[i] % k) % k]);
            }
        }
    }

    cout << dp[n][0];
    return 0;
}