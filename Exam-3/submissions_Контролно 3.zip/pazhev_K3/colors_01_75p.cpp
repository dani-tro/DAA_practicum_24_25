#include <bits/stdc++.h>
using namespace std;

#define d 1000000007
#define MAX 3010

unsigned cols[MAX], dp[MAX][MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    size_t n;
    unsigned k;
    cin >> n >> k;

    for (size_t i = 1; i <= n; ++i) {
        cin >> cols[i];

    }

    for (unsigned c = 1; c <= k; ++c) {
        dp[1][c] = (cols[1] == c || cols[1] == 0 ? 1 : 0);
    }

    for (size_t i = 2; i <= n; ++i) {
        for (unsigned c = 1; c <= k; ++c) {
            if (cols[i] != c && cols[i] != 0) {
                continue;
            }

            for (unsigned j = 1; j <= k; ++j) {
                if (j != c) {
                    dp[i][c] = (dp[i][c] + dp[i - 1][j]) % d;
                }
            }
        }
    }

    unsigned result = 0;
    for (unsigned c = 1; c <= k; ++c) {
        result = (result + dp[n][c]) % d;
    }

    cout << result;
    return 0;
}