#include <bits/stdc++.h>
using namespace std;

#define MAX 3010

bool table[MAX][MAX];
unsigned dp[MAX][MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    size_t n, m;
    cin >> n >> m;

    char c;

    for (size_t i = 0; i < n; ++i) {
        for (size_t j = 0; j < m; ++j) {
            cin >> c;
            table[i][j] = c - '0';
        }
    }

    unsigned opt = 0;

    for (unsigned i = 0; i < n; ++i) {
        for (unsigned j = 0; j < m; ++j) {
            dp[i][j] = table[i][j];

            if (i == 0 || j == 0) {
                continue;
            }

            unsigned s = min({ dp[i - 1][j - 1], i - 1, j - 1 });

            if (s == 0) {
                continue;
            }

            if (s % 2 == 0) {
                --s;
            }

            if (table[i - 1 - s][j] && table[i][j - 1 - s] && table[i - 1 - s][j - 1 - s]) {
                dp[i][j] = s + 2;
            }

            opt = max(opt, dp[i][j]);
        }
    }

    cout << opt;
    return 0;
}