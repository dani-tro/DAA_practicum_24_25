// #include <bits/stdc++.h>
// using namespace std;

// #define MAX 3010

// bool table[MAX][MAX];
// unsigned dp[MAX][MAX];

// int main() {
//     ios_base::sync_with_stdio(false);
//     cin.tie(nullptr);
//     cout.tie(nullptr);

//     size_t n, m;
//     cin >> n >> m;

//     char c;

//     for (size_t i = 0; i < n; ++i) {
//         for (size_t j = 0; j < m; ++j) {
//             cin >> c;
//             table[i][j] = c - '0';
//         }
//     }

//     unsigned opt = 0;

//     for (unsigned i = 0; i < n; ++i) {
//         for (unsigned j = 0; j < m; ++j) {
//             dp[i][j] = table[i][j];

//             if (i == 0 || j == 0) {
//                 continue;
//             }

//             unsigned s = min({ dp[i - 1][j - 1], i - 1, j - 1 });

//             if (s == 0) {
//                 continue;
//             }

//             if (s % 2 == 0) {
//                 --s;
//             }

//             if (table[i - 1 - s][j] && table[i][j - 1 - s] && table[i - 1 - s][j - 1 - s]) {
//                 dp[i][j] = s + 2;
//             }

//             opt = max(opt, dp[i][j]);
//         }
//     }

//     cout << opt;
//     return 0;
// }
#include <bits/stdc++.h>
using namespace std;

#define MAX 3010

bool table[MAX][MAX];
unsigned dp1[MAX][MAX], dp2[MAX][MAX];
unsigned dp3[MAX][MAX], dp4[MAX][MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    size_t n, m;
    cin >> n >> m;

    char c;

    for (size_t i = 0; i < n; ++i) {
        for (size_t j = 0; j < m; ++j) {
            cin >> c;
            table[i][j] = c - '0';
        }
    }

    for (size_t j = 0; j < m; ++j) {
        dp1[0][j] = table[0][j];
        dp2[0][j] = table[0][j];
    }

    for (size_t i = 1; i < n; ++i) {
        for (size_t j = 0; j < m; ++j) {
            if (!table[i][j]) {
                continue;
            }

            dp1[i][j] = table[i][j];
            dp2[i][j] = table[i][j];

            if (j + 1 < m) {
                dp1[i][j] = dp1[i - 1][j + 1] + 1;
            }

            if (j > 0) {
                dp2[i][j] = dp2[i - 1][j - 1] + 1;
            }
        }
    }

    for (size_t j = 0; j < m; ++j) {
        dp3[n - 1][j] = table[n - 1][j];
        dp4[n - 1][j] = table[n - 1][j];
    }

    for (int i = n - 1; i >= 0; --i) {
        for (size_t j = 0; j < m; ++j) {
            if (!table[i][j]) {
                continue;
            }

            dp3[i][j] = table[i][j];
            dp4[i][j] = table[i][j];

            if (j + 1 < m) {
                dp3[i][j] = dp3[i + 1][j + 1] + 1;
            }

            if (j > 0) {
                dp4[i][j] = dp4[i + 1][j - 1] + 1;
            }
        }
    }

    unsigned opt = 0;

    for (size_t i = 0; i < n; ++i) {
        for (size_t j = 0; j < m; ++j) {
            if (table[i][j]) {
                opt = max(opt, min({ dp1[i][j], dp2[i][j], dp3[i][j], dp4[i][j]}) * 2 - 1);
            }
        }
    }

    cout << opt;
    return 0;
}