#include <bits/stdc++.h>
using namespace std;

#define d 1000000007
#define MAX 3010

unsigned cols[MAX];
unsigned long long dp[MAX][MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    size_t n;
    unsigned k;
    cin >> n >> k;

    for (size_t i = 1; i <= n; ++i) {
        cin >> cols[i];

    }

    for (unsigned c = 1; c <= k; ++c) {
        if (cols[1] == 0) {
            dp[1][c] = c;
        } else if (cols[1] <= c) {
            dp[1][c] = 1;
        }
    }

    for (size_t i = 2; i <= n; ++i) {
        for (unsigned c = 1; c <= k; ++c) {
            if (cols[i] > c) {
                continue;
            }

            if (cols[i] > 0) {
                dp[i][c] = (dp[i - 1][cols[i] - 1] + d + dp[i - 1][k] - dp[i - 1][cols[i]]) % d;
                continue;
            }

            dp[i][c] = (dp[i][c - 1] + dp[i - 1][c - 1] + d + dp[i - 1][k] - dp[i - 1][c]) % d;
        }
    }
    
    cout << dp[n][k];
    return 0;
}