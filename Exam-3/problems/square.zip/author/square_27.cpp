#include<iostream>
using namespace std;


const int M=10000;
const int N=10000;
short int t[M][N];

int m,n;


int main()
{
    std::ios_base::sync_with_stdio (false); // makes I/O faster

    cin >> m >> n;

    for(int i=1;i<=m;i++)
    for(int j=1;j<=n;j++)
    {
      char c; cin >> c;
      if(c=='1') t[i][j]=1;
    }

   int r=0;
   for(int i0=1;i0<=m;i0++)
   for(int j0=1;j0<=n;j0++)
   for(int d=0;i0+d<=m && j0+d<=n;d=d+2)
   {
      bool b=true;
      int i=i0;
      int j=j0;
      while(i<=i0+d && j<=j0+d)
      {
          if(t[i][j]==0){b=false; break;}
          i++;j++;
      }
      if(!b) continue;

      i=i0;
      j=j0+d;
      while(i<=i0+d && j>=j0)
      {
          if(t[i][j]==0){b=false; break;}
          i++;j--;
      }
      if(!b) continue;

      if(r<d+1) r=d+1;

   }

   cout << r << endl;

}
