// square.cpp
// Emil Kelevedjiev
// dp method

#include<iostream>
using namespace std;


const int M=3000;
const int N=3000;
short int t[M][N];

int m,n;

int UR[M][N];
int UL[M][N];
int DR[M][N];
int DL[M][N];

void doUR()
{
    int j0=1;
    for(int i0=1;i0<=m;i0++)
    {

      UR[i0][j0]=t[i0][j0];
      int i=i0-1;
      int j=j0+1;
      while(i>=1 && (j<=n))
      {
          if(t[i][j]==0) UR[i][j]=0;
          else UR[i][j]=1+UR[i+1][j-1];
          i--;j++;
      }
    }
    int i0=m;
    for(int j0=2;j0<=n;j0++)
    {

      UR[i0][j0]=t[i0][j0];
      int i=i0-1;
      int j=j0+1;
      while(i>=1 && (j<=n))
      {
          if(t[i][j]==0) UR[i][j]=0;
          else UR[i][j]=1+UR[i+1][j-1];
          i--;j++;
      }
    }

}

void doUL()
{

    int j0=n;
    for(int i0=1;i0<=m;i0++)
    {

      UL[i0][j0]=t[i0][j0];
      int i=i0-1;
      int j=j0-1;
      while(i>=1 && j>=1)
      {
          if(t[i][j]==0) UL[i][j]=0;
          else UL[i][j]=1+UL[i+1][j+1];
          i--;j--;
      }
    }
    int i0=m;
    for(int j0=n-1;j0>=1;j0--)
    {

      UL[i0][j0]=t[i0][j0];
      int i=i0-1;
      int j=j0-1;
      while(i>=1 && j>=1)
      {
          if(t[i][j]==0) UL[i][j]=0;
          else UL[i][j]=1+UL[i+1][j+1];
          i--;j--;
      }
    }

}

void doDR()
{
    int i0=1;
    for(int j0=n;j0>=1;j0--)
    {

      DR[i0][j0]=t[i0][j0];
      int i=i0+1;
      int j=j0+1;
      while(i<=m && (j<=n))
      {
          if(t[i][j]==0) DR[i][j]=0;
          else DR[i][j]=1+DR[i-1][j-1];
          i++;j++;
      }
    }
    int j0=1;
    for(int i0=2;i0<=m;i0++)
    {

      DR[i0][j0]=t[i0][j0];
      int i=i0+1;
      int j=j0+1;
      while(i<=m && (j<=n))
      {
          if(t[i][j]==0) DR[i][j]=0;
          else DR[i][j]=1+DR[i-1][j-1];
          i++;j++;
      }
    }

}

void doDL()
{
    int j0=n;
    for(int i0=m;i0>=1;i0--)
    {

      DL[i0][j0]=t[i0][j0];
      int i=i0+1;
      int j=j0-1;
      while(i<=m && (j<=n))
      {
          if(t[i][j]==0) DL[i][j]=0;
          else DL[i][j]=1+DL[i-1][j+1];
          i++;j--;
      }
    }
    int i0=1;
    for(int j0=n-1;j0>=1;j0--)
    {

      DL[i0][j0]=t[i0][j0];
      int i=i0+1;
      int j=j0-1;
      while(i<=m && (j<=n))
      {
          if(t[i][j]==0) DL[i][j]=0;
          else DL[i][j]=1+DL[i-1][j+1];
          i++;j--;
      }
    }

}


int main()
{

    std::ios_base::sync_with_stdio (false);

    cin >> m >> n;

    for(int i=1;i<=m;i++)
    for(int j=1;j<=n;j++)
    {
      char c; cin >> c;
      if(c=='1') t[i][j]=1;
    }

 doUR();
 doUL();
 doDR();
 doDL();



 int r=0;
 for(int i=1;i<=m;i++)
 {
 for(int j=1;j<=n;j++)
  {
    int d=UR[i][j];
    if(d > UL[i][j]) d=UL[i][j];
    if(d > DR[i][j]) d=DR[i][j];
    if(d > DL[i][j]) d=DL[i][j];

    if(r<d) r=d;
  }

 }
  cout << 2*r-1 << endl;
}

