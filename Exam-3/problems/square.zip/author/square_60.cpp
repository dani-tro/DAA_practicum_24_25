#include<iostream>
using namespace std;

const int M=10000;
const int N=10000;
short int t[M][N];

int m,n;


int main()
{
    std::ios_base::sync_with_stdio (false); // makes I/O faster

    cin >> m >> n;

    for(int i=1;i<=m;i++)
    for(int j=1;j<=n;j++)
    {
      char c; cin >> c;
      if(c=='1') t[i][j]=1;
    }

    int R=0;
    for(int i=1;i<=m;i++)
    {
    for(int j=1;j<=n;j++)
    {
      //cout << "i=" << i << " j=" << j << endl;
      if(t[i][j]==0)
      {
        //// cout << "* ";
      }
      else
      {
      int i0=i; int j0=j;
      int r = m+n;


      //cout << "UR" << endl;
      int d=0;
      while(i0>=1 && j0<=n)
      {
        if(t[i0][j0]==1) {i0--; j0++; d++;}
        else break;
        if(d>=r) break;
      }
      if(r>d)r=d;


      //cout << "UL" << endl;
      d=0; i0=i; j0=j;
      while(i0>=1 && j0>=1)
      {
        if(t[i0][j0]==1) {i0--; j0-- ;d++;}
        else break;
        if(d>=r) break;
      }
      if(r>d)r=d;

      //cout << "DL" << endl;
      d=0; i0=i; j0=j;
      while(i0<=m && j0>=1)
      {
        if(t[i0][j0]==1) {i0++; j0-- ;d++;}
        else break;
        if(d>=r) break;
      }
      if(r>d)r=d;

      //cout << "DR" << endl;
      d=0; i0=i; j0=j;
      while(i0<=m && j0<=n)
      {
        if(t[i0][j0]==1) {i0++; j0++ ;d++;}
        else break;
        if(d>=r) break;
      }
      if(r>d)r=d;
      if(R<r) R=r;

    ////cout << r << " ";
      }
    }
    ////cout << endl;
    }
   //cout << "R=";
   cout << 2*R-1 << endl;
}
