#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;
typedef long long llong;

const int MAX_N = 3000;
const int MAX_K = 3000;
const llong MOD = 1000000007LL;

int n, k;
int vals[MAX_N + 111];
llong F[MAX_N + 111][MAX_K + 111];

int main()
{
    int i, j;

    scanf("%d %d", &n, &k);

    for (i=1;i<=n;i++)
    {
        scanf("%d", &vals[i]);
    }

    llong prevTotal = 1;
    for (i=1;i<=n;i++)
    {
        llong total = 0;
        for (j=1;j<=k;j++)
        {
            if (vals[i] != 0 && vals[i] != j)
                continue;

            F[i][j] = prevTotal - F[i-1][j] + MOD;
            if (F[i][j] >= MOD)
                F[i][j] -= MOD;

            total += F[i][j];
            if (total >= MOD)
                total -= MOD;
        }
        prevTotal = total;
    }

    printf("%lld\n", prevTotal);

    return 0;
}
